"""Movement refinement: cleaning, normalisation and two-hand control."""
import math

import numpy as np
import pytest

from formflow.app import App, VIEWPORT
from formflow.calibration import Calibration, CalibrationWizard, Sample
from formflow.hand import GestureDecoder, HandInput, HandTrack, Reading, isotropic_region
from formflow.sketch3d import Sketch3D
from formflow.ui import Pointer

VP = VIEWPORT


def centre():
    return VP[0] + VP[2] / 2, VP[1] + VP[3] / 2


# ----------------------------------------------------------- landmarks helper
def hand(gap=0.9, curled=False, at=(0.5, 0.5), size=0.1):
    """21 landmarks in image coords; `size` = palm size, `gap` = thumb-index gap in palm sizes."""
    lm = np.zeros((21, 3))
    lm[0] = (0, 0, 0)
    lm[9] = (0, -1, 0)
    lm[4] = (-gap / 2, -1.5, 0)
    lm[8] = (gap / 2, -1.5 if not curled else -0.6, 0)
    for tip, pip in zip((12, 16, 20), (10, 14, 18)):
        lm[pip] = (0, -1.2, 0)
        lm[tip] = (0, -0.6 if curled else -2.0, 0)
    lm[6] = (0, -1.2, 0)
    out = lm[:, :2] * size
    out = out + np.array(at)
    full = np.zeros((21, 3))
    full[:, :2] = out
    return full


# ----------------------------------------------------------- isotropic mapping
def test_isotropic_region_already_matching_is_unchanged():
    r = (0.2, 0.2, 0.8, 0.8)
    assert isotropic_region(r, 16 / 9, 16 / 9) == pytest.approx(r)


def test_isotropic_region_equalises_axis_speed():
    cam, scr = 16 / 9, 16 / 9
    r = isotropic_region((0.1, 0.2, 0.9, 0.6), cam, scr)        # a wide, flat calibrated box
    x0, y0, x1, y1 = r
    assert ((x1 - x0) * cam) / (y1 - y0) == pytest.approx(scr, rel=1e-6)
    assert 0 <= x0 < x1 <= 1 and 0 <= y0 < y1 <= 1             # still inside the camera image


def test_isotropic_region_tall_box_and_overflow():
    cam, scr = 16 / 9, 16 / 9
    for box in [(0.4, 0.05, 0.6, 0.95), (0.0, 0.0, 1.0, 0.3), (0.05, 0.05, 0.95, 0.95)]:
        x0, y0, x1, y1 = isotropic_region(box, cam, scr)
        assert 0 <= x0 < x1 <= 1 and 0 <= y0 < y1 <= 1
        assert ((x1 - x0) * cam) / (y1 - y0) == pytest.approx(scr, rel=1e-6)


def test_distance_normalisation_shrinks_reach_for_close_hand():
    h = HandInput(screen=(1000, 500), region=(0.25, 0.25, 0.75, 0.75))
    h.cam_aspect = 2.0
    h.cal = Calibration(palm_ref=0.10)
    far = h.map_point((0.65, 0.5), palm=0.10)                  # at calibration distance
    near = h.map_point((0.65, 0.5), palm=0.20)                 # twice as close: same motion looks bigger
    assert far[0] > near[0] > 500                              # shrunk back toward the centre
    assert h.map_point((0.5, 0.5), 0.2) == pytest.approx((500, 250))   # centre never moves


def test_no_normalisation_without_palm_ref():
    h = HandInput(screen=(1000, 500), region=(0.25, 0.25, 0.75, 0.75))
    h.cam_aspect = 2.0
    assert h.map_point((0.65, 0.5), 0.1) == h.map_point((0.65, 0.5), 0.3)


# ----------------------------------------------------------- HandTrack cleaning
def feed(track, secs, gap=0.9, at=(0.5, 0.5), t0=0.0, fps=30, **kw):
    t, out = t0, None
    for _ in range(int(secs * fps)):
        out = track.step(hand(gap, at=at, **kw), t)[0]
        t += 1 / fps
    return out, t


def test_glitch_leap_is_rejected_then_accepted_if_real():
    tr = HandTrack()
    r, t = feed(tr, 0.5, at=(0.3, 0.4))
    base = r.cur.copy()
    r = tr.step(hand(at=(0.8, 0.8)), t)[0]                      # one-frame teleport
    assert np.linalg.norm(r.cur - base) < 0.05
    for i in range(1, 8):                                       # it stays there: it was real movement
        r = tr.step(hand(at=(0.8, 0.8)), t + i / 30)[0]
    assert r.cur[0] > 0.6


def test_pinch_onset_latches_to_pre_pinch_position():
    tr = HandTrack()
    r, t = feed(tr, 1.0, gap=0.9, at=(0.5, 0.5))
    # the closing motion drags the cursor: simulate drift while the fingers close
    for i, (gap, x) in enumerate([(0.7, 0.505), (0.5, 0.52), (0.2, 0.54), (0.1, 0.56), (0.1, 0.56), (0.1, 0.56)]):
        r = tr.step(hand(gap, at=(x, 0.5)), t + i / 30)[0]
    assert r.pinching
    assert abs(r.cur[0] - 0.5) < 0.02                           # pinned near where you aimed, not 0.56


def test_release_freezes_cursor_briefly():
    tr = HandTrack()
    r, t = feed(tr, 1.0, gap=0.1, at=(0.5, 0.5))                # pinching and steady
    assert r.pinching
    for i, (gap, x) in enumerate([(0.3, 0.5), (0.7, 0.53), (0.9, 0.56), (0.9, 0.58)]):
        r = tr.step(hand(gap, at=(x, 0.5)), t + i / 30)[0]
    assert not r.pinching and abs(r.cur[0] - 0.5) < 0.03        # no hook as the fingers open


# ----------------------------------------------------------- roles
def test_assign_roles():
    f = HandInput.assign_roles
    assert f(["Left"], [0.3], "Right") == ["main"]              # a single hand is always the main hand
    assert f(["Right", "Left"], [0.7, 0.3], "Right") == ["main", "second"]
    assert f(["Left", "Right"], [0.3, 0.7], "Right") == ["second", "main"]
    assert f(["Left", "Right"], [0.3, 0.7], "Left") == ["main", "second"]
    assert f(["Right", "Right"], [0.3, 0.7], "Right") == ["second", "main"]   # same label: by position
    assert f(["Left", "Left"], [0.3, 0.7], "Left") == ["main", "second"]


# ----------------------------------------------------------- stroke input
def test_orbit_clamps_glitch_jumps():
    sk = Sketch3D()
    y0 = sk.yaw
    sk.orbit(5000, 0, now=1.0)
    assert abs(sk.yaw - y0) <= 60 * 0.009 + 1e-9


def test_orbit_inertia_decays_and_stops():
    sk = Sketch3D()
    t = 0.0
    for _ in range(10):                                         # fast steady swipe
        sk.orbit(40, 0, now=t)
        t += 1 / 60
    y_end = sk.yaw
    sk.release_orbit(now=t)
    assert sk._coasting
    moved = []
    for _ in range(300):
        t += 1 / 60
        before = sk.yaw
        sk.coast(now=t)
        moved.append(abs(sk.yaw - before))
    assert sk.yaw != y_end                                      # it kept spinning
    assert moved[0] > moved[40] > moved[120]                    # and slowed smoothly
    assert not sk._coasting and moved[-1] == 0                  # then stopped


def test_slow_release_does_not_coast():
    sk = Sketch3D()
    sk.orbit(1, 0, now=0.0)
    sk.orbit(1, 0, now=0.5)
    sk.release_orbit(now=0.5)
    assert not sk._coasting


def test_new_grab_cancels_coasting():
    sk = Sketch3D()
    for i in range(10):
        sk.orbit(40, 0, now=i / 60)
    sk.release_orbit(now=0.2)
    sk.orbit(1, 0, now=0.3)
    assert not sk._coasting


def test_freehand_stroke_is_normalised_to_even_spacing():
    sk = Sketch3D()
    sk.yaw = sk.pitch = 0.0
    sk.begin(560, 300 + 8 * math.sin(560 / 25), VP)
    xs = [560 + i * i * 0.9 for i in range(1, 15)]              # accelerating hand: uneven samples
    for x in xs:
        sk.add(x, 300 + 8 * math.sin(x / 25), VP)
    sk.end()
    d = np.linalg.norm(np.diff(sk.items[0].pts, axis=0), axis=1)
    assert d[:-1].std() / d[:-1].mean() < 0.1       # all but the (partial) last segment


def test_release_hook_is_trimmed():
    sk = Sketch3D()
    sk.yaw = sk.pitch = 0.0
    t = 100.0
    sk.begin(400, 300, VP)
    sk._times = [t]
    for i in range(1, 31):                                      # a clean horizontal stroke ...
        sk.add(400 + i * 6, 300, VP, now=t + i / 30)
    for i in range(31, 36):                                     # ... then the hook as fingers open
        sk.add(580 + (i - 30) * 2, 300 + (i - 30) * 14, VP, now=t + i / 30)
    sk.end(trim=0.2, now=t + 35 / 30)
    pts = sk.items[0].pts
    assert np.ptp(pts[:, 1]) < 0.05                             # no vertical hook left


def test_trim_never_destroys_a_short_stroke():
    sk = Sketch3D()
    sk.begin(400, 300, VP)
    sk.add(500, 320, VP)
    sk.end(trim=0.5)                                            # all points are 'recent'
    assert len(sk.items) == 1


def test_snap_skips_normalisation():
    sk = Sketch3D()
    sk.snap = True
    sk.begin(410, 311, VP)
    sk.add(520, 333, VP)
    sk.add(600, 340, VP)
    sk.end()
    assert np.allclose(sk.items[0].pts / 0.1, np.round(sk.items[0].pts / 0.1))


def test_offhand_depth_deadzone_direction_and_easing():
    sk = Sketch3D()
    sk.depth_gain = 3.0
    sk.offhand_depth(0.10)                                      # first sighting = neutral
    assert sk.depth == 0.0
    sk.offhand_depth(0.104)                                     # inside the dead zone
    assert sk.depth == 0.0
    for _ in range(40):
        sk.offhand_depth(0.14)                                  # hand pushed toward the camera
    assert 0.2 < sk.depth <= 1.0
    for _ in range(80):
        sk.offhand_depth(0.07)                                  # pulled back
    assert sk.depth < -0.1
    sk.offhand_depth(0.0)                                       # no hand: ignored
    d = sk.depth
    sk.offhand_depth(0.0)
    assert sk.depth == d


def test_depth_mode_cycles_through_three():
    sk = Sketch3D()
    assert [sk.toggle_depth_mode() for _ in range(4)] == ["hand", "offhand", "steps", "hand"]


# ----------------------------------------------------------- two hands in the app
def frame(a, **kw):
    a.update()
    a.render()
    a.ptr.tick()
    a.ptr2.prev_down = a.ptr2.down


def test_second_hand_fist_orbits_while_main_hand_keeps_drawing():
    a = App()
    a.screen = "air"
    a.ptr.visible = True
    a.ptr.x, a.ptr.y = 500, 300
    a.ptr.down = True
    frame(a)                                                    # main hand starts a stroke
    assert a.drawing
    yaw0 = a.sketch.yaw
    a.ptr2.visible, a.ptr2.grab = True, True
    a.ptr2.x, a.ptr2.y = 300, 300
    frame(a)
    for i in range(1, 12):
        a.ptr.x += 5
        a.ptr2.x += 8
        frame(a)
    assert a.drawing and a.sketch.active is not None and len(a.sketch.active) > 3   # still drawing
    assert a.sketch.yaw != yaw0                                 # while the other hand rotated the view


def test_second_hand_open_palm_sets_depth_only_in_offhand_mode():
    a = App()
    a.screen = "air"
    a.ptr2.visible, a.ptr2.scale = True, 0.10
    frame(a)
    a.ptr2.scale = 0.16
    for _ in range(40):
        frame(a)
    assert a.sketch.depth == 0.0                                # default mode ignores it
    a.sketch.palm_ref = 0.10                                    # neutral distance (normally the calibrated one)
    a.sketch.depth_mode = "offhand"
    for _ in range(40):
        frame(a)
    assert a.sketch.depth > 0.2


def test_second_hand_lost_stops_navigation():
    a = App()
    a.screen = "air"
    a.ptr2.visible, a.ptr2.grab = True, True
    a.ptr2.x, a.ptr2.y = 300, 300
    frame(a)
    a.ptr2.x = 340
    frame(a)
    assert a._grab2 is not None
    a.ptr2.visible = False
    frame(a)
    assert a._grab2 is None


def test_mouse_right_drag_inertia_and_wheel():
    a = App()
    a.screen = "air"
    a.ptr.visible, a.ptr.grab = True, True
    a.ptr.x, a.ptr.y = 500, 300
    frame(a)
    for i in range(1, 8):
        a.ptr.x += 30
        frame(a)
    a.ptr.grab = False
    frame(a)
    assert a.sketch._coasting


def test_dominant_hand_toggle_persists_in_calibration(tmp_path, monkeypatch):
    from formflow import calibration as calmod
    monkeypatch.setattr(calmod, "DEFAULT_PATH", tmp_path / "c.json")
    a = App()
    h = HandInput()
    a.hand = h
    a.screen = "air"
    a.handle_key(ord("h"))
    assert a.cal.dominant == "Left" and h.cal.dominant == "Left"
    a.cal.save()
    assert Calibration.load().dominant == "Left"


def test_calibration_records_palm_ref():
    w = CalibrationWizard()
    w.i = 2
    t = 0.0
    for _ in range(60):
        w.feed(Sample(True, (0.5, 0.5), 1.0, 0.17, False, t))
        t += 1 / 30
    assert w.step == "closed" and w.data["palm"] == pytest.approx(0.17)
    w.data.update(tl=(0.2, 0.2), br=(0.8, 0.7), closed=0.1)
    assert w.result().palm_ref == pytest.approx(0.17)


def test_calibration_rejects_bad_dominant(tmp_path):
    p = tmp_path / "c.json"
    p.write_text('{"region":[0.1,0.1,0.9,0.9],"pinch_on":0.3,"pinch_off":0.4,"dominant":"Middle"}')
    assert Calibration.load(p) == Calibration()
