import struct

import numpy as np
import pytest

from formflow.shapes import (TOOLS_3D, Poly, Solid, build_item, export_scene_obj, export_scene_stl,
                             mesh_volume)

R, U = np.array([1.0, 0, 0]), np.array([0, 1.0, 0])


@pytest.mark.parametrize("kind", TOOLS_3D)
def test_solid_mesh_is_closed_and_outward(kind):
    s = Solid(kind, np.array([0.2, -0.1, 0.3]), 0.5)
    v, f = s.mesh()
    assert mesh_volume(v, f) > 0.05                         # positive volume = outward winding
    # closed manifold: every undirected edge is shared by exactly two triangles
    edges = {}
    for tri in f:
        for a, b in ((0, 1), (1, 2), (2, 0)):
            e = tuple(sorted((int(tri[a]), int(tri[b]))))
            edges[e] = edges.get(e, 0) + 1
    assert set(edges.values()) == {2}


def test_known_volumes():
    c = np.zeros(3)
    assert mesh_volume(*Solid("cube", c, 1.0).mesh()) == pytest.approx((1.6) ** 3, rel=1e-6)
    sph = mesh_volume(*Solid("sphere", c, 1.0).mesh())
    assert sph == pytest.approx(4 / 3 * np.pi, rel=0.05)
    cyl = mesh_volume(*Solid("cylinder", c, 1.0).mesh())
    assert cyl == pytest.approx(np.pi * 0.7 ** 2 * 2, rel=0.03)
    cone = mesh_volume(*Solid("cone", c, 1.0).mesh())
    assert cone == pytest.approx(np.pi * 0.7 ** 2 * 2 / 3, rel=0.03)
    pyr = mesh_volume(*Solid("pyramid", c, 1.0).mesh())
    assert pyr == pytest.approx((1.6 ** 2) * 2 / 3, rel=1e-6)


@pytest.mark.parametrize("kind", TOOLS_3D)
def test_wireframe_stays_near_solid(kind):
    s = Solid(kind, np.array([1.0, 2.0, 3.0]), 0.5)
    pts = s.hull()
    assert np.all(np.abs(pts - s.center) <= 0.55)


def test_build_item_from_drag():
    a, b = np.zeros(3), np.array([0.4, 0.3, 0.0])
    assert isinstance(build_item("cube", a, b, R, U), Solid)
    assert build_item("cube", a, b, R, U).r == pytest.approx(0.5)
    rect = build_item("rect", a, b, R, U)
    assert rect.pts.shape == (5, 3) and np.allclose(rect.pts[0], rect.pts[-1])
    assert np.allclose(rect.pts[2], b)
    circ = build_item("circle", a, b, R, U)
    assert np.allclose(np.linalg.norm(circ.pts - a, axis=1), 0.5)
    assert build_item("sphere", a, a + 0.01, R, U) is None   # tiny drag ignored


def test_translate_moves_items():
    s = Solid("cube", np.zeros(3), 1.0)
    s.translate(np.array([1.0, 0, 0]))
    assert np.allclose(s.center, [1, 0, 0])
    p = Poly("line", np.array([[0.0, 0, 0], [1, 0, 0]]))
    p.translate(np.array([0.0, 2, 0]))
    assert np.allclose(p.center, [0.5, 2, 0])


def test_export_obj_and_stl(tmp_path):
    items = [Solid("cube", np.zeros(3), 0.5), Poly("line", np.array([[0.0, 0, 0], [1, 1, 1]]))]
    obj = export_scene_obj(items, tmp_path / "s.obj").read_text()
    assert obj.count("\nv ") == 8 + 2 and obj.count("\nf ") == 12 and obj.count("\nl ") == 1
    # face indices must stay inside the vertex list
    nv = obj.count("\nv ")
    assert all(1 <= int(i) <= nv for line in obj.splitlines() if line.startswith("f ") for i in line.split()[1:])

    stl = export_scene_stl(items, tmp_path / "s.stl").read_bytes()
    assert struct.unpack("<I", stl[80:84])[0] == 12 and len(stl) == 84 + 12 * 50
    with pytest.raises(ValueError):
        export_scene_stl([items[1]], tmp_path / "x.stl")
    with pytest.raises(ValueError):
        export_scene_obj([], tmp_path / "x.obj")


# ------------------------------------------------------------ stroke normalisation
def _path_length(p):
    return float(np.linalg.norm(np.diff(p, axis=0), axis=1).sum())


def test_normalize_polyline_even_spacing_and_endpoints():
    from formflow.shapes import normalize_polyline
    rng = np.random.default_rng(1)
    t = np.concatenate([np.linspace(0, 0.3, 60), np.linspace(0.3, 1.0, 8)])    # bunched, then sparse
    raw = np.stack([t, np.sin(t * 3) * 0.2, np.zeros_like(t)], 1) + rng.normal(0, 0.004, (len(t), 3))
    out = normalize_polyline(raw, spacing=0.03)
    assert np.allclose(out[0], raw[0]) and np.allclose(out[-1], raw[-1])
    d = np.linalg.norm(np.diff(out, axis=0), axis=1)
    assert d.std() / d.mean() < 0.08                       # uniform spacing
    assert _path_length(out) < _path_length(raw)           # tremor removed


def test_normalize_polyline_keeps_shape():
    from formflow.shapes import normalize_polyline
    t = np.linspace(0, np.pi, 200)
    arc = np.stack([np.cos(t), np.sin(t), np.zeros_like(t)], 1)
    out = normalize_polyline(arc, spacing=0.04)
    assert np.abs(np.linalg.norm(out, axis=1) - 1).max() < 0.01     # still on the unit circle


def test_normalize_polyline_tiny_inputs():
    from formflow.shapes import normalize_polyline
    two = np.array([[0.0, 0, 0], [0.5, 0, 0]])
    assert np.allclose(normalize_polyline(two), two)
    dup = np.array([[0.0, 0, 0]] * 5)
    assert len(normalize_polyline(dup)) <= 5
    short = np.array([[0.0, 0, 0], [0.01, 0, 0], [0.02, 0, 0]])
    assert len(normalize_polyline(short, spacing=0.03)) == 3
