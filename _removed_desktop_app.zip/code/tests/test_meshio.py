import struct

import numpy as np
import pytest

from formflow.meshio import MeshError, decimate_for_display, fit_to_workspace, load_mesh
from formflow.shapes import Solid, export_scene_obj, export_scene_stl, mesh_volume


def cube_obj(path, scale=1.0, style="plain"):
    v = [(x, y, z) for x in (0, scale) for y in (0, scale) for z in (0, scale)]
    lines = [f"v {a} {b} {c}" for a, b, c in v]
    quads = [(1, 3, 4, 2), (5, 6, 8, 7), (1, 2, 6, 5), (3, 7, 8, 4), (1, 5, 7, 3), (2, 4, 8, 6)]
    for q in quads:
        if style == "slash":
            lines.append("f " + " ".join(f"{i}/1/1" for i in q))
        elif style == "negative":
            lines.append("f " + " ".join(str(i - 9) for i in q))
        else:
            lines.append("f " + " ".join(map(str, q)))
    path.write_text("\n".join(lines))
    return path


@pytest.mark.parametrize("style", ["plain", "slash", "negative"])
def test_obj_quads_become_triangles(tmp_path, style):
    v, f = load_mesh(cube_obj(tmp_path / "c.obj", style=style))
    assert v.shape == (8, 3) and f.shape == (12, 3)


def test_obj_ignores_comments_normals_and_groups(tmp_path):
    p = tmp_path / "t.obj"
    p.write_text("# hi\nmtllib x.mtl\no thing\nv 0 0 0\nv 1 0 0\nv 0 1 0\nvn 0 0 1\nvt 0 0\ns off\n"
                 "usemtl m\nf 1//1 2//1 3//1\n")
    v, f = load_mesh(p)
    assert len(v) == 3 and f.tolist() == [[0, 1, 2]]


def test_binary_stl_roundtrip_with_our_own_exporter(tmp_path):
    items = [Solid("sphere", np.array([0.1, 0.2, 0.3]), 0.5)]
    p = export_scene_stl(items, tmp_path / "s.stl")
    v, f = load_mesh(p)
    assert len(f) == len(items[0].mesh()[1])
    assert len(v) < 3 * len(f)                               # corners were welded
    assert abs(mesh_volume(v, f) - mesh_volume(*items[0].mesh())) < 1e-4


def test_obj_roundtrip_with_our_own_exporter(tmp_path):
    s = Solid("cube", np.zeros(3), 1.0)
    p = export_scene_obj([s], tmp_path / "c.obj")
    v, f = load_mesh(p)
    assert v.shape == (8, 3) and f.shape == (12, 3)
    assert mesh_volume(v, f) == pytest.approx(1.6 ** 3)


def test_ascii_stl(tmp_path):
    p = tmp_path / "a.stl"
    p.write_text("solid x\n facet normal 0 0 1\n  outer loop\n   vertex 0 0 0\n   vertex 1 0 0\n"
                 "   vertex 0 1 0\n  endloop\n endfacet\nendsolid x\n")
    v, f = load_mesh(p)
    assert len(v) == 3 and len(f) == 1


@pytest.mark.parametrize("body,ext,msg", [
    ("not a mesh", ".stl", "STL"),
    ("v 0 0 0\nv 1 0 0\n", ".obj", "no faces"),
    ("f 1 2 3\n", ".obj", "no vertices"),
    ("v 0 0 0\nv 1 0 0\nv 0 1 0\nf 1 2 9\n", ".obj", "does not exist"),
    ("v 0 0 0\nv 1 0 0\nv 0 1 0\nf 1 1 2\n", ".obj", "degenerate"),
    ("v a b c\n", ".obj", "Malformed"),
    ("hello", ".txt", "Only .obj"),
])
def test_bad_files_raise_clear_errors(tmp_path, body, ext, msg):
    p = tmp_path / f"bad{ext}"
    p.write_text(body)
    with pytest.raises(MeshError, match=msg):
        load_mesh(p)


def test_missing_file(tmp_path):
    with pytest.raises(MeshError, match="not found"):
        load_mesh(tmp_path / "nope.obj")


def test_truncated_binary_stl_is_rejected(tmp_path):
    data = b"\0" * 80 + struct.pack("<I", 5) + b"\0" * 50          # claims 5 triangles, has 1
    p = tmp_path / "t.stl"
    p.write_bytes(data)
    with pytest.raises(MeshError):
        load_mesh(p)


def test_fit_to_workspace_centres_and_scales_any_units():
    for unit in (0.002, 1.0, 5000.0):
        v = np.array([[0, 0, 0], [4, 0, 0], [0, 2, 0], [0, 0, 1.0]]) * unit + 123 * unit
        out, s = fit_to_workspace(v, 0.85)
        assert np.ptp(out, axis=0).max() == pytest.approx(1.7)
        assert (out.min(0) + out.max(0)) / 2 == pytest.approx([0, 0, 0], abs=1e-9)
    with pytest.raises(MeshError):
        fit_to_workspace(np.zeros((3, 3)))


def test_decimate_keeps_shape_and_budget():
    # a dense sphere
    n = 120
    a, b = np.meshgrid(np.linspace(0.05, np.pi - 0.05, n), np.linspace(0, 2 * np.pi, n, endpoint=False))
    v = np.stack([np.sin(a) * np.cos(b), np.cos(a), np.sin(a) * np.sin(b)], -1).reshape(-1, 3)
    f = []
    for i in range(n - 1):
        for j in range(n):
            p, q = i * n + j, i * n + (j + 1) % n
            f += [(p, q, p + n), (q, q + n, p + n)]
    f = np.array(f)
    dv, df = decimate_for_display(v, f, max_tris=2500)
    assert 200 < len(df) <= 2500 and df.max() < len(dv)
    r = np.linalg.norm(dv, axis=1)
    assert 0.85 < r.mean() < 1.01                          # still roughly a unit sphere
    small = decimate_for_display(v[:10], f[:5], 2500)
    assert len(small[1]) == 5                              # under budget: untouched
