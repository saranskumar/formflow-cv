import numpy as np
import pytest

from formflow import calibration as calmod
from formflow.app import App, VIEWPORT
from formflow.calibration import Calibration, Sample
from formflow.hand import HandInput
from formflow.shapes import Poly, Solid
from formflow.sketch3d import Sketch3D, export_polylines_obj
from formflow.ui import Pointer

VP = VIEWPORT


def centre():
    return VP[0] + VP[2] / 2, VP[1] + VP[3] / 2


# ------------------------------------------------------------------ engine
def test_project_unproject_roundtrip_at_any_view():
    sk = Sketch3D()
    for yaw, pitch, depth in [(0.0, 0.0, 0.0), (0.55, 0.35, 0.4), (-1.2, 0.9, -0.6)]:
        sk.yaw, sk.pitch = yaw, pitch
        p = sk.unproject(700, 300, VP, depth)
        back, _ = sk.project(p, VP)
        assert back[0] == pytest.approx([700, 300], abs=1e-6)


def test_screen_centre_hits_depth_axis():
    sk = Sketch3D()
    sk.yaw = sk.pitch = 0.0
    assert sk.unproject(*centre(), VP, 0.5) == pytest.approx([0, 0, 0.5], abs=1e-9)


def test_freehand_lifecycle_and_undo():
    sk = Sketch3D()
    sk.begin(400, 300, VP)
    for x in range(410, 600, 8):
        sk.add(x, 300 + (x % 5), VP)
    sk.end()
    assert len(sk.items) == 1 and isinstance(sk.items[0], Poly) and len(sk.items[0].pts) > 5
    sk.undo()
    assert not sk.items and sk.undo_count == 1


def test_single_tap_is_not_an_item():
    sk = Sketch3D()
    sk.begin(400, 300, VP)
    sk.end()
    sk.set_tool("cube")
    sk.begin(400, 300, VP)
    sk.end()
    assert not sk.items


@pytest.mark.parametrize("tool,cls", [("line", Poly), ("rect", Poly), ("circle", Poly), ("cube", Solid),
                                      ("sphere", Solid), ("cylinder", Solid), ("cone", Solid),
                                      ("pyramid", Solid)])
def test_every_shape_tool_creates_its_item(tool, cls):
    sk = Sketch3D()
    sk.yaw = sk.pitch = 0.0
    sk.set_tool(tool)
    sk.begin(*centre(), VP)
    assert sk.preview() is None                     # nothing to preview before dragging
    sk.add(centre()[0] + 90, centre()[1] + 40, VP)
    assert isinstance(sk.preview(), cls)            # live preview while dragging
    sk.end()
    assert len(sk.items) == 1 and isinstance(sk.items[0], cls) and sk.items[0].kind == tool


def test_solid_is_placed_at_anchor_and_sized_by_drag():
    sk = Sketch3D()
    sk.yaw = sk.pitch = 0.0
    sk.set_tool("sphere")
    sk.begin(*centre(), VP)
    sk.add(centre()[0] + 100, centre()[1], VP)
    sk.end()
    s = sk.items[0]
    assert s.center == pytest.approx([0, 0, 0], abs=1e-6)
    assert s.r == pytest.approx(100 * sk.dist / sk.focal(VP), rel=1e-6)


def test_depth_steps_clamp_and_move_the_stroke():
    sk = Sketch3D()
    sk.yaw = sk.pitch = 0.0
    for _ in range(10):
        sk.step_depth(+1)
    assert sk.depth == 1.0
    sk.begin(*centre(), VP)
    sk.add(centre()[0] + 20, centre()[1], VP)
    sk.end()
    assert sk.items[0].pts[:, 2] == pytest.approx(1.0, abs=1e-6)


def test_hand_depth_follows_palm_size_and_gain():
    def run(gain):
        sk = Sketch3D()
        sk.yaw = sk.pitch = 0.0
        sk.depth_gain = gain
        sk.toggle_depth_mode()
        sk.begin(*centre(), VP, palm=0.20)
        for i in range(30):
            sk.add(centre()[0] + 6 * i, centre()[1], VP, palm=0.20 + 0.002 * i)
        sk.end()
        return sk.items[0].pts[:, 2]
    z = run(3.0)
    assert z[-1] > z[0] + 0.1 and np.all(z <= 1.2)
    assert run(6.0)[-1] > z[-1]                      # calibrated gain scales the response


def test_move_tool_drags_the_picked_object_only():
    sk = Sketch3D()
    sk.yaw = sk.pitch = 0.0
    sk.set_tool("cube")
    sk.begin(*centre(), VP)
    sk.add(centre()[0] + 60, centre()[1], VP)
    sk.end()
    sk.set_tool("cube")
    sk.begin(centre()[0] + 150, centre()[1], VP)
    sk.add(centre()[0] + 205, centre()[1], VP)
    sk.end()
    far = sk.items[1].center.copy()
    sk.set_tool("move")
    sk.hover(*centre(), VP)
    assert sk.hot is sk.items[0]
    sk.begin(*centre(), VP)
    sk.add(centre()[0] + 80, centre()[1] - 40, VP)
    sk.end()
    assert sk.moved == 1
    assert sk.items[0].center[0] > 0.3 and sk.items[0].center[1] > 0.1
    assert sk.items[1].center == pytest.approx(far)
    sk.begin(5, 5, VP)                               # empty space: nothing to move
    sk.add(50, 50, VP)
    sk.end()
    assert sk.moved == 1


def test_orbit_accumulates_and_clamps_pitch():
    sk = Sketch3D()
    sk.orbit(100, 0)
    sk.orbit(0, 5000)
    assert sk.rotated > 1.0 and sk.pitch <= 1.45


def test_snap_quantises_points():
    sk = Sketch3D()
    sk.snap = True
    sk.begin(410, 311, VP)
    sk.add(520, 333, VP)
    sk.end()
    assert np.allclose(sk.items[0].pts / 0.1, np.round(sk.items[0].pts / 0.1))


def test_export_polylines_obj_legacy(tmp_path):
    sk = Sketch3D()
    sk.begin(400, 300, VP)
    sk.add(500, 340, VP)
    sk.end()
    text = export_polylines_obj(sk.items, tmp_path / "s.obj").read_text()
    assert text.count("\nv ") == len(sk.items[0].pts) and text.count("\nl ") == 1
    with pytest.raises(ValueError):
        export_polylines_obj([], tmp_path / "e.obj")


def test_render_all_item_types_without_error():
    img = np.zeros((720, 1280, 3), np.uint8)
    sk = Sketch3D()
    for i, tool in enumerate(["free", "line", "rect", "circle", "cube", "sphere", "cylinder", "cone", "pyramid"]):
        sk.set_tool(tool)
        sk.begin(400 + i * 60, 300, VP)
        sk.add(430 + i * 60, 360, VP)
        sk.add(450 + i * 60, 330, VP)
        sk.end()
    backdrop = np.full((720, 1280, 3), 90, np.uint8)
    sk.render(img, VP, backdrop=backdrop)
    assert img[VP[1] + 5, VP[0] + 5].tolist() != [0, 0, 0]
    assert len(sk.items) == 9 and sk.solid_count == 5


# ------------------------------------------------------------------ app level
def frame(a, x=None, y=None, down=None, grab=None):
    if x is not None:
        a.ptr.x, a.ptr.y, a.ptr.visible = x, y, True
    if down is not None:
        a.ptr.down = down
    if grab is not None:
        a.ptr.grab = grab
    a.update()
    a.render()
    a.ptr.tick()


def draw_line(a, p0, p1, n=12):
    frame(a, *p0, down=False)
    frame(a, *p0, down=True)
    for t in range(1, n + 1):
        frame(a, p0[0] + (p1[0] - p0[0]) * t / n, p0[1] + (p1[1] - p0[1]) * t / n, down=True)
    frame(a, down=False)


def press(a, bid):
    b = next(b for b in a.air_buttons if b.id == bid)
    x, y, w, h = b.rect
    frame(a, x + w / 2, y + h / 2, down=False)
    frame(a, down=True)
    frame(a, down=False)


def test_air_guide_end_to_end(tmp_path):
    a = App(export_dir=tmp_path)
    a.handle_key(ord("g"))
    assert a.guide_on and a.screen == "air"
    a.guide_ticks = 200
    frame(a, 600, 300, down=False)
    for _ in range(45):
        frame(a, 600, 300)
    assert a.step_i == 2                                   # pick a shape

    press(a, "t_cube")
    assert a.sketch.tool == "cube" and a.step_i == 3
    draw_line(a, (600, 300), (700, 340))                   # drag out a cube
    assert a.sketch.solid_count == 1 and a.step_i == 4

    frame(a, 600, 300, grab=True)
    for i in range(1, 40):
        frame(a, 600 + 6 * i, 300 + 3 * i, grab=True)
    frame(a, grab=False)
    assert a.step_i == 5 and a.sketch.rotated > 1.2

    press(a, "depth_up")
    assert a.sketch.depth == pytest.approx(0.2) and a.step_i == 6
    press(a, "t_sphere")
    draw_line(a, (900, 250), (960, 280))
    assert a.sketch.solid_count == 2 and a.step_i == 7

    press(a, "t_move")
    frame(a, 900, 250, down=False)                         # hover so the target is picked
    draw_line(a, (900, 250), (880, 330))
    assert a.sketch.moved >= 1 and a.step_i == 8
    press(a, "undo")
    assert len(a.sketch.items) == 1 and a.step_i == 9
    press(a, "export")
    assert a.exported
    assert len(list(tmp_path.glob("*.obj"))) == 1 and len(list(tmp_path.glob("*.stl"))) == 1


def test_buttons_do_not_draw():
    a = App()
    a.screen = "air"
    press(a, "snap")
    assert a.sketch.snap and not a.sketch.items


def test_tool_buttons_and_number_keys_select_tools():
    a = App()
    a.screen = "air"
    press(a, "t_pyramid")
    assert a.sketch.tool == "pyramid"
    a.handle_key(ord("1"))
    assert a.sketch.tool == "free"
    a.handle_key(ord("0"))
    assert a.sketch.tool == "move"


def test_bg_camera_toggle():
    a = App()
    a.screen = "air"
    assert a.bg_cam
    press(a, "bg")
    assert not a.bg_cam


def test_fist_orbits_instead_of_drawing():
    a = App()
    a.screen = "air"
    frame(a, 600, 300, down=False, grab=True)
    frame(a, 650, 320, down=False, grab=True)
    assert a.sketch.rotated > 0 and not a.sketch.items and not a.drawing


def test_clear_all_needs_hold():
    a = App()
    a.screen = "air"
    draw_line(a, (400, 300), (700, 360))
    press(a, "clear")
    assert len(a.sketch.items) == 1


def test_stl_only_written_when_there_are_solids(tmp_path):
    a = App(export_dir=tmp_path)
    a.screen = "air"
    draw_line(a, (400, 300), (700, 360))                   # freehand only
    press(a, "export")
    assert len(list(tmp_path.glob("*.obj"))) == 1 and not list(tmp_path.glob("*.stl"))


# --------------------------------------------------------------- camera switch
def test_camera_label_states():
    a = App()
    assert "off" in a.camera_label()
    h = HandInput()
    h.camera_index = 0
    a.hand = h
    assert a.camera_label().startswith("Camera 0")
    h.switching = True
    assert "Switching" in a.camera_label()


def test_switch_goes_to_next_working_camera(monkeypatch):
    h = HandInput()
    h.camera_index = 0
    closed = []

    class Cap:
        def release(self):
            closed.append(1)

    h._cap = Cap()
    opened = []

    def fake_open(idx):
        opened.append(idx)
        return Cap() if idx == 2 else None

    monkeypatch.setattr(h, "_open", fake_open)
    h.request_switch()
    assert h.switching
    h._do_switch()
    assert h.camera_index == 2 and opened == [1, 2] and not h.switching and closed


def test_switch_with_single_camera_returns_to_it(monkeypatch):
    h = HandInput()
    h.camera_index = 0

    class Cap:
        def release(self):
            pass

    h._cap = Cap()
    monkeypatch.setattr(h, "_open", lambda i: Cap() if i == 0 else None)
    h._do_switch()
    assert h.camera_index == 0 and h._cap is not None


# --------------------------------------------------------------- calibration UI
def scripted_hand(monkeypatch):
    h = HandInput()
    h.preview = np.zeros((720, 1280, 3), np.uint8)
    cur = [Sample(False)]
    monkeypatch.setattr(h, "sample", lambda: cur[0])
    return h, cur


def feed(a, cur, secs, t0, **kw):
    t, fps = t0, 30
    for _ in range(int(secs * fps) + 1):
        cur[0] = Sample(True, kw.get("pos", (0.5, 0.5)), kw.get("ratio", 0.9), kw.get("palm", 0.2),
                        kw.get("fist", False), t)
        a.update()
        a.render()
        a.ptr.tick()
        t += 1 / fps
    return t + 1


def test_calibration_requires_camera():
    a = App()
    a.start_calibration()
    assert a.screen == "menu" and "camera" in a.message[0].lower()


def test_calibration_screen_full_run_saves_and_applies(tmp_path, monkeypatch):
    monkeypatch.setattr(calmod, "DEFAULT_PATH", tmp_path / "cal.json")
    a = App()
    a.hand, cur = scripted_hand(monkeypatch)
    a.screen = "menu"
    a.handle_key(ord("k"))
    assert a.screen == "calib" and a.wizard.step == "tl"

    t = feed(a, cur, 1.5, 0.0, pos=(0.2, 0.2))
    t = feed(a, cur, 1.5, t, pos=(0.8, 0.7))
    t = feed(a, cur, 1.5, t, ratio=1.0)
    t = feed(a, cur, 1.5, t, ratio=0.1)
    t = feed(a, cur, 1.2, t, fist=True)
    assert a.wizard.step == "depth"
    tt = t
    for i in range(int(5.3 * 30)):
        cur[0] = Sample(True, (0.5, 0.5), 0.9, 0.15 + 0.15 * abs((i % 60) - 30) / 30, False, tt)
        a.update()
        a.render()
        tt += 1 / 30
    assert a.wizard.step == "test"
    assert a.hand.region[0] < 0.25                          # measured reach applied live

    b = a.calib_buttons["c_snap"]
    before = a._test_smooth
    x, y, w, h = b.rect
    frame(a, x + w / 2, y + h / 2, down=False)
    frame(a, down=True)
    frame(a, down=False)
    assert a._test_smooth > before

    b = a.calib_buttons["c_done"]
    x, y, w, h = b.rect
    frame(a, x + w / 2, y + h / 2, down=False)
    frame(a, down=True)
    frame(a, down=False)
    assert a.screen == "menu" and a.cal.calibrated
    assert Calibration.load(tmp_path / "cal.json").calibrated
    assert a.sketch.depth_gain == pytest.approx(a.cal.depth_gain)


def test_calibration_cancel_restores_previous(tmp_path, monkeypatch):
    monkeypatch.setattr(calmod, "DEFAULT_PATH", tmp_path / "cal.json")
    a = App(calibration=Calibration(region=(0.2, 0.2, 0.8, 0.8), calibrated=True))
    a.hand, _ = scripted_hand(monkeypatch)
    a.start_calibration()
    assert a.hand.region == (0.0, 0.0, 1.0, 1.0)
    a.handle_key(27)
    assert a.screen == "menu" and a.hand.region == (0.2, 0.2, 0.8, 0.8)
    assert not (tmp_path / "cal.json").exists()
