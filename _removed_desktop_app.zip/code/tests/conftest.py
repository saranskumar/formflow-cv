import platform

# Same guard as formflow/__init__.py: this must run before numpy is imported by any test module.
if hasattr(platform, "_wmi_query"):
    def _no_wmi(*_a, **_k):
        raise OSError("WMI disabled")
    platform._wmi_query = _no_wmi
