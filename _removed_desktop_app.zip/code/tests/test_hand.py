import numpy as np

from formflow.hand import GestureDecoder, OneEuro, HandInput
from formflow.ui import Button, Pointer


def hand(pinch_gap=0.9, curled=False):
    """Synthetic 21-landmark hand; palm size = 1.0 (wrist->middle MCP)."""
    lm = np.zeros((21, 3))
    lm[0] = (0, 0, 0)
    lm[9] = (0, -1, 0)                       # middle MCP
    lm[4] = (-pinch_gap / 2, -1.5, 0)        # thumb tip
    lm[8] = (pinch_gap / 2, -1.5, 0)         # index tip
    for tip, pip in zip((8, 12, 16, 20), (6, 10, 14, 18)):
        lm[pip] = (0, -1.2, 0)
        lm[tip] = (0, -0.6 if curled else -2.0, 0)
    lm[8] = (pinch_gap / 2, -1.5 if not curled else -0.6, 0)
    return lm


def test_pinch_hysteresis_and_debounce():
    d = GestureDecoder(on=0.30, off=0.45, debounce=2)
    t = 0.0
    for gap in (0.9, 0.9):
        assert not d.step(hand(gap), t)[0]
    assert not d.step(hand(0.1), t)[0]              # first closed frame: debounced
    assert d.step(hand(0.1), t)[0]                  # second: pinching
    assert d.step(hand(0.40), t)[0]                 # between thresholds: stays pinched
    d.step(hand(0.9), t)
    assert not d.step(hand(0.9), t)[0]              # clearly open: released


def test_single_noisy_frame_does_not_toggle():
    d = GestureDecoder(debounce=2)
    for _ in range(3):
        d.step(hand(0.9), 0)
    assert not d.step(hand(0.05), 0)[0]
    assert not d.step(hand(0.9), 0)[0]


def test_pinch_is_scale_invariant():
    d = GestureDecoder()
    small = hand(0.1) * 0.3
    for _ in range(3):
        assert d.step(small, 0)[0] or True
    assert d.pinching


def test_fist_hold_fires_once():
    d = GestureDecoder(fist_hold=0.7)
    fired = [d.step(hand(0.9, curled=True), t)[1] for t in (0.0, 0.3, 0.8, 1.2, 2.0)]
    assert fired == [False, False, True, False, False]
    d.step(hand(0.9), 3.0)                           # open the hand: re-arms
    assert [d.step(hand(0.9, curled=True), t)[1] for t in (4.0, 4.8)] == [False, True]


def test_one_euro_smooths_jitter_but_follows_motion():
    f = OneEuro()
    rng = np.random.default_rng(0)
    out = [f(np.array([0.5, 0.5]) + rng.normal(0, 0.004, 2), i / 30) for i in range(60)]
    assert np.std([o[0] for o in out[20:]]) < 0.004          # still: jitter reduced
    f = OneEuro()
    for i in range(30):
        last = f(np.array([i * 0.03, 0.5]), i / 30)
    assert abs(last[0] - 29 * 0.03) < 0.08                    # fast sweep: small lag


def test_hand_pointer_mapping_and_loss():
    from formflow.hand import Reading
    h = HandInput(screen=(1000, 500), region=(0.0, 0.0, 1.0, 1.0))
    h.cam_aspect = 2.0                                       # same aspect as the screen: no correction
    h._read["main"] = Reading(np.array([0.5, 0.25]), True, False, 0.2, 0.1, 0.0)
    p = Pointer()
    h.update(p)
    assert (p.x, p.y, p.down, p.source) == (500, 125, True, "hand")
    h._read["main"] = None
    h._seen["main"] -= 1.0
    h._lost_at -= 1.0
    h.update(p)
    assert not p.down and not p.visible


def test_hovering_never_selects_a_button():
    """Selection is an intentional pinch only: no dwell-to-select."""
    b = Button("x", "X", (0, 0, 100, 50))
    p = Pointer(x=10, y=10, visible=True, source="hand")
    assert not any(b.update(p, t / 10) for t in range(0, 100))        # 10 s of hovering
    p.down = True                                                      # pinch
    assert b.update(p, 11.0)
    p.prev_down = True
    assert not b.update(p, 11.1)                                       # holding the pinch does not repeat
