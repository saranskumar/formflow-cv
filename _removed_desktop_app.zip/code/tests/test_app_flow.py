"""Drive the whole app headlessly through a Pointer, the way mouse/hand would."""
import cv2

from formflow import app as appmod
from formflow.app import App, CANVAS_XY, CANVAS_PX


def screen(pt):
    s = CANVAS_PX / 512
    return CANVAS_XY[0] + pt[0] * s, CANVAS_XY[1] + pt[1] * s


def frame(a, x=None, y=None, down=None):
    if x is not None:
        a.ptr.x, a.ptr.y, a.ptr.visible = x, y, True
    if down is not None:
        a.ptr.down = down
    a.update()
    a.render()
    a.ptr.tick()


def draw_poly(a, poly):
    pts = poly + [poly[0]]
    frame(a, *screen(pts[0]), down=False)
    frame(a, *screen(pts[0]), down=True)
    for p, q in zip(pts, pts[1:]):
        for t in range(1, 11):
            x = p[0] + (q[0] - p[0]) * t / 10
            y = p[1] + (q[1] - p[1]) * t / 10
            frame(a, *screen((x, y)), down=True)
    frame(a, down=False)


def click(a, bid):
    pool = a.menu_buttons if a.screen == "menu" else a.buttons
    b = next(b for b in pool if b.id == bid)
    x, y, w, h = b.rect
    frame(a, x + w / 2, y + h / 2, down=False)
    frame(a, down=True)
    frame(a, down=False)


def test_full_flow_with_guide(tmp_path, monkeypatch):
    monkeypatch.setattr(App, "show_mesh", lambda self, m: None)
    a = App(export_dir=tmp_path)
    a.start_guide("multiview")                           # three-view builder is hidden from the menu
    assert a.guide_on and a.screen == "build"
    a.guide_ticks = 200                                  # skip the welcome pause
    frame(a)
    assert a.step_i == 1

    draw_poly(a, [(100, 100), (200, 100), (200, 300), (400, 300), (400, 400), (100, 400)])
    frame(a)
    assert a.canvases["front"].silhouette.closed
    assert a.step_i >= 3

    click(a, "top")
    draw_poly(a, [(100, 150), (400, 150), (400, 350), (100, 350)])
    click(a, "side")
    draw_poly(a, [(150, 100), (350, 100), (350, 400), (150, 400)])
    frame(a)
    assert a.step_i == 5 and a.warnings() == []

    click(a, "build")
    assert a.mesh is not None
    frame(a)
    click(a, "export")
    assert a.exported
    assert len(list(tmp_path.glob("*.obj"))) == 1 and len(list(tmp_path.glob("*.stl"))) == 1


def test_guide_can_be_skipped():
    a = App()
    click(a, "guide")
    assert a.guide_on and a.screen == "air"
    a.handle_key(27)
    assert not a.guide_on and a.screen == "air"


def test_clear_requires_hold():
    a = App()
    a.screen = "build"
    draw_poly(a, [(100, 100), (300, 100), (300, 300), (100, 300)])
    assert a.canvases["front"].has_ink
    click(a, "clear")                                    # a quick click must not clear
    assert a.canvases["front"].has_ink
