import cv2
import numpy as np
import pytest

from formflow.silhouette import extract_silhouette
from formflow.validation import check_consistency, align_views
from formflow.reconstruction import build_visual_hull, volume_to_mesh
from formflow.exporter import export_mesh, mesh_report

N = 96


def outline(poly, size=512, thick=4):
    img = np.zeros((size, size), np.uint8)
    cv2.polylines(img, [np.array(poly, np.int32)], True, 255, thick)
    return img


def rect(x0, y0, x1, y1):
    return [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]


def l_views():
    """L-bracket: Front is L-shaped (tall column left, foot along the bottom)."""
    front = outline([(100, 100), (200, 100), (200, 300), (400, 300), (400, 400), (100, 400)])
    top = outline(rect(100, 150, 400, 350))
    side = outline(rect(150, 100, 350, 400))
    return [extract_silhouette(v) for v in (front, top, side)]


def test_silhouette_closed_and_filled():
    s = extract_silhouette(outline(rect(100, 100, 300, 250)))
    assert s.closed and s.mask[175, 200] == 255
    assert s.bbox[2] == pytest.approx(204, abs=6)


def test_silhouette_gap_is_repaired():
    img = outline(rect(100, 100, 300, 250))
    cv2.line(img, (200, 98), (204, 98), 0, 9)   # punch a ~13 px gap in the top edge
    assert extract_silhouette(img).closed


def test_open_outline_not_closed():
    img = np.zeros((512, 512), np.uint8)
    cv2.polylines(img, [np.array([(100, 100), (300, 100), (300, 300)], np.int32)], False, 255, 4)
    assert not extract_silhouette(img).closed


def test_consistency_pass_and_fail():
    f, t, s = l_views()
    assert check_consistency(f, t, s) == []
    wide_top = extract_silhouette(outline(rect(50, 150, 460, 350)))
    assert any("Width" in w for w in check_consistency(f, wide_top, s))


def test_l_bracket_hull_shape_and_iou():
    f, t, s = l_views()
    hull = build_visual_hull(*align_views(f, t, s, N))
    assert hull.voxels > 0
    assert min(hull.iou.values()) > 0.95
    v = hull.volume
    xs = np.where(v.any(axis=(1, 2)))[0]
    ys = np.where(v.any(axis=(0, 2)))[0]
    mid_z = v.shape[2] // 2
    # Y is up: the foot spans full width at the bottom, the column stays on the left
    assert v[xs.max() - 2, ys.min() + 2, mid_z]        # right end of the foot
    assert not v[xs.max() - 2, ys.max() - 2, mid_z]    # empty above the foot, right side
    assert v[xs.min() + 2, ys.max() - 2, mid_z]        # top of the column, left side


def test_axes_asymmetric_orientation():
    """Distinct W/H/D must land on the right voxel axes."""
    def box(w, h):
        return extract_silhouette(
            outline(rect(256 - w // 2, 256 - h // 2, 256 + w // 2, 256 + h // 2)))
    W, H, D = 300, 100, 200
    hull = build_visual_hull(*align_views(box(W, H), box(W, D), box(D, H), N))
    x, y, z = [int(np.ptp(np.where(hull.volume.any(axis=a))[0])) + 1
               for a in [(1, 2), (0, 2), (0, 1)]]
    assert x > z > y


def test_mesh_export_roundtrip(tmp_path):
    import open3d as o3d
    f, t, s = l_views()
    mesh = volume_to_mesh(build_visual_hull(*align_views(f, t, s, N)).volume)
    rep = mesh_report(mesh)
    assert rep["watertight"] and rep["triangles"] > 100
    for ext in (".obj", ".stl"):
        p = export_mesh(mesh, tmp_path / f"m{ext}")
        assert len(o3d.io.read_triangle_mesh(str(p)).triangles) > 0


def test_empty_volume_raises():
    with pytest.raises(ValueError):
        volume_to_mesh(np.zeros((8, 8, 8), bool))
