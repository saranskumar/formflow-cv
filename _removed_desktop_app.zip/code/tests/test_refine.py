"""Refinement round: strict hand selection, no dwell, release commit, two-hand navigation, model import."""
import struct

import numpy as np
import pytest

from formflow.app import App, VIEWPORT
from formflow.hand import COLOR_MAIN, COLOR_SECOND, select_user_hands
from formflow.meshio import MeshError
from formflow.shapes import ImportedMesh, Poly, Solid, export_scene_obj, export_scene_stl, mesh_volume
from formflow.sketch3d import Sketch3D
from formflow.ui import Pointer

VP = VIEWPORT


def centre():
    return VP[0] + VP[2] / 2, VP[1] + VP[3] / 2


# ------------------------------------------------------------- hand selection
def fake_hand(wrist_x, size, y=0.6):
    lm = np.zeros((21, 3))
    lm[0] = (wrist_x, y, 0)
    lm[9] = (wrist_x, y - size, 0)
    return lm


def test_colours_are_cyan_and_magenta_in_bgr():
    assert COLOR_MAIN == (255, 255, 0) and COLOR_SECOND == (255, 0, 255)


def test_background_person_is_ignored():
    user_r, user_l = ("Right", fake_hand(0.7, 0.14)), ("Left", fake_hand(0.3, 0.13))
    far = ("Right", fake_hand(0.5, 0.05))                      # someone behind: small hands
    assert select_user_hands([far, user_r, user_l]) == [1, 2]  # both user hands, in size order
    assert select_user_hands([far]) == [0]                     # alone, a small hand is still the only candidate
    assert select_user_hands([user_r, far]) == [0]             # too small to be the second hand


def test_never_more_than_two_hands():
    hands = [("Right", fake_hand(0.7, 0.14)), ("Left", fake_hand(0.3, 0.13)),
             ("Right", fake_hand(0.5, 0.12)), ("Left", fake_hand(0.1, 0.12))]
    assert len(select_user_hands(hands)) == 2


def test_tiny_far_hands_are_dropped_even_if_alone():
    assert select_user_hands([("Right", fake_hand(0.5, 0.02))]) == []


def test_same_label_pair_accepted_only_when_apart_and_comparable():
    a, b = ("Right", fake_hand(0.7, 0.14)), ("Right", fake_hand(0.3, 0.13))
    assert select_user_hands([a, b]) == [0, 1]                 # one person, mislabelled
    close = ("Right", fake_hand(0.72, 0.13))
    assert select_user_hands([a, close]) == [0]                # overlapping duplicate detection
    small = ("Right", fake_hand(0.3, 0.07))
    assert select_user_hands([a, small]) == [0]                # same label and much smaller: a bystander


def test_hand_near_previous_position_is_preferred():
    left_big = ("Left", fake_hand(0.2, 0.125))
    right = ("Right", fake_hand(0.8, 0.13))
    assert select_user_hands([left_big, right], prev_main=(0.2, 0.6))[0] == 0
    assert select_user_hands([left_big, right], prev_main=None)[0] == 1


# ------------------------------------------------------------- no dwell in the app
def frame(a):
    a.update()
    a.render()
    a.ptr.tick()
    a.ptr2.prev_down = a.ptr2.down


def hover(a, bid, secs=3.0):
    b = next(b for b in a.air_buttons if b.id == bid)
    x, y, w, h = b.rect
    a.ptr.source, a.ptr.visible, a.ptr.down = "hand", True, False
    a.ptr.x, a.ptr.y = x + w / 2, y + h / 2
    import time as _t
    t0 = _t.time()
    while _t.time() - t0 < secs:
        frame(a)
        _t.sleep(0.05)


def test_hovering_a_tool_button_does_not_select_it():
    a = App()
    a.screen = "air"
    hover(a, "t_cube", 1.6)
    assert a.sketch.tool == "free"


def test_pinching_a_tool_button_selects_it():
    a = App()
    a.screen = "air"
    b = next(b for b in a.air_buttons if b.id == "t_cube")
    x, y, w, h = b.rect
    a.ptr.source, a.ptr.visible = "hand", True
    a.ptr.x, a.ptr.y, a.ptr.down = x + w / 2, y + h / 2, False
    frame(a)
    a.ptr.down = True
    frame(a)
    assert a.sketch.tool == "cube"


# ------------------------------------------------------------- release commit
def test_dropped_object_stays_where_it_was_let_go():
    sk = Sketch3D()
    sk.yaw = sk.pitch = 0.0
    sk.set_tool("cube")
    sk.begin(*centre(), VP)
    sk.add(centre()[0] + 60, centre()[1], VP)
    sk.end()
    sk.set_tool("move")
    t0 = 1000.0
    sk.begin(*centre(), VP)
    sk._drag_hist.clear()
    sk._drag_hist.append((t0, sk.items[0].snapshot()))
    x = centre()[0]
    for i in range(1, 31):                                    # steady carry to the right
        x += 3
        sk.add(x, centre()[1], VP, now=t0 + i / 30)
    held = sk.items[0].center.copy()
    for i in range(31, 36):                                   # fingers open: the hand drifts away
        x += 14
        sk.add(x, centre()[1] + (i - 30) * 9, VP, now=t0 + i / 30)
    assert sk.items[0].center[0] > held[0] + 0.1              # the drift really did move it...
    sk.end(trim=0.15, now=t0 + 35 / 30)
    assert np.linalg.norm(sk.items[0].center - held) < 0.06   # ...and the release commit undid the drift


def test_short_drag_is_not_erased_by_the_release_rewind():
    sk = Sketch3D()
    sk.yaw = sk.pitch = 0.0
    sk.set_tool("cube")
    sk.begin(*centre(), VP)
    sk.add(centre()[0] + 60, centre()[1], VP)
    sk.end()
    sk.set_tool("move")
    before = sk.items[0].center.copy()
    sk.begin(*centre(), VP)
    sk.add(centre()[0] + 40, centre()[1], VP)
    sk.end(trim=0.5)                                          # whole drag is inside the rewind window
    assert sk.items[0].center[0] > before[0] + 0.05


def test_input_is_ignored_for_a_moment_after_release():
    a = App()
    a.screen = "air"
    a.sketch.set_tool("cube")
    a.ptr.source, a.ptr.visible = "hand", True
    a.ptr.x, a.ptr.y, a.ptr.down = 600, 300, True
    frame(a)
    a.ptr.x = 680
    frame(a)
    a.ptr.down = False
    frame(a)                                                  # release: gesture committed, freeze starts
    assert len(a.sketch.items) == 1 and a._freeze_until > 0
    a.ptr.x, a.ptr.y, a.ptr.down = 700, 340, True             # a jittery re-pinch right away
    frame(a)
    assert not a.drawing
    a._freeze_until = 0.0
    a.ptr.down = False
    frame(a)
    a.ptr.down = True
    frame(a)
    assert a.drawing                                          # after the pause it works normally


def test_mouse_has_no_release_freeze():
    a = App()
    a.screen = "air"
    a.ptr.x, a.ptr.y, a.ptr.visible, a.ptr.down = 600, 300, True, True
    frame(a)
    a.ptr.x = 680
    frame(a)
    a.ptr.down = False
    frame(a)
    assert a._freeze_until == 0.0


# ------------------------------------------------------------- scale tool, cancel, pan
def test_scale_tool_grows_and_shrinks_and_clamps():
    sk = Sketch3D()
    sk.yaw = sk.pitch = 0.0
    sk.set_tool("sphere")
    sk.begin(*centre(), VP)
    sk.add(centre()[0] + 60, centre()[1], VP)
    sk.end()
    r0 = sk.items[0].r
    sk.set_tool("scale")
    sk.begin(*centre(), VP)
    for i in range(1, 11):
        sk.add(centre()[0], centre()[1] - 10 * i, VP)           # drag up
    assert sk.items[0].r > r0 * 1.5
    for i in range(1, 80):
        sk.add(centre()[0], centre()[1] + 30 * i, VP)           # drag far down
    sk.end()
    assert 0.03 <= sk.items[0].r < r0


def test_cancel_rewinds_a_drag_and_discards_a_stroke():
    sk = Sketch3D()
    sk.yaw = sk.pitch = 0.0
    sk.set_tool("cube")
    sk.begin(*centre(), VP)
    sk.add(centre()[0] + 60, centre()[1], VP)
    sk.end()
    start = sk.items[0].center.copy()
    sk.set_tool("move")
    sk.begin(*centre(), VP)
    sk.add(centre()[0] + 100, centre()[1] + 50, VP)
    assert np.linalg.norm(sk.items[0].center - start) > 0.1
    sk.cancel()
    assert np.allclose(sk.items[0].center, start)
    sk.set_tool("free")
    sk.begin(500, 300, VP)
    sk.add(600, 330, VP)
    sk.cancel()
    sk.end()
    assert len(sk.items) == 1


def test_pan_moves_the_view_and_the_scene_follows_the_hands():
    sk = Sketch3D()
    sk.yaw = sk.pitch = 0.0
    p0, _ = sk.project(np.zeros(3), VP)
    sk.pan(100, 0, VP)                                          # hands move 100 px to the right
    p1, _ = sk.project(np.zeros(3), VP)
    assert p1[0, 0] == pytest.approx(p0[0, 0] + 100, abs=1.0)  # the origin follows the hands
    assert p1[0, 1] == pytest.approx(p0[0, 1], abs=1.0)
    sk.pan(0, -60, VP)
    p2, _ = sk.project(np.zeros(3), VP)
    assert p2[0, 1] == pytest.approx(p1[0, 1] - 60, abs=1.0)
    sk.reset_view()
    assert np.allclose(sk.target, 0)
    for _ in range(100):
        sk.pan(500, 500, VP)
    assert np.abs(sk.target).max() <= 2.5                       # cannot lose the scene


def test_drawing_still_lands_under_the_cursor_after_panning():
    sk = Sketch3D()
    sk.pan(80, -40, VP)
    sk.yaw, sk.pitch = 0.3, 0.2
    sk.begin(700, 280, VP)
    sk.add(760, 300, VP)
    sk.end()
    back, _ = sk.project(sk.items[0].pts[0], VP)
    assert back[0] == pytest.approx([700, 280], abs=1.0)


# ------------------------------------------------------------- two-hand zoom and pan
def two_hands(a, x1, y1, x2, y2, down=True):
    for ptr, x, y in ((a.ptr, x1, y1), (a.ptr2, x2, y2)):
        ptr.source, ptr.visible, ptr.down, ptr.grab = "hand", True, down, False
        ptr.x, ptr.y = x, y
    frame(a)


def test_pinching_both_hands_apart_zooms_in_and_together_zooms_out():
    a = App()
    a.screen = "air"
    two_hands(a, 600, 400, 800, 400)
    d0 = a.sketch.dist
    for i in range(1, 25):
        two_hands(a, 600 - 6 * i, 400, 800 + 6 * i, 400)          # hands spread apart
    assert a.sketch.dist < d0 * 0.7
    zoomed = a.sketch.dist
    for i in range(1, 60):
        two_hands(a, 456 + 5 * i, 400, 944 - 5 * i, 400)          # hands come together
    assert a.sketch.dist > zoomed * 1.4


def test_pinching_both_hands_and_moving_in_parallel_pans_without_zooming():
    a = App()
    a.screen = "air"
    two_hands(a, 600, 400, 800, 400)
    d0 = a.sketch.dist
    for i in range(1, 20):
        two_hands(a, 600 + 8 * i, 400 - 3 * i, 800 + 8 * i, 400 - 3 * i)
    assert np.linalg.norm(a.sketch.target) > 0.2
    assert a.sketch.dist == pytest.approx(d0, rel=0.02)


def test_two_hand_gesture_cancels_a_stray_stroke_and_blocks_drawing():
    a = App()
    a.screen = "air"
    a.ptr.source, a.ptr.visible, a.ptr.down = "hand", True, True
    a.ptr.x, a.ptr.y = 600, 300
    frame(a)
    a.ptr.x = 650
    frame(a)
    assert a.drawing
    two_hands(a, 650, 300, 900, 300)                              # second hand pinches
    assert not a.drawing and not a.sketch.items and a.sketch.active is None


def test_after_two_hand_navigation_a_lingering_pinch_does_not_start_drawing():
    a = App()
    a.screen = "air"
    two_hands(a, 600, 400, 800, 400)
    two_hands(a, 610, 400, 810, 400)
    a.ptr2.down = False                                           # second hand lets go first
    frame(a)
    a.ptr.x += 20
    frame(a)
    assert not a.drawing and not a.sketch.items


def test_single_pinch_of_second_hand_does_nothing():
    a = App()
    a.screen = "air"
    d0 = a.sketch.dist
    a.ptr2.visible, a.ptr2.down, a.ptr2.source = True, True, "hand"
    a.ptr2.x, a.ptr2.y = 300, 400
    frame(a)
    for i in range(10):
        a.ptr2.y -= 15
        frame(a)
    assert a.sketch.dist == d0 and np.allclose(a.sketch.target, 0)


def test_mouse_middle_drag_pans():
    a = App()
    a.screen = "air"
    a.ptr.visible, a.ptr.pan = True, True
    a.ptr.x, a.ptr.y = 600, 400
    frame(a)
    for i in range(1, 8):
        a.ptr.x += 20
        frame(a)
    assert np.linalg.norm(a.sketch.target) > 0.1


# ------------------------------------------------------------- importing models
def write_cube_obj(path, size=1.0, offset=0.0):
    v = [(x * size + offset, y * size + offset, z * size + offset) for x in (0, 1) for y in (0, 1) for z in (0, 1)]
    quads = [(1, 3, 4, 2), (5, 6, 8, 7), (1, 2, 6, 5), (3, 7, 8, 4), (1, 5, 7, 3), (2, 4, 8, 6)]
    path.write_text("\n".join([f"v {a} {b} {c}" for a, b, c in v] +
                              ["f " + " ".join(map(str, q)) for q in quads]))
    return path


def test_imported_model_is_fitted_centred_and_interactable(tmp_path):
    for size in (0.01, 1.0, 900.0):
        p = write_cube_obj(tmp_path / f"c{size}.obj", size, offset=37 * size)
        m = ImportedMesh.from_file(p)
        v, f = m.mesh()
        assert np.ptp(v, axis=0).max() == pytest.approx(1.7)           # fits the grid whatever the units
        assert v.mean(0) == pytest.approx([0, 0, 0], abs=1e-9)
        assert m.volumetric and len(f) == 12


def test_app_import_places_selects_move_and_reports(tmp_path):
    a = App()
    a.screen = "air"
    a.sketch.target = np.array([0.4, 0.1, 0.0])
    item = a.import_model(write_cube_obj(tmp_path / "part.obj"))
    assert item is not None and a.sketch.items == [item]
    assert np.allclose(item.center, [0.4, 0.1, 0.0])                  # appears where the camera looks
    assert a.sketch.tool == "move" and "Imported part" in a.message[0]
    assert a.sketch.solid_count == 1


def test_import_errors_do_not_crash_or_add_anything(tmp_path):
    a = App()
    a.screen = "air"
    bad = tmp_path / "bad.obj"
    bad.write_text("v 0 0 0\n")
    assert a.import_model(bad) is None and not a.sketch.items and "Import failed" in a.message[0]
    assert a.import_model(tmp_path / "missing.stl") is None and "Import failed" in a.message[0]


def test_import_button_uses_the_file_dialog_and_cancel_is_safe(tmp_path, monkeypatch):
    a = App()
    a.screen = "air"
    monkeypatch.setattr(App, "pick_file", lambda self: None)            # user pressed Cancel
    a.act_air("import")
    assert not a.sketch.items
    p = write_cube_obj(tmp_path / "k.obj")
    monkeypatch.setattr(App, "pick_file", lambda self: str(p))
    a.act_air("import")
    assert len(a.sketch.items) == 1


def test_imported_model_can_be_moved_scaled_undone_and_exported(tmp_path):
    a = App(export_dir=tmp_path)
    a.screen = "air"
    a.sketch.yaw = a.sketch.pitch = 0.0
    m = a.import_model(write_cube_obj(tmp_path / "m.obj"))
    sk = a.sketch
    s0 = m.s
    sk.set_tool("scale")
    sk.begin(*centre(), VP)
    for i in range(1, 8):
        sk.add(centre()[0], centre()[1] - 12 * i, VP)
    sk.end()
    assert m.s > s0 * 1.4
    sk.set_tool("move")
    c0 = m.center.copy()
    sk.begin(*centre(), VP)
    sk.add(centre()[0] + 70, centre()[1], VP)
    sk.end()
    assert m.center[0] > c0[0] + 0.1
    a.export_sketch()
    obj = next(tmp_path.glob("*.obj"))
    stl = next(tmp_path.glob("*.stl"))                                  # imported solids reach the STL
    assert obj.read_text().count("\nf ") == 12
    assert struct.unpack("<I", stl.read_bytes()[80:84])[0] == 12
    sk.undo()
    assert not sk.items


def test_imported_mesh_renders_and_highlights(tmp_path):
    a = App()
    a.screen = "air"
    m = a.import_model(write_cube_obj(tmp_path / "r.obj"))
    a.sketch.hover(*centre(), VP)
    img = a.render()
    assert a.sketch.hot is m
    assert img[VP[1] + 5:VP[1] + VP[3] - 5, VP[0] + 5:VP[0] + VP[2] - 5].std() > 5


def test_huge_import_stays_fast_to_draw(tmp_path):
    import time
    n = 90
    a_, b_ = np.meshgrid(np.linspace(0.05, np.pi - 0.05, n), np.linspace(0, 2 * np.pi, n, endpoint=False))
    v = np.stack([np.sin(a_) * np.cos(b_), np.cos(a_), np.sin(a_) * np.sin(b_)], -1).reshape(-1, 3)
    f = []
    for i in range(n - 1):
        for j in range(n):
            p, q = i * n + j, i * n + (j + 1) % n
            f += [(p, q, p + n), (q, q + n, p + n)]
    f = np.array(f)
    path = tmp_path / "big.obj"
    path.write_text("\n".join([f"v {x} {y} {z}" for x, y, z in v] + [f"f {a+1} {b+1} {c+1}" for a, b, c in f]))
    m = ImportedMesh.from_file(path)
    assert len(m.faces) == len(f) and len(m.disp_f) <= 1200            # export keeps everything, display is light
    sk = Sketch3D()
    sk.add_item(m)
    img = np.zeros((720, 1280, 3), np.uint8)
    sk.render(img, VP)
    t = time.perf_counter()
    for _ in range(10):
        sk.render(img, VP)
    assert (time.perf_counter() - t) / 10 < 0.06


def test_import_model_cli_flag_loads_at_start(tmp_path, monkeypatch):
    from formflow import __main__ as entry
    seen = {}
    monkeypatch.setattr(App, "run", lambda self: seen.setdefault("screen", self.screen) and None)
    monkeypatch.setattr(App, "import_model", lambda self, path=None: seen.setdefault("path", path))
    monkeypatch.setattr("sys.argv", ["formflow", "--mouse", "--import-model", "x.obj"])
    entry.main()
    assert seen["path"] == "x.obj"


def test_quick_flick_shorter_than_the_release_rewind_still_makes_its_shape():
    sk = Sketch3D()
    sk.yaw = sk.pitch = 0.0
    sk.set_tool("cube")
    sk.begin(*centre(), VP)
    sk._cursor_hist.clear()
    sk.add(centre()[0] + 25, centre()[1] + 10, VP, now=10.03)
    sk.add(centre()[0] + 60, centre()[1] + 20, VP, now=10.06)
    sk.end(trim=0.10, now=10.08)                      # whole drag inside the rewind window
    assert len(sk.items) == 1 and sk.items[0].r > 0.1
