import pytest

from formflow.calibration import Calibration, CalibrationWizard, Sample


def hold(w, secs, cur, ratio=0.9, palm=0.2, fist=False, t0=0.0, fps=30, present=True):
    t = t0
    for _ in range(int(secs * fps) + 1):
        w.feed(Sample(present, cur, ratio, palm, fist, t))
        t += 1 / fps
    return t


def test_full_wizard_computes_calibration():
    w = CalibrationWizard()
    t = hold(w, 1.5, (0.2, 0.2))
    assert w.step == "br"
    t = hold(w, 1.5, (0.8, 0.7), t0=t + 1)
    assert w.step == "open"
    t = hold(w, 1.5, (0.5, 0.5), ratio=1.0, t0=t + 1)
    assert w.step == "closed"
    t = hold(w, 1.5, (0.5, 0.5), ratio=0.1, t0=t + 1)
    assert w.step == "fist"
    t = hold(w, 1.2, (0.5, 0.5), fist=True, t0=t + 1)
    assert w.step == "depth"
    # near/far sweep over the 5 s window
    tt = t + 1
    for i in range(int(5.2 * 30)):
        w.feed(Sample(True, (0.5, 0.5), 0.9, 0.15 + 0.15 * abs((i % 60) - 30) / 30, False, tt))
        tt += 1 / 30
    assert w.step == "test"

    c = w.result()
    assert c.calibrated
    assert c.region[0] < 0.2 and c.region[2] > 0.8 and c.region[1] < 0.2 and c.region[3] > 0.7
    assert c.pinch_on == pytest.approx(0.1 + 0.3 * 0.9, abs=0.02) and c.pinch_off > c.pinch_on
    assert 1.5 <= c.depth_gain <= 8.0


def test_moving_hand_does_not_confirm():
    w = CalibrationWizard()
    t = 0.0
    for i in range(120):
        w.feed(Sample(True, (0.1 + 0.005 * i, 0.3), 0.9, 0.2, False, t))
        t += 1 / 30
    assert w.step == "tl"


def test_losing_hand_resets_progress():
    w = CalibrationWizard()
    hold(w, 0.9, (0.2, 0.2))
    assert w.progress > 0.5
    w.feed(Sample(False, t=1.0))
    assert w.progress == 0 and "hand" in w.message.lower()


def test_second_corner_must_differ_from_first():
    w = CalibrationWizard()
    t = hold(w, 1.5, (0.2, 0.2))
    hold(w, 1.5, (0.22, 0.21), t0=t + 1)
    assert w.step == "br" and "bottom-right" in w.message.lower()


def test_pinch_must_be_tighter_than_open():
    w = CalibrationWizard()
    w.i = 3
    w.data["open"] = 1.0
    hold(w, 1.5, (0.5, 0.5), ratio=0.9)
    assert w.step == "closed" and "tighter" in w.message.lower()


def test_fist_not_detected_stays_put():
    w = CalibrationWizard()
    w.i = 4
    hold(w, 2.0, (0.5, 0.5), fist=False)
    assert w.step == "fist"


def test_depth_needs_real_movement():
    w = CalibrationWizard()
    w.i = 5
    hold(w, 5.5, (0.5, 0.5), palm=0.2)
    assert w.step == "depth" and "closer" in w.message.lower()


def test_save_load_and_bad_file(tmp_path):
    p = tmp_path / "c.json"
    c = Calibration(region=(0.1, 0.2, 0.9, 0.8), pinch_on=0.25, pinch_off=0.4, depth_gain=4.0, calibrated=True)
    c.save(p)
    assert Calibration.load(p) == c
    p.write_text("not json")
    assert Calibration.load(p) == Calibration()
    p.write_text('{"region":[0.9,0.1,0.1,0.8],"pinch_on":0.3,"pinch_off":0.4}')
    assert Calibration.load(p) == Calibration()
    assert Calibration.load(tmp_path / "missing.json") == Calibration()
