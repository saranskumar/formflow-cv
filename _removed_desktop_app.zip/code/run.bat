@echo off
rem FormFlow launcher: creates the venv and installs dependencies on first run, then starts the app.
rem Usage:  run.bat            (camera + mouse)
rem         run.bat --mouse    (no camera)
rem         run.bat --camera 1 (pick a camera)
rem         run.bat --multiview (hidden three-view builder)
rem         run.bat test       (run the test suite)
setlocal
cd /d "%~dp0"

set "PY=.venv\Scripts\python.exe"

if not exist "%PY%" (
    echo [FormFlow] First run: creating virtual environment...
    py -3.12 -m venv .venv 2>nul || py -3 -m venv .venv 2>nul || python -m venv .venv
    if not exist "%PY%" (
        echo [FormFlow] Could not create the venv. Install Python 3.12 from python.org and retry.
        pause
        exit /b 1
    )
)

"%PY%" -c "import cv2, mediapipe, open3d, skimage, scipy, numpy" >nul 2>&1
if errorlevel 1 (
    echo [FormFlow] Installing dependencies ^(first run only, a few minutes^)...
    "%PY%" -m pip install --upgrade pip
    "%PY%" -m pip install -r requirements.txt
    if errorlevel 1 (
        echo [FormFlow] Dependency install failed. Check your internet connection and retry.
        pause
        exit /b 1
    )
)

set "PYTHONPATH=%CD%\src"
set "TF_CPP_MIN_LOG_LEVEL=2"
set "GLOG_minloglevel=2"

if /i "%~1"=="test" (
    "%PY%" -m pytest -q
    pause
    exit /b %errorlevel%
)

"%PY%" -m formflow %*
if errorlevel 1 (
    echo.
    echo [FormFlow] The app exited with an error.
    pause
)
endlocal
