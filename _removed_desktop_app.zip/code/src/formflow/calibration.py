"""Per-user calibration of hand movement.

A wizard measures what is comfortable for *this* user and this camera:
  1. reach area (two opposite corners)   -> maps hand movement onto the screen
  2. open-hand and pinched finger spacing -> pinch on/off thresholds
  3. a fist check                         -> proves rotate gesture is detected
  4. near/far hand range                  -> depth gain for "Depth: hand"
  5. a live test with a smoothing control
The pure logic lives here so it can be unit-tested without a camera.
"""
from __future__ import annotations

import json
from collections import deque
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Deque, Optional, Tuple

import numpy as np

DEFAULT_PATH = Path(__file__).resolve().parents[2] / "calibration.json"


@dataclass
class Calibration:
    region: Tuple[float, float, float, float] = (0.12, 0.10, 0.88, 0.80)   # x0, y0, x1, y1 in camera image
    pinch_on: float = 0.30
    pinch_off: float = 0.45
    depth_gain: float = 3.0
    smoothing: float = 1.0          # One-Euro min_cutoff: lower = smoother, higher = snappier
    palm_ref: float = 0.0           # palm size at the calibration distance (0 = unknown)
    dominant: str = "Right"         # which hand draws; the other hand navigates
    calibrated: bool = False

    def save(self, path=None) -> None:
        path = path or DEFAULT_PATH
        Path(path).write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path=None) -> "Calibration":
        path = path or DEFAULT_PATH
        try:
            d = json.loads(Path(path).read_text(encoding="utf-8"))
            c = cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})
            c.region = tuple(float(v) for v in c.region)            # type: ignore[assignment]
            x0, y0, x1, y1 = c.region
            if not (0 <= x0 < x1 <= 1 and 0 <= y0 < y1 <= 1 and c.pinch_on < c.pinch_off
                    and c.dominant in ("Left", "Right")):
                return cls()
            return c
        except (OSError, ValueError, TypeError):
            return cls()


@dataclass
class Sample:
    present: bool
    cur: Tuple[float, float] = (0.0, 0.0)    # raw (filtered) cursor in camera-image coords 0..1
    ratio: float = 1.0                       # thumb-index gap / palm size
    palm: float = 0.0                        # palm size, grows as the hand nears the camera
    fist: bool = False
    t: float = 0.0


STEPS = ("tl", "br", "open", "closed", "fist", "depth", "test")

TITLES = {
    "tl": ("1/6  Reach the TOP-LEFT", "Move your hand to the top-left of your comfortable range and hold still."),
    "br": ("2/6  Reach the BOTTOM-RIGHT", "Now move to the bottom-right of your comfortable range and hold still."),
    "open": ("3/6  Open hand", "Hold your hand up with thumb and index finger wide apart. Hold still."),
    "closed": ("4/6  Pinch", "Pinch thumb and index finger together and hold still."),
    "fist": ("5/6  Fist", "Make a fist and hold it. This is the rotate gesture."),
    "depth": ("6/6  Depth range", "Move your open hand slowly toward the camera, then back away."),
    "test": ("Test", "Try drawing and rotating. Adjust smoothing, then press Done."),
}

HOLD = 1.2           # seconds of stillness to confirm a pose
STILL = 0.035        # max cursor wander (image fraction) while holding
DEPTH_WINDOW = 5.0
COOLDOWN = 0.8


class CalibrationWizard:
    def __init__(self, base: Optional[Calibration] = None):
        self.base = base or Calibration()
        self.i = 0
        self.progress = 0.0
        self.message = ""
        self.finished = False
        self.data = {}
        self._buf: Deque[Sample] = deque()
        self._cool_until = 0.0
        self._d0: Optional[float] = None
        self._pmin = self._pmax = 0.0

    @property
    def step(self) -> str:
        return STEPS[self.i]

    @property
    def title(self) -> Tuple[str, str]:
        return TITLES[self.step]

    # ------------------------------------------------------------------
    def _advance(self, t: float) -> None:
        self.i = min(self.i + 1, len(STEPS) - 1)
        self._buf.clear()
        self._d0 = None
        self.progress = 0.0
        self.message = ""
        self._cool_until = t + COOLDOWN

    def skip_step(self, t: float = 0.0) -> None:
        if self.step != "test":
            self._advance(t)

    def feed(self, s: Sample) -> None:
        if self.step == "test" or s.t < self._cool_until:
            return
        if not s.present:
            self._buf.clear()
            self._d0 = None
            self.progress = 0.0
            self.message = "Show your hand to the camera"
            return
        self._buf.append(s)
        while self._buf and s.t - self._buf[0].t > HOLD + 0.15:
            self._buf.popleft()
        step = self.step
        if step == "depth":
            return self._feed_depth(s)

        span = s.t - self._buf[0].t
        xs = np.array([b.cur for b in self._buf])
        still = float(np.ptp(xs[:, 0])) < STILL and float(np.ptp(xs[:, 1])) < STILL
        need = 0.8 if step == "fist" else HOLD
        ok = self._pose_ok(step, s)
        if ok:
            self.message = ""
        if not still or not ok:
            self.progress = 0.0
            if step == "fist":
                self._buf.clear()
            return
        self.progress = min(1.0, span / need)
        if span >= need * 0.98:
            self._commit(step, s)

    def _pose_ok(self, step: str, s: Sample) -> bool:
        if step == "open":
            if s.ratio < 0.5:
                self.message = "Open your fingers wider"
                return False
        elif step == "closed":
            o = self.data.get("open", 0.9)
            if s.ratio > o * 0.6:
                self.message = "Pinch thumb and index tighter"
                return False
        elif step == "br":
            tl = self.data["tl"]
            if abs(s.cur[0] - tl[0]) < 0.15 or abs(s.cur[1] - tl[1]) < 0.12:
                self.message = "Move further to the bottom-right"
                return False
        elif step == "fist":
            return s.fist
        return True

    def _commit(self, step: str, s: Sample) -> None:
        pts = np.array([b.cur for b in self._buf])
        if step in ("tl", "br"):
            self.data[step] = tuple(pts.mean(0))
        elif step in ("open", "closed"):
            self.data[step] = float(np.median([b.ratio for b in self._buf]))
            if step == "open":
                self.data["palm"] = float(np.median([b.palm for b in self._buf]))
        self._advance(s.t)

    def _feed_depth(self, s: Sample) -> None:
        if self._d0 is None:
            self._d0, self._pmin, self._pmax = s.t, s.palm, s.palm
        self._pmin, self._pmax = min(self._pmin, s.palm), max(self._pmax, s.palm)
        elapsed = s.t - self._d0
        self.progress = min(1.0, elapsed / DEPTH_WINDOW)
        if elapsed >= DEPTH_WINDOW:
            if self._pmax / max(self._pmin, 1e-6) > 1.12:
                self.data["depth"] = (self._pmin, self._pmax)
                self._advance(s.t)
            else:
                self.message = "Move your hand much closer, then much further"
                self._d0 = None

    # ------------------------------------------------------------------
    def result(self) -> Calibration:
        c = Calibration(**{**asdict(self.base)})
        if "tl" in self.data and "br" in self.data:
            (ax, ay), (bx, by) = self.data["tl"], self.data["br"]
            x0, x1 = sorted((ax, bx))
            y0, y1 = sorted((ay, by))
            px, py = 0.04 * (x1 - x0), 0.04 * (y1 - y0)
            c.region = (max(0.0, x0 - px), max(0.0, y0 - py), min(1.0, x1 + px), min(1.0, y1 + py))
        if "open" in self.data and "closed" in self.data:
            o, cl = self.data["open"], self.data["closed"]
            if o > cl + 0.2:
                c.pinch_on = cl + 0.30 * (o - cl)
                c.pinch_off = max(c.pinch_on + 0.08, cl + 0.50 * (o - cl))
        if self.data.get("palm", 0) > 0:
            c.palm_ref = self.data["palm"]
        if "depth" in self.data:
            lo, hi = self.data["depth"]
            rel = (hi - lo) / ((hi + lo) / 2)
            c.depth_gain = float(np.clip(2.0 / rel, 1.5, 8.0))
        c.calibrated = True
        return c
