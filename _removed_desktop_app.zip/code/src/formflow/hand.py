"""Hand input: webcam + MediaPipe -> a Pointer (cursor, pinch) and gestures.

Pure logic (OneEuro, GestureDecoder) is separate from the camera so it can
be unit-tested with synthetic landmarks.
"""
from __future__ import annotations

import math
import threading
import time
from collections import deque
from dataclasses import dataclass
from typing import Deque, Dict, List, Optional, Tuple

import cv2
import numpy as np

from .calibration import Calibration, Sample
from .ui import Pointer

# MediaPipe landmark ids
WRIST, THUMB_TIP, INDEX_TIP, INDEX_PIP, MIDDLE_MCP = 0, 4, 8, 6, 9
FINGER_TIPS = (8, 12, 16, 20)
FINGER_PIPS = (6, 10, 14, 18)
MAX_CAMERAS = 5


class OneEuro:
    """One-Euro filter: heavy smoothing when slow (kills jitter), light when fast (no lag)."""

    def __init__(self, min_cutoff=1.0, beta=6.0, d_cutoff=1.0):
        self.min_cutoff, self.beta, self.d_cutoff = min_cutoff, beta, d_cutoff
        self.x: Optional[np.ndarray] = None
        self.dx = np.zeros(2)
        self.t: Optional[float] = None

    @staticmethod
    def _alpha(cutoff, dt):
        tau = 1.0 / (2 * math.pi * cutoff)
        return 1.0 / (1.0 + tau / dt)

    def reset(self):
        self.x, self.t = None, None

    def __call__(self, p, t: float) -> np.ndarray:
        p = np.asarray(p, float)
        if self.x is None:
            self.x, self.t, self.dx = p.copy(), t, np.zeros(2)
            return p
        dt = max(t - self.t, 1e-3)
        a_d = self._alpha(self.d_cutoff, dt)
        self.dx = a_d * ((p - self.x) / dt) + (1 - a_d) * self.dx
        cutoff = self.min_cutoff + self.beta * float(np.linalg.norm(self.dx))
        a = self._alpha(cutoff, dt)
        self.x = a * p + (1 - a) * self.x
        self.t = t
        return self.x.copy()


class GestureDecoder:
    """Landmarks (21,2+) in normalised image coords -> cursor, pinch, fist.

    Pinch is measured relative to palm size so it works at any distance, with
    separate on/off thresholds (hysteresis) and frame debounce.
    """

    def __init__(self, on=0.30, off=0.45, debounce=2, fist_hold=0.7):
        self.on, self.off, self.debounce, self.fist_hold = on, off, debounce, fist_hold
        self.pinching = False
        self.fist = False
        self._streak = 0
        self._fist_t0: Optional[float] = None
        self._fist_fired = False

    def reset(self):
        self.pinching, self._streak = False, 0
        self._fist_t0, self._fist_fired = None, False

    @staticmethod
    def palm_size(lm) -> float:
        return float(np.linalg.norm(lm[MIDDLE_MCP][:2] - lm[WRIST][:2])) or 1e-6

    def pinch_ratio(self, lm) -> float:
        return float(np.linalg.norm(lm[THUMB_TIP][:2] - lm[INDEX_TIP][:2])) / self.palm_size(lm)

    def is_fist(self, lm) -> bool:
        wrist = lm[WRIST][:2]
        curled = sum(np.linalg.norm(lm[t][:2] - wrist) < np.linalg.norm(lm[p][:2] - wrist)
                     for t, p in zip(FINGER_TIPS, FINGER_PIPS))
        return curled >= 4

    def cursor(self, lm) -> np.ndarray:
        # midpoint of thumb and index tip: stays put while the fingers close
        return (lm[THUMB_TIP][:2] + lm[INDEX_TIP][:2]) / 2

    def step(self, lm, now: float) -> Tuple[bool, bool]:
        """Returns (pinching, fist_undo_event)."""
        r = self.pinch_ratio(lm)
        want = r < (self.off if self.pinching else self.on)
        if want != self.pinching:
            self._streak += 1
            if self._streak >= self.debounce:
                self.pinching, self._streak = want, 0
        else:
            self._streak = 0

        fist_event = False
        self.fist = self.is_fist(lm)
        if self.fist:
            if self._fist_t0 is None:
                self._fist_t0 = now
            if not self._fist_fired and now - self._fist_t0 >= self.fist_hold:
                self._fist_fired, fist_event = True, True
        else:
            self._fist_t0, self._fist_fired = None, False
        return self.pinching, fist_event

    @property
    def fist_progress(self) -> float:
        if self._fist_t0 is None or self._fist_fired:
            return 0.0
        return min(1.0, (time.time() - self._fist_t0) / self.fist_hold)


@dataclass
class Reading:
    """One cleaned measurement of one hand."""
    cur: np.ndarray            # filtered cursor in camera-image coords (0..1)
    pinching: bool
    fist: bool
    palm: float                # palm size in image units; grows as the hand nears the camera
    ratio: float               # thumb-index gap / palm size
    t: float
    label: str = ""


class HandTrack:
    """Per-hand signal cleaning, so the cursor does what the user *meant*.

    * One-Euro smoothing (steady when slow, no lag when fast)
    * glitch rejection: a one-frame leap across the image is a tracking error, not a movement
    * pinch latch: closing thumb and finger drags the cursor a little. At pinch onset we rewind
      to where the cursor was just before and hold it for a moment, so strokes start where you
      aimed. The same hold at release stops the hook at the end of a stroke.
    """
    LOOKBACK = 0.15     # s: rewind this far at pinch onset
    HOLD = 0.08         # s: freeze the cursor after onset / release
    GLITCH = 0.18       # image fraction: a bigger one-frame jump is rejected
    MAX_GLITCH_FRAMES = 3

    def __init__(self, cal: Optional[Calibration] = None):
        self.decoder = GestureDecoder()
        self.filter = OneEuro()
        self.apply(cal or Calibration())
        self.reset()

    def apply(self, cal: Calibration) -> None:
        self.decoder.on, self.decoder.off = cal.pinch_on, cal.pinch_off
        self.filter.min_cutoff = cal.smoothing

    def reset(self) -> None:
        self.filter.reset()
        self.decoder.reset()
        self._hist: Deque[Tuple[float, np.ndarray]] = deque()
        self._prev: Optional[np.ndarray] = None
        self._prev_t = 0.0
        self._glitch = 0
        self._was_pinching = False
        self._hold_until = 0.0
        self._latched: Optional[np.ndarray] = None

    def _at(self, t: float) -> np.ndarray:
        """Filtered cursor position at (or just after) time t."""
        for ht, hp in self._hist:
            if ht >= t:
                return hp.copy()
        return self._hist[-1][1].copy()

    def step(self, lm: np.ndarray, now: float, label: str = ""):
        pinching, fist_event = self.decoder.step(lm, now)
        raw = self.decoder.cursor(lm).astype(float)
        if (self._prev is not None and now - self._prev_t < 0.15 and self._glitch < self.MAX_GLITCH_FRAMES
                and float(np.linalg.norm(raw - self._prev)) > self.GLITCH):
            raw, self._glitch = self._prev, self._glitch + 1       # reject the leap
        else:
            self._glitch = 0
        self._prev, self._prev_t = raw, now

        cur = self.filter(raw, now)
        self._hist.append((now, cur.copy()))
        while self._hist and now - self._hist[0][0] > 0.6:
            self._hist.popleft()

        if pinching and not self._was_pinching:                    # pinch onset
            self._latched = self._at(now - self.LOOKBACK)
            self.filter.x = self._latched.copy()
            self._hold_until = now + self.HOLD
        elif self._was_pinching and not pinching:                  # release
            self._latched = self._at(now - 0.10)
            self.filter.x = self._latched.copy()
            self._hold_until = now + self.HOLD
        self._was_pinching = pinching
        if now < self._hold_until and self._latched is not None:
            cur = self._latched
        return Reading(cur, pinching, self.decoder.fist, self.decoder.palm_size(lm),
                       self.decoder.pinch_ratio(lm), now, label), fist_event


MIN_PALM = 0.035            # smaller than this (image fraction) = too far away to be the user
OPPOSITE_RATIO = 0.55       # a second hand of the opposite side must be at least this big vs the first
SAME_LABEL_RATIO = 0.70     # ...and stricter when MediaPipe labels both hands alike
MIN_SEPARATION = 0.15       # same-label hands must be at least this far apart (image width fraction)

COLOR_MAIN = (255, 255, 0)        # BGR of cyan    #00FFFF
COLOR_SECOND = (255, 0, 255)      # BGR of magenta #FF00FF


def select_user_hands(dets, prev_main=None) -> List[int]:
    """Pick at most two hands that belong to the person using the app.

    dets: [(label, landmarks)]. A person standing behind the user has smaller hands (they are
    further from the camera), so the *largest* hand is taken as the user's, favouring the one near
    where the main hand was last seen. A second hand is accepted only if it is the opposite hand and
    close in size to the first (one left + one right of the same person). Returns indices into dets.
    """
    size = lambda lm: float(np.linalg.norm(lm[MIDDLE_MCP][:2] - lm[WRIST][:2]))
    cand = [(size(lm), i) for i, (_, lm) in enumerate(dets)]
    cand = [(sz, i) for sz, i in cand if sz >= MIN_PALM]
    if not cand:
        return []

    def score(c):
        sz, i = c
        near = prev_main is not None and float(np.linalg.norm(dets[i][1][WRIST][:2] - np.asarray(prev_main))) < 0.2
        return sz * (1.3 if near else 1.0)

    cand.sort(key=score, reverse=True)
    first_sz, first = cand[0]
    chosen = [first]
    for sz, i in cand[1:]:
        same = dets[i][0] == dets[first][0]
        far = abs(dets[i][1][WRIST][0] - dets[first][1][WRIST][0]) >= MIN_SEPARATION
        if (not same and sz >= OPPOSITE_RATIO * first_sz) or (same and far and sz >= SAME_LABEL_RATIO * first_sz):
            chosen.append(i)
            break
    return chosen


def isotropic_region(region, cam_aspect: float, screen_aspect: float):
    """Adjust a reach region so 1 cm of hand travel moves the cursor equally far on both axes.

    Region coordinates are fractions of the camera image, whose width and height differ in pixels;
    the screen has its own aspect. Matching them removes the 'horizontal feels faster' effect.
    Grows the short axis when it fits inside the image, otherwise shrinks the long one.
    """
    x0, y0, x1, y1 = region
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    ex, ey = x1 - x0, y1 - y0                       # extents as image fractions
    rw, rh = ex * cam_aspect, ey                    # in image-height units
    if rw / rh > screen_aspect:                     # too wide for the screen
        want = rw / screen_aspect
        if want <= 1.0:
            ey = want
        else:
            ex = rh * screen_aspect / cam_aspect
    else:                                           # too tall
        want = rh * screen_aspect / cam_aspect
        if want <= 1.0:
            ex = want
        else:
            ey = rw / screen_aspect
    nx0 = min(max(cx - ex / 2, 0.0), 1.0 - ex)
    ny0 = min(max(cy - ey / 2, 0.0), 1.0 - ey)
    return (nx0, ny0, nx0 + ex, ny0 + ey)


class HandInput:
    """Threaded webcam + MediaPipe, up to two hands.

    The *main* hand (calibration.dominant) drives the pointer. If a second hand is visible it is the
    *navigation* hand (ptr2): fist = orbit, pinch-drag = zoom, open palm distance = depth.
    With one hand visible it is always the main hand.
    """

    def __init__(self, camera_index: Optional[int] = None, region=(0.12, 0.10, 0.88, 0.80),
                 screen=(1280, 720), calibration: Optional[Calibration] = None):
        self.region, self.screen = region, screen
        self.cal = Calibration()
        self.cam_aspect = 16 / 9
        self.tracks: Dict[str, HandTrack] = {"main": HandTrack(), "second": HandTrack()}
        self.decoder = self.tracks["main"].decoder        # kept for older callers/tests
        self.filter = self.tracks["main"].filter
        self.active = False            # the main hand is currently tracked
        self.hand_count = 0
        self.ignored_hands = 0         # background hands filtered out
        self.undo_event = False
        self.preview: Optional[np.ndarray] = None
        self.camera_index = camera_index
        self.error: Optional[str] = None
        self._lock = threading.Lock()
        self._read: Dict[str, Optional[Reading]] = {"main": None, "second": None}
        self._seen = {"main": 0.0, "second": 0.0}
        self._eff_region = None
        self._lost_at = 0.0
        self._stop = False
        self.switching = False
        self._switch_req = False
        self._cap = None
        self._thread: Optional[threading.Thread] = None
        if calibration is not None:
            self.apply_calibration(calibration)

    def apply_calibration(self, cal: Calibration) -> None:
        self.cal = cal
        self.region = cal.region
        self._eff_region = None
        for t in self.tracks.values():
            t.apply(cal)

    def set_smoothing(self, value: float) -> None:
        for t in self.tracks.values():
            t.filter.min_cutoff = value

    def swap_dominant(self) -> str:
        self.cal.dominant = "Left" if self.cal.dominant == "Right" else "Right"
        return self.cal.dominant

    def sample(self) -> Sample:
        """Latest raw measurements of the main hand (image coordinates), for the calibration wizard."""
        with self._lock:
            r = self._read["main"]
        if r is None:
            return Sample(False, t=time.time())
        return Sample(True, (float(r.cur[0]), float(r.cur[1])), float(r.ratio), float(r.palm),
                      bool(r.fist), time.time())

    # ---- camera thread -------------------------------------------------
    def _open(self, idx: int):
        for backend in (cv2.CAP_DSHOW, cv2.CAP_ANY):
            cap = cv2.VideoCapture(idx, backend)
            if cap.isOpened() and cap.read()[0]:
                cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)         # always the freshest frame
                return cap
            cap.release()
        return None

    def start(self) -> bool:
        import mediapipe as mp
        self._mp = mp
        candidates = [self.camera_index] if self.camera_index is not None else list(range(MAX_CAMERAS))
        for idx in candidates:
            cap = self._open(idx)
            if cap is not None:
                self._cap, self.camera_index = cap, idx
                break
        if self._cap is None:
            self.error = "No camera found"
            return False
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return True

    def request_switch(self) -> None:
        """Ask the camera thread to move to the next working camera (non-blocking)."""
        if not self.switching:
            self.switching = True
            self._switch_req = True

    def _do_switch(self):
        cur = self.camera_index if self.camera_index is not None else 0
        old = self._cap
        self._cap = None
        if old is not None:
            old.release()
        order = [(cur + k) % MAX_CAMERAS for k in range(1, MAX_CAMERAS)] + [cur]
        for idx in order:
            cap = self._open(idx)
            if cap is not None:
                self._cap, self.camera_index = cap, idx
                break
        with self._lock:
            self._read = {"main": None, "second": None}
            self.preview = None
        for t in self.tracks.values():
            t.reset()
        self._switch_req = False
        self.switching = False

    def stop(self):
        self._stop = True
        if self._thread:
            self._thread.join(timeout=1.0)
        if self._cap:
            self._cap.release()

    @staticmethod
    def assign_roles(labels: List[str], xs: List[float], dominant: str) -> List[str]:
        """Role ('main'/'second') for each detected hand."""
        if len(labels) == 1:
            return ["main"]
        hits = [i for i, l in enumerate(labels) if l == dominant]
        if len(hits) == 1:
            main = hits[0]
        else:                                        # both labelled alike: fall back to position
            main = int(np.argmax(xs)) if dominant == "Right" else int(np.argmin(xs))
        return ["main" if i == main else "second" for i in range(len(labels))]

    def _loop(self):
        hands = self._mp.solutions.hands.Hands(
            static_image_mode=False, max_num_hands=4, model_complexity=0,
            min_detection_confidence=0.6, min_tracking_confidence=0.6)
        drawing = self._mp.solutions.drawing_utils
        conn = self._mp.solutions.hands.HAND_CONNECTIONS
        while not self._stop:
            if self._switch_req:
                self._do_switch()
            if self._cap is None:
                time.sleep(0.05)
                continue
            ok, frame = self._cap.read()
            if not ok:
                time.sleep(0.01)
                continue
            frame = cv2.flip(frame, 1)
            self.cam_aspect = frame.shape[1] / frame.shape[0]
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            rgb.flags.writeable = False
            res = hands.process(rgb)
            now = time.time()
            readings: Dict[str, Optional[Reading]] = {"main": None, "second": None}
            ignored = 0
            if res.multi_hand_landmarks:
                hls = res.multi_hand_landmarks
                labels = [h.classification[0].label for h in (res.multi_handedness or [])]
                labels = (labels + [""] * len(hls))[:len(hls)]
                lms = [np.array([[p.x, p.y, p.z] for p in hl.landmark]) for hl in hls]
                prev = self._read["main"].cur if self._read["main"] is not None else None
                keep = select_user_hands(list(zip(labels, lms)), prev)      # at most two, the user's own
                ignored = len(hls) - len(keep)
                roles = self.assign_roles([labels[i] for i in keep], [float(lms[i][0][0]) for i in keep],
                                          self.cal.dominant)
                h_img, w_img = frame.shape[:2]
                for i, role in zip(keep, roles):
                    hl, lm, label = hls[i], lms[i], labels[i]
                    track = self.tracks[role]
                    if getattr(track, "label", label) != label:
                        track.reset()                       # a different hand took this role
                    track.label = label
                    r, fist_event = track.step(lm, now, label)
                    readings[role] = r
                    col = COLOR_MAIN if role == "main" else COLOR_SECOND
                    drawing.draw_landmarks(
                        frame, hl, conn,
                        drawing.DrawingSpec(color=col, thickness=2, circle_radius=3),
                        drawing.DrawingSpec(color=col, thickness=2))
                    c = (int(r.cur[0] * w_img), int(r.cur[1] * h_img))      # gesture marker at the cursor point
                    if r.fist:
                        cv2.circle(frame, c, 16, (60, 140, 255), 3, cv2.LINE_AA)
                    elif r.pinching:
                        cv2.circle(frame, c, 9, (255, 255, 255), -1, cv2.LINE_AA)
                    if fist_event and role == "main":
                        with self._lock:
                            self.undo_event = True
            self.ignored_hands = ignored
            for role in ("main", "second"):
                if readings[role] is None:
                    self.tracks[role].reset()
            with self._lock:
                self._read = readings
                self.preview = frame
            self.hand_count = sum(r is not None for r in readings.values())

    # ---- main-thread side -------------------------------------------------
    def map_point(self, cur, palm: float) -> Tuple[float, float]:
        """Camera-image position -> screen position, normalised for distance and axis scale."""
        if self._eff_region is None or self._eff_region[0] != self.region or self._eff_region[1] != self.cam_aspect:
            iso = isotropic_region(self.region, self.cam_aspect, self.screen[0] / self.screen[1])
            self._eff_region = (self.region, self.cam_aspect, iso)
        x0, y0, x1, y1 = self._eff_region[2]
        k = 1.0
        if self.cal.palm_ref > 0 and palm > 0:
            # a closer hand covers more image for the same physical motion: shrink it back
            k = float(np.clip(self.cal.palm_ref / palm, 0.6, 1.6))
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        u = float(np.clip(0.5 + (cur[0] - cx) * k / (x1 - x0), 0, 1))
        v = float(np.clip(0.5 + (cur[1] - cy) * k / (y1 - y0), 0, 1))
        return u * self.screen[0], v * self.screen[1]

    def _apply(self, role: str, ptr: Pointer, now: float) -> bool:
        with self._lock:
            r = self._read[role]
        if r is None:
            # short grace period so one dropped frame doesn't end a stroke
            if ptr.source == "hand" and ptr.visible and now - self._seen[role] > 0.25:
                ptr.down, ptr.visible, ptr.grab = False, False, False
            return False
        self._seen[role] = now
        ptr.x, ptr.y = self.map_point(r.cur, r.palm)
        ptr.down, ptr.visible, ptr.source = bool(r.pinching and not r.fist), True, "hand"
        ptr.grab, ptr.scale = bool(r.fist), float(r.palm)
        return True

    def update(self, ptr: Pointer, ptr2: Optional[Pointer] = None) -> None:
        now = time.time()
        main = self._apply("main", ptr, now)
        if main:
            self._lost_at = now
            self.active = True
        elif self.active and now - self._lost_at > 0.25:
            self.active = False
        if ptr2 is not None:
            self._apply("second", ptr2, now)

    def take_undo(self) -> bool:
        with self._lock:
            ev, self.undo_event = self.undo_event, False
        return ev
