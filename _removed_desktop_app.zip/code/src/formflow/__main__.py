import argparse

from .app import App
from .calibration import Calibration


def main():
    ap = argparse.ArgumentParser(prog="formflow")
    ap.add_argument("--mouse", action="store_true", help="skip the camera, use the mouse only")
    ap.add_argument("--camera", type=int, default=None, help="camera index (default: auto)")
    ap.add_argument("--multiview", action="store_true", help="open the (hidden) three-view builder")
    ap.add_argument("--import-model", dest="model", default=None, help="load an .obj/.stl file at start")
    args = ap.parse_args()

    cal = Calibration.load()
    hand = None
    if not args.mouse:
        from .hand import HandInput
        hand = HandInput(args.camera, calibration=cal)
        if hand.start():
            print(f"Camera {hand.camera_index} OK. Hand control on (mouse still works)."
                  + ("" if cal.calibrated else " Tip: run Calibrate for best accuracy."))
        else:
            print(f"{hand.error}; continuing with mouse only (use the Camera button to retry).")
            hand = None
    app = App(hand_source=hand, calibration=cal)
    app.sketch.depth_gain = cal.depth_gain
    app.sketch.palm_ref_cal = cal.palm_ref
    app.camera_arg = args.camera
    if args.multiview:
        app.screen = "build"
    elif args.model:
        app.screen = "air"
        app.import_model(args.model)
    app.run()


if __name__ == "__main__":
    main()
