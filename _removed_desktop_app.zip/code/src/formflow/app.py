"""FormFlow application: menu + three-view builder + guide."""
from __future__ import annotations

import math
import time
from collections import deque
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

import cv2
import numpy as np

from .canvas import AXES, ViewCanvas
from .exporter import export_mesh, mesh_report
from .guide import Step, build_air_steps, build_steps
from .calibration import Calibration, CalibrationWizard, TITLES
from .meshio import MeshError
from .shapes import ALL_TOOLS, ImportedMesh, export_scene_obj, export_scene_stl
from .sketch3d import Sketch3D
from .reconstruction import build_visual_hull, volume_to_mesh
from .ui import (ACCENT, BAD, BG, DIM, EDGE, GOOD, PANEL, TEXT, WARN, Button, Pointer,
                 draw_cursor, put_text, text_size)
from .validation import align_views, check_consistency

WIN = "FormFlow"
W, H = 1280, 720
CANVAS_XY = (275, 80)
CANVAS_PX = 536
THUMB = 170
GRID_N = 96
VIEWPORT = (270, 76, 990, 546)   # air-sketch 3D view (x, y, w, h)
VIEWS = ("front", "top", "side")
DIMS = {"front": ("W", "H"), "top": ("W", "D"), "side": ("D", "H")}  # (horizontal, vertical)


class App:
    def __init__(self, export_dir="exports", hand_source=None, calibration=None):
        self.export_dir = Path(export_dir)
        self._bg = np.full((H, W, 3), BG, np.uint8)   # cached: a full-frame fill costs ~4 ms
        self.cal = calibration or Calibration()
        self.ptr2 = Pointer(source="hand")     # navigation hand (second hand)
        self._grab2 = None
        self._two_nav = None          # (hand distance, midpoint, camera distance) while both hands are pinched
        self._freeze_until = 0.0      # after a release, input is ignored briefly so the object stays put
        self._pan_last = None
        self.wizard = None
        self.bg_cam = True
        self.trail = deque(maxlen=60)
        self._test_applied = False
        self._test_smooth = 1.0
        self.canvases: Dict[str, ViewCanvas] = {v: ViewCanvas(v) for v in VIEWS}
        self.view = "front"
        self.screen = "menu"            # menu | build
        self.ptr = Pointer()
        self.hand = hand_source         # optional HandInput (stage 4)
        self.mesh = None
        self.exported = False
        self.message = ("", 0.0, GOOD)  # text, until, color
        self.drawing = False
        self.show_grid = True
        self.quit = False

        # guide
        self.guide_on = False
        self.steps: List[Step] = []
        self.step_i = 0
        self.guide_ticks = 0
        self.guide_ticks_step = 0

        self.menu_buttons = [
            Button("guide", "Guided tour (recommended)", (440, 270, 400, 54)),
            Button("air", "Air sketch (3D)", (440, 334, 400, 54)),
            Button("calibrate", "Calibrate hand movement", (440, 398, 400, 54)),
            Button("camera", "Camera", (440, 462, 400, 54), hint="N"),
            Button("quit", "Quit", (440, 526, 400, 54)),
        ]
        # three-view builder is kept in code but hidden from the UI (python -m formflow --multiview)
        self.sketch = Sketch3D()
        self.air_hover_ticks = 0
        self._grab_last = None
        self.camera_arg: Optional[int] = None
        self.cam_btn = Button("camera", "Camera", (880, 20, 250, 36), hint="N")
        tool_labels = {"free": "Freehand", "line": "Line", "rect": "Rectangle", "circle": "Circle",
                       "cube": "Cube", "sphere": "Sphere", "cylinder": "Cylinder", "cone": "Cone",
                       "pyramid": "Pyramid", "move": "Move", "scale": "Scale"}
        cell = lambda i: (20 + (i % 2) * 118, 84 + (i // 2) * 40, 112, 34)
        self.air_buttons = [Button(f"t_{t}", tool_labels[t], cell(i), scale=0.5)
                            for i, t in enumerate(ALL_TOOLS)]
        self.air_buttons.append(Button("import", "Import model", cell(len(ALL_TOOLS)), scale=0.46))
        actions = [("undo", "Undo"), ("clear", "Clear (hold)"), ("depth_dn", "Depth -"), ("depth_up", "Depth +"),
                   ("depth_mode", "Depth: steps"), ("snap", "Snap: off"), ("zoom_in", "Zoom +"),
                   ("zoom_out", "Zoom -"), ("reset", "Reset view"), ("export", "Export"),
                   ("calibrate", "Calibrate"), ("bg", "BG cam: on"), ("guide", "Guide"), ("menu", "Menu")]
        for i, (bid, label) in enumerate(actions):
            self.air_buttons.append(Button(bid, label, cell(len(ALL_TOOLS) + 1 + i), hold=0.6 if bid == "clear" else 0.0,
                                           scale=0.46))
        # three-view builder (hidden from the UI, reachable with --multiview)
        bx, bw, bh = 20, 230, 46
        y = lambda i: 90 + i * 56
        self.buttons = [
            Button("front", "Front", (bx, y(0), bw, bh), hint="1"),
            Button("top", "Top", (bx, y(1), bw, bh), hint="2"),
            Button("side", "Side", (bx, y(2), bw, bh), hint="3"),
            Button("undo", "Undo stroke", (bx, y(3), bw, bh), hint="Z"),
            Button("clear", "Clear view (hold)", (bx, y(4), bw, bh), hold=0.9, hint="C"),
            Button("build", "Build 3D", (bx, y(5), bw, bh), hint="R"),
            Button("export", "Export OBJ + STL", (bx, y(6), bw, bh), hint="E"),
            Button("guide", "Guide", (bx, y(7), bw, bh), hint="G"),
            Button("menu", "Menu", (bx, y(8), bw, bh), hint="Esc"),
        ]
        self.skip_btn = Button("skip", "Skip guide", (W - 190, 640, 160, 40), hint="")
        # calibration screen
        self.calib_buttons = {
            "c_smooth": Button("c_smooth", "Smoother", (20, 640, 150, 40), scale=0.5),
            "c_snap": Button("c_snap", "Snappier", (180, 640, 150, 40), scale=0.5),
            "c_skip": Button("c_skip", "Skip step", (W - 360, 640, 160, 40), scale=0.5),
            "c_done": Button("c_done", "Save & done", (W - 360, 640, 160, 40), scale=0.5),
            "c_cancel": Button("c_cancel", "Cancel", (W - 190, 640, 160, 40), scale=0.5),
            "c_hand": Button("c_hand", "Main hand: Right", (340, 640, 200, 40), scale=0.5),
        }

    # ------------------------------------------------------------------ input
    def on_mouse(self, event, x, y, flags, _):
        if self.hand is not None and self.hand.active:
            return
        self.ptr.source = "mouse"
        self.ptr.x, self.ptr.y, self.ptr.visible = x, y, True
        if event == cv2.EVENT_LBUTTONDOWN:
            self.ptr.down = True
        elif event == cv2.EVENT_LBUTTONUP:
            self.ptr.down = False
        elif event == cv2.EVENT_RBUTTONDOWN:
            self.ptr.grab = True
        elif event == cv2.EVENT_RBUTTONUP:
            self.ptr.grab = False
        elif event == cv2.EVENT_MBUTTONDOWN:
            self.ptr.pan = True
        elif event == cv2.EVENT_MBUTTONUP:
            self.ptr.pan = False
        elif event == cv2.EVENT_MOUSEWHEEL:
            self.ptr.wheel += 1 if flags > 0 else -1

    def canvas_rect(self):
        return (*CANVAS_XY, CANVAS_PX, CANVAS_PX)

    def to_canvas(self, x, y):
        s = 512 / CANVAS_PX
        return (x - CANVAS_XY[0]) * s, (y - CANVAS_XY[1]) * s

    def in_canvas(self, x, y):
        cx, cy, cw, ch = self.canvas_rect()
        return cx <= x < cx + cw and cy <= y < cy + ch

    # ---------------------------------------------------------------- actions
    def say(self, text, seconds=3.0, color=GOOD):
        self.message = (text, time.time() + seconds, color)

    def set_view(self, v):
        if self.drawing:
            self.canvases[self.view].end()
            self.drawing = False
        self.view = v

    # ---- camera ------------------------------------------------------
    def camera_label(self) -> str:
        if self.hand is None:
            return "Camera off - click to try"
        if self.hand.switching:
            return "Switching camera..."
        return f"Camera {self.hand.camera_index} - switch"

    def cycle_camera(self):
        if self.hand is None:
            from .hand import HandInput
            h = HandInput(self.camera_arg)
            if h.start():
                self.hand = h
                self.say(f"Camera {h.camera_index} on. Hand control enabled.")
            else:
                self.say(h.error or "No camera found", 4.0, BAD)
            return
        self.hand.request_switch()
        self.say("Switching camera...", 2.0, WARN)

    # ---- air sketch ----------------------------------------------------
    TOOL_HINTS = {
        "free": "Freehand: pinch and move to draw a curve",
        "line": "Line: pinch at the start, drag, release at the end",
        "rect": "Rectangle: pinch at one corner, drag to the opposite corner",
        "circle": "Circle: pinch at the centre, drag out to set the radius",
        "cube": "Cube: pinch at the centre, drag outward to size it",
        "sphere": "Sphere: pinch at the centre, drag outward to size it",
        "cylinder": "Cylinder: pinch at the centre, drag outward to size it",
        "cone": "Cone: pinch at the centre, drag outward to size it",
        "pyramid": "Pyramid: pinch at the centre, drag outward to size it",
        "move": "Move: pinch an object and drag it; release to drop it where it is",
        "scale": "Scale: pinch an object, drag up to grow it, down to shrink it",
    }

    def act_air(self, bid: str):
        sk = self.sketch
        if bid.startswith("t_"):
            sk.set_tool(bid[2:])
            self.say(self.TOOL_HINTS[sk.tool], 4.0, ACCENT)
        elif bid == "undo":
            sk.undo()
        elif bid == "clear":
            sk.clear()
            self.say("Scene cleared", color=WARN)
        elif bid == "depth_dn":
            sk.step_depth(-1)
        elif bid == "depth_up":
            sk.step_depth(+1)
        elif bid == "depth_mode":
            m = sk.toggle_depth_mode()
            self.say({"steps": "Depth set by the Depth +/- buttons",
                      "hand": "Depth follows your drawing hand: push toward the camera to come closer",
                      "offhand": "Depth follows your OTHER hand: open palm, push in = closer, pull back = away"}[m],
                     4.0, WARN)
        elif bid == "snap":
            sk.snap = not sk.snap
        elif bid == "zoom_in":
            sk.zoom(0.85)
        elif bid == "zoom_out":
            sk.zoom(1 / 0.85)
        elif bid == "reset":
            sk.reset_view()
        elif bid == "export":
            self.export_sketch()
        elif bid == "bg":
            self.bg_cam = not self.bg_cam
        elif bid == "import":
            self.import_model()
        elif bid == "calibrate":
            self.start_calibration()
        elif bid == "guide":
            self.start_guide("air")
        elif bid == "menu":
            self.screen, self.guide_on = "menu", False

    # ---- importing models -----------------------------------------------
    def pick_file(self):
        """Native file dialog for an OBJ/STL file (None if cancelled or unavailable)."""
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            path = filedialog.askopenfilename(
                title="Import a 3D model", parent=root,
                filetypes=[("3D models", "*.obj *.stl"), ("All files", "*.*")])
            root.destroy()
            return path or None
        except Exception as e:                                   # no display / tkinter missing
            self.say(f"File dialog unavailable ({e.__class__.__name__}). Use: run.bat --import-model file.obj", 6.0, BAD)
            return None

    def import_model(self, path=None):
        path = path or self.pick_file()
        self.ptr.down = self.ptr2.down = False                   # the dialog swallowed the release
        self._freeze_until = time.time() + 0.5
        if not path:
            return None
        try:
            item = ImportedMesh.from_file(path)
        except MeshError as e:
            self.say(f"Import failed: {e}", 6.0, BAD)
            return None
        item.center = self.sketch.target.copy()                  # appears where the camera is looking
        self.sketch.add_item(item)
        self.sketch.set_tool("move")
        self.say(f"Imported {item.name}: {len(item.faces)} triangles, fitted to the grid. "
                 "Move or Scale it with a pinch.", 6.0)
        return item

    def export_sketch(self):
        items = self.sketch.items
        if not items:
            self.say("Draw something first", 3.0, WARN)
            return
        base = self.export_dir / f"formflow_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        export_scene_obj(items, base.with_suffix(".obj"))
        msg = f"Saved {base}.obj"
        if self.sketch.solid_count:
            export_scene_stl(items, base.with_suffix(".stl"))
            msg += " + .stl"
        self.exported = True
        self.say(msg, 5.0)

    # ---- calibration -----------------------------------------------------
    def start_calibration(self):
        if self.hand is None:
            self.say("Turn the camera on first (Camera button)", 4.0, WARN)
            return
        self.wizard = CalibrationWizard(self.cal)
        self.trail.clear()
        self._test_applied = False
        self._test_smooth = self.cal.smoothing
        self.hand.apply_calibration(Calibration(region=(0.0, 0.0, 1.0, 1.0), smoothing=self.cal.smoothing))
        self.screen, self.guide_on = "calib", False

    def end_calibration(self, save: bool):
        w = self.wizard
        if save and w is not None:
            cal = w.result()
            cal.smoothing = self._test_smooth
            cal.save()
            self.cal = cal
            self.sketch.depth_gain = cal.depth_gain
            self.sketch.palm_ref_cal = cal.palm_ref
            self.say("Calibration saved", 4.0)
        if self.hand is not None:
            self.hand.apply_calibration(self.cal)
        self.wizard, self.screen = None, "menu"

    def toggle_dominant(self):
        if self.hand is None:
            return
        d = self.hand.swap_dominant()
        self.cal.dominant = d
        if self.wizard is not None:
            self.wizard.base.dominant = d
        self.say(f"Main hand: {d}. The other hand navigates.", 3.0, ACCENT)

    def act_calib(self, bid: str):
        w = self.wizard
        if bid == "c_skip":
            w.skip_step(time.time())
        elif bid == "c_cancel":
            self.end_calibration(False)
        elif bid == "c_done":
            self.end_calibration(True)
        elif bid in ("c_smooth", "c_snap"):
            f = 0.7 if bid == "c_smooth" else 1.4
            self._test_smooth = float(np.clip(self._test_smooth * f, 0.2, 5.0))
            self.hand.set_smoothing(self._test_smooth)
        elif bid == "c_hand":
            self.toggle_dominant()

    def _update_calib(self):
        w = self.wizard
        if w is None or self.hand is None:
            return
        s = self.hand.sample()
        w.feed(s)
        if w.step == "test":
            if not self._test_applied:
                # live-apply the measured calibration so the test screen feels like the real thing
                c = w.result()
                c.smoothing = self._test_smooth
                self.hand.apply_calibration(c)
                self._test_applied = True
            if s.present:
                self.trail.append(s.cur)

    def act(self, bid: str):
        if bid == "camera":
            return self.cycle_camera()
        if bid == "quit":
            self.quit = True
            return
        if self.screen == "air":
            return self.act_air(bid)
        if self.screen == "calib":
            return self.act_calib(bid)
        if bid == "air":
            self.screen = "air"
            return
        if bid == "calibrate":
            return self.start_calibration()
        cv = self.canvases[self.view]
        if bid in VIEWS:
            self.set_view(bid)
        elif bid == "undo":
            cv.undo()
        elif bid == "clear":
            cv.clear()
            self.say(f"{self.view.title()} cleared", color=WARN)
        elif bid == "build":
            self.build()
        elif bid == "export":
            self.export()
        elif bid == "guide":
            self.start_guide("multiview" if self.screen == "build" else "air")
        elif bid == "menu":
            self.screen = "menu"
            self.guide_on = False
        elif bid == "start":
            self.screen = "build"
        elif bid == "quit":
            self.quit = True

    def start_guide(self, kind: str = "air"):
        hand = self.hand is not None and self.hand.active
        self.step_i, self.guide_ticks, self.guide_ticks_step = 0, 0, 0
        self.guide_on, self.exported = True, False
        if kind == "air":
            self.steps = build_air_steps(hand=hand)
            self.screen = "air"
            self.sketch = Sketch3D()
            self.air_hover_ticks = 0
        else:
            self.steps = build_steps(hand=hand)
            self.screen = "build"
            for c in self.canvases.values():
                c.clear()
            self.mesh = None
            self.set_view("front")

    def end_guide(self):
        self.guide_on = False

    def sils(self):
        return [self.canvases[v].silhouette for v in VIEWS]

    def warnings(self) -> List[str]:
        return check_consistency(*self.sils())

    def build(self):
        f, t, s = self.sils()
        problems = self.warnings()
        if any("closed outline" in p for p in problems):
            self.say(problems[0], 4.0, BAD)
            return
        t0 = time.time()
        hull = build_visual_hull(*align_views(f, t, s, GRID_N))
        try:
            mesh = volume_to_mesh(hull.volume)
        except ValueError as e:
            self.say(str(e), 4.0, BAD)
            return
        self.mesh = mesh
        rep = mesh_report(mesh)
        iou = sum(hull.iou.values()) / 3
        self.say(f"Built in {time.time() - t0:.2f}s | {rep['triangles']} tris | "
                 f"IoU {iou:.2f} | watertight {rep['watertight']}", 6.0)
        self.show_mesh(mesh)

    def show_mesh(self, mesh):
        import open3d as o3d
        m = o3d.geometry.TriangleMesh(mesh)
        m.paint_uniform_color([0.95, 0.72, 0.30])
        m.translate(-m.get_center())
        size = float(max(m.get_axis_aligned_bounding_box().get_extent()))
        axes = o3d.geometry.TriangleMesh.create_coordinate_frame(size=size * 0.4)
        axes.translate(-np.array([size * 0.6] * 3))
        o3d.visualization.draw_geometries(
            [m, axes], window_name="FormFlow - 3D (drag rotate, scroll zoom, close to return)",
            width=1000, height=720, mesh_show_back_face=True)

    def export(self):
        if self.mesh is None:
            self.say("Build the 3D model first", 3.0, WARN)
            return
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base = self.export_dir / f"formflow_{stamp}"
        export_mesh(self.mesh, base.with_suffix(".obj"))
        export_mesh(self.mesh, base.with_suffix(".stl"))
        self.exported = True
        self.say(f"Saved {base}.obj / .stl", 5.0)

    # ------------------------------------------------------------------ frame
    def update(self):
        now = time.time()
        if self.hand is not None:
            self.hand.update(self.ptr, self.ptr2)
            if self.hand.take_undo() and self.screen == "build":
                self.canvases[self.view].undo()
                self.say("Undo (fist)", 1.5, WARN)
        if self.screen == "calib":
            test = self.wizard is not None and self.wizard.step == "test"
            ids = ["c_cancel"] + (["c_smooth", "c_snap", "c_hand", "c_done"] if test else ["c_skip"])
            buttons = [self.calib_buttons[i] for i in ids]
            self.calib_buttons["c_hand"].label = f"Main hand: {self.cal.dominant}"
        else:
            buttons = {"menu": self.menu_buttons, "air": self.air_buttons}.get(self.screen, self.buttons)
            if self.screen != "menu":
                buttons = buttons + [self.cam_btn]
        for b in buttons:
            if b.update(self.ptr, now):
                self.act(b.id)
                break
        self.cam_btn.label = self.camera_label()
        next(b for b in self.menu_buttons if b.id == "camera").label = self.camera_label()
        if self.screen == "calib":
            self._update_calib()
        if self.screen == "air":
            self._update_air()
            if self.guide_on:
                self._update_guide()
        if self.screen == "build":
            self._update_drawing()
            if self.guide_on:
                self._update_guide()
        for b in self.buttons:
            b.active = self.screen == "build" and b.id == self.view
        by = {b.id: b for b in self.air_buttons}
        for b in self.air_buttons:
            if b.id.startswith("t_"):
                b.active = b.id[2:] == self.sketch.tool
        by["bg"].label = f"BG cam: {'on' if self.bg_cam else 'off'}"
        by["bg"].active = self.bg_cam
        by["depth_mode"].label = f"Depth: {self.sketch.depth_mode}"
        by["depth_mode"].active = self.sketch.depth_mode == "hand"
        by["snap"].label = f"Snap: {'on' if self.sketch.snap else 'off'}"
        by["snap"].active = self.sketch.snap

    def _trim(self) -> float:
        """Hand input: rewind the last 0.1 s of a gesture (the fingers opening drags the cursor).
        Drags of existing objects rewind a little further so a dropped object stays exactly put."""
        if self.ptr.source != "hand":
            return 0.0
        return 0.15 if self.sketch.tool in ("move", "scale") else 0.10

    def _finish_gesture(self, now: float):
        """Commit the gesture and ignore input for a moment so release jitter cannot disturb the result."""
        self.sketch.end(trim=self._trim(), now=now)
        self.drawing = False
        if self.ptr.source == "hand":
            self._freeze_until = now + 0.3

    def _update_air(self):
        p, p2, sk = self.ptr, self.ptr2, self.sketch
        vp = VIEWPORT
        now = time.time()
        over = p.visible and vp[0] <= p.x < vp[0] + vp[2] and vp[1] <= p.y < vp[1] + vp[3]
        on_button = any(b.hovered(p) for b in self.air_buttons + [self.cam_btn])
        palm = p.scale if p.source == "hand" else 0.0
        if p.wheel:
            sk.zoom(0.9 ** p.wheel)
            p.wheel = 0

        # ---- both hands pinched: zoom (hands apart/together) and pan (hands move together)
        if p.visible and p2.visible and p.down and p2.down and p.source == "hand":
            d = math.hypot(p.x - p2.x, p.y - p2.y)
            mid = ((p.x + p2.x) / 2, (p.y + p2.y) / 2)
            if self._two_nav is None:
                if self.drawing or sk.active is not None or sk._anchor is not None or sk._drag is not None:
                    sk.cancel()                              # a stray single-hand gesture gives way to navigation
                    self.drawing = False
                self._two_nav = [max(d, 40.0), mid, sk.dist]
            else:
                d0, last_mid, dist0 = self._two_nav
                target = float(np.clip(dist0 * d0 / max(d, 40.0), 2.2, 9.0))
                sk.dist += 0.35 * (target - sk.dist)         # eased: no jumps
                dx, dy = mid[0] - last_mid[0], mid[1] - last_mid[1]
                if math.hypot(dx, dy) >= 1.5:                # small tremor does not move the view
                    sk.pan(dx, dy, vp)
                    self._two_nav[1] = mid
            return
        if self._two_nav is not None:
            self._two_nav = None
            self._freeze_until = now + 0.3                   # one hand lets go first: don't start drawing by accident

        # ---- navigation hand: fist = orbit, open palm = depth (Offhand mode)
        orbiting = False
        if p2.visible:
            if p2.grab:
                if self._grab2 is not None:
                    sk.orbit(p2.x - self._grab2[0], p2.y - self._grab2[1], now)
                self._grab2, orbiting = (p2.x, p2.y), True
            else:
                if self._grab2 is not None:
                    sk.release_orbit(now)
                self._grab2 = None
                if not p2.down and sk.depth_mode == "offhand":
                    sk.offhand_depth(p2.scale)
        else:
            if self._grab2 is not None:
                sk.release_orbit(now)
            self._grab2 = None

        # ---- middle mouse button: pan
        if p.pan and p.visible:
            if self._pan_last is not None:
                sk.pan(p.x - self._pan_last[0], p.y - self._pan_last[1], vp)
            self._pan_last = (p.x, p.y)
            return
        self._pan_last = None

        # ---- main hand fist (or right-drag with the mouse): orbit
        if p.grab and p.visible:
            if self.drawing:
                self._finish_gesture(now)
            if self._grab_last is not None:
                sk.orbit(p.x - self._grab_last[0], p.y - self._grab_last[1], now)
            self._grab_last = (p.x, p.y)
            return
        if self._grab_last is not None:
            sk.release_orbit(now)
        self._grab_last = None
        if not orbiting:
            sk.coast(now)

        # ---- main hand: hover / draw / drag
        frozen = now < self._freeze_until
        if over and not on_button:
            self.air_hover_ticks += 1
            if not self.drawing and not frozen:
                sk.hover(p.x, p.y, vp, palm)
        if p.pressed and over and not on_button and not frozen:
            self.drawing = True
            sk.begin(p.x, p.y, vp, palm)
        elif self.drawing and p.down and over:
            sk.add(p.x, p.y, vp, palm, now)
        elif self.drawing:
            self._finish_gesture(now)

    def _update_drawing(self):
        cv = self.canvases[self.view]
        p = self.ptr
        over = p.visible and self.in_canvas(p.x, p.y)
        on_button = any(b.hovered(p) for b in self.buttons)
        if p.pressed and over and not on_button:
            self.drawing = True
            cv.begin(self.to_canvas(p.x, p.y))
        elif self.drawing and p.down and over:
            cv.add(self.to_canvas(p.x, p.y))
        elif self.drawing and (p.released or not p.down or not over):
            cv.end()
            self.drawing = False

    def _update_guide(self):
        self.guide_ticks += 1
        self.guide_ticks_step += 1
        step = self.steps[self.step_i]
        if step.view and self.view != step.view and self.step_i in (1, 2):
            self.set_view(step.view)
        if step.done(self):
            if self.step_i + 1 >= len(self.steps):
                self.end_guide()
            else:
                self.step_i += 1
                self.guide_ticks_step = 0
        if self.skip_btn.update(self.ptr, time.time()):
            self.end_guide()

    # ---------------------------------------------------------------- drawing
    def render(self) -> np.ndarray:
        img = self._bg.copy()
        if self.screen == "menu":
            self._render_menu(img)
        elif self.screen == "air":
            self._render_air(img)
        elif self.screen == "calib":
            self._render_calib(img)
        else:
            self._render_build(img)
            self.cam_btn.draw(img, self.ptr)
        self._render_camera(img)
        draw_cursor(img, self.ptr)
        return img

    CALIB_RECT = (160, 76, 960, 540)

    def _render_calib(self, img):
        w = self.wizard
        x0, y0, cw, ch = self.CALIB_RECT
        title, body = w.title
        put_text(img, "Calibration", (x0, 50), 0.9, TEXT, 2)
        cam = self.hand.preview if self.hand is not None else None
        if cam is not None:
            img[y0:y0 + ch, x0:x0 + cw] = cv2.resize(cam, (cw, ch))
        cv2.rectangle(img, (x0, y0), (x0 + cw, y0 + ch), ACCENT, 1)
        step = w.step
        # target hints
        if step == "tl":
            cv2.drawMarker(img, (x0 + 40, y0 + 40), WARN, cv2.MARKER_TILTED_CROSS, 40, 3)
        elif step == "br":
            cv2.drawMarker(img, (x0 + cw - 40, y0 + ch - 40), WARN, cv2.MARKER_TILTED_CROSS, 40, 3)
        elif step == "test":
            rx0, ry0, rx1, ry1 = w.result().region
            cv2.rectangle(img, (int(x0 + rx0 * cw), int(y0 + ry0 * ch)), (int(x0 + rx1 * cw), int(y0 + ry1 * ch)),
                          GOOD, 2)
            put_text(img, "your reach area", (int(x0 + rx0 * cw) + 8, int(y0 + ry0 * ch) + 22), 0.5, GOOD)
            for i in range(1, len(self.trail)):
                a = (int(x0 + self.trail[i - 1][0] * cw), int(y0 + self.trail[i - 1][1] * ch))
                b = (int(x0 + self.trail[i][0] * cw), int(y0 + self.trail[i][1] * ch))
                cv2.line(img, a, b, ACCENT, 2, cv2.LINE_AA)
            put_text(img, f"smoothing {self._test_smooth:.2f}  (lower = smoother)", (x0 + 10, y0 + ch - 12), 0.5, TEXT)
            p = self.ptr
            state = "FIST" if p.grab else ("PINCH" if p.down else "open")
            put_text(img, f"gesture: {state}", (x0 + cw - 190, y0 + ch - 12), 0.6,
                     (60, 140, 255) if p.grab else (BAD if p.down else TEXT), 2)
        s = self.hand.sample() if self.hand is not None else None
        if s is not None and s.present and step != "test":
            c = (int(x0 + s.cur[0] * cw), int(y0 + s.cur[1] * ch))
            cv2.circle(img, c, 14, ACCENT, 2, cv2.LINE_AA)
            if w.progress > 0:
                cv2.ellipse(img, c, (24, 24), -90, 0, int(360 * w.progress), GOOD, 4, cv2.LINE_AA)
            if step in ("open", "closed"):
                put_text(img, f"finger gap {s.ratio:.2f}", (c[0] + 28, c[1] + 6), 0.5, TEXT)
            if step == "depth":
                put_text(img, f"hand size {s.palm:.3f}", (c[0] + 28, c[1] + 6), 0.5, TEXT)
        # bottom bar
        yb = 628
        cv2.rectangle(img, (0, yb), (W, H), PANEL, -1)
        cv2.line(img, (0, yb), (W, yb), EDGE, 1)
        put_text(img, title, (20, yb + 4 + 20), 0.7, ACCENT, 2)
        put_text(img, body, (20, yb + 4 + 46), 0.5, TEXT)
        if w.message:
            put_text(img, w.message, (20, yb + 4 + 70), 0.55, WARN)
        test = step == "test"
        for bid in (["c_cancel"] + (["c_smooth", "c_snap", "c_hand", "c_done"] if test else ["c_skip"])):
            self.calib_buttons[bid].draw(img, self.ptr)
        if not test and cam is None:
            put_text(img, "No camera image yet...", (x0 + 20, y0 + 40), 0.6, WARN)

    def _render_air(self, img):
        sk, p = self.sketch, self.ptr
        put_text(img, "Air sketch", (VIEWPORT[0], 50), 0.9, TEXT, 2)
        if self.drawing:
            label, col = "DRAWING", BAD
        elif p.grab and p.visible:
            label, col = "ROTATING", (60, 140, 255)
        elif p.visible and p.source == "hand":
            label, col = "READY: pinch to draw, fist to rotate", ACCENT
        elif p.visible:
            label, col = "READY: drag to draw, right-drag to rotate", ACCENT
        else:
            label, col = "show your hand to the camera", DIM
        put_text(img, label, (VIEWPORT[0] + 190, 50), 0.55, col)
        hands = self.hand.hand_count if self.hand is not None else 0
        put_text(img, f"tool: {sk.tool}   hands: {hands}"
                      + ("   (2nd hand fist = orbit, both pinched = zoom + pan)" if hands >= 2 else ""),
                 (VIEWPORT[0] + 10, 70), 0.45, DIM)
        back = self.hand.preview if (self.bg_cam and self.hand is not None) else None
        sk.render(img, VIEWPORT, backdrop=back)
        put_text(img, f"depth {sk.depth:+.1f}   objects {len(sk.items)}   solids {sk.solid_count}",
                 (VIEWPORT[0] + 10, VIEWPORT[1] + VIEWPORT[3] - 12), 0.5, DIM)
        for b in self.air_buttons:
            b.draw(img, self.ptr, self._pulse(b.id))
        self.cam_btn.draw(img, self.ptr)
        self._render_status(img, hint="Pinch a tool, then pinch and drag in the scene.   Fist: orbit.   Both hands pinched: zoom + pan")

    def _render_camera(self, img):
        if self.hand is None or self.hand.preview is None:
            return
        w, h = (320, 180) if self.screen == "menu" else (128, 72)
        x, y = (W - w - 20, 20) if self.screen == "menu" else (W - w - 12, 4)
        img[y:y + h, x:x + w] = cv2.resize(self.hand.preview, (w, h))
        col = GOOD if self.hand.active else EDGE
        cv2.rectangle(img, (x, y), (x + w, y + h), col, 1)
        if self.screen == "menu":
            put_text(img, "hand tracked" if self.hand.active else "show your hand",
                     (x, y + h + 22), 0.5, col)

    def _render_menu(self, img):
        put_text(img, "FormFlow", (440, 190), 2.2, ACCENT, 3)
        put_text(img, "Sketch in the air. Spin it around in 3D.", (442, 230), 0.7, DIM)
        for b in self.menu_buttons:
            b.draw(img, self.ptr)
        put_text(img, "Hand: point at an option and pinch it.  Mouse works too.", (442, 616), 0.5, DIM)
        if not self.cal.calibrated:
            put_text(img, "Tip: run Calibrate once for accurate pinch and reach.", (442, 642), 0.5, WARN)
        text, until, col = self.message
        if text and time.time() < until:
            put_text(img, text, (442, 672), 0.6, col)

    def _render_build(self, img):
        put_text(img, f"{self.view.title()} view", (CANVAS_XY[0], 55), 0.9, TEXT, 2)
        ax = AXES[self.view]
        put_text(img, f"horizontal: {ax[0]}   vertical: {ax[1]}", (CANVAS_XY[0] + 220, 55), 0.5, DIM)

        # active canvas
        x, y = CANVAS_XY
        big = cv2.resize(self.canvases[self.view].render(self.show_grid), (CANVAS_PX, CANVAS_PX),
                         interpolation=cv2.INTER_LINEAR)
        img[y:y + CANVAS_PX, x:x + CANVAS_PX] = big
        cv2.rectangle(img, (x, y), (x + CANVAS_PX, y + CANVAS_PX), ACCENT, 1)
        self._render_guides(img)

        for b in self.buttons:
            b.draw(img, self.ptr, self._pulse(b.id))

        # thumbnails with measured extents
        tx = 880
        for i, v in enumerate(VIEWS):
            ty = 80 + i * (THUMB + 12)
            c = self.canvases[v]
            thumb = cv2.resize(c.render(False), (THUMB, THUMB), interpolation=cv2.INTER_AREA)
            img[ty:ty + THUMB, tx:tx + THUMB] = thumb
            sil = c.silhouette
            col = GOOD if sil.closed else (WARN if c.has_ink else EDGE)
            cv2.rectangle(img, (tx, ty), (tx + THUMB, ty + THUMB), ACCENT if v == self.view else col, 2)
            put_text(img, v.title(), (tx + THUMB + 14, ty + 24), 0.65, TEXT, 1)
            if sil.closed:
                bw, bh = sil.bbox[2], sil.bbox[3]
                put_text(img, f"{bw} x {bh} px", (tx + THUMB + 14, ty + 50), 0.5, DIM)
                put_text(img, "closed", (tx + THUMB + 14, ty + 74), 0.5, GOOD)
            elif c.has_ink:
                put_text(img, "open - close it", (tx + THUMB + 14, ty + 50), 0.5, WARN)
            else:
                put_text(img, "empty", (tx + THUMB + 14, ty + 50), 0.5, DIM)
            # clicking a thumbnail selects the view
            if self.ptr.pressed and tx <= self.ptr.x <= tx + THUMB and ty <= self.ptr.y <= ty + THUMB:
                self.set_view(v)

        self._render_status(img)

    def _render_guides(self, img):
        """Tick marks showing the size the OTHER views expect along each axis."""
        cur = self.canvases[self.view].silhouette
        if not cur.closed:
            return
        x0, y0 = CANVAS_XY
        s = CANVAS_PX / 512
        cx, cy, cw, ch = cur.bbox
        col = (200, 160, 70)
        for axis, dim in zip("xy", DIMS[self.view]):
            ext = None
            for other in VIEWS:
                sil = self.canvases[other].silhouette
                if other != self.view and sil.closed and dim in DIMS[other]:
                    ext = sil.bbox[2] if DIMS[other][0] == dim else sil.bbox[3]
                    break
            if ext is None:
                continue
            if axis == "x":
                mid = cx + cw / 2
                for e in (mid - ext / 2, mid + ext / 2):
                    px = int(x0 + e * s)
                    cv2.line(img, (px, y0 + CANVAS_PX - 4), (px, y0 + CANVAS_PX - 22), col, 2)
            else:
                mid = cy + ch / 2
                for e in (mid - ext / 2, mid + ext / 2):
                    py = int(y0 + e * s)
                    cv2.line(img, (x0 + 4, py), (x0 + 22, py), col, 2)

    def _pulse(self, bid: str) -> float:
        if not (self.guide_on and self.step_i < len(self.steps)):
            return 0.0
        if self.steps[self.step_i].highlight == bid:
            return 0.5 + 0.5 * np.sin(time.time() * 5)
        return 0.0

    def _render_status(self, img, hint: str = ""):
        y0 = 628
        cv2.rectangle(img, (0, y0), (W, H), PANEL, -1)
        cv2.line(img, (0, y0), (W, y0), EDGE, 1)
        if self.guide_on and self.step_i < len(self.steps):
            st = self.steps[self.step_i]
            put_text(img, f"GUIDE {self.step_i + 1}/{len(self.steps)}  {st.title}", (20, y0 + 30), 0.75, ACCENT, 2)
            put_text(img, st.body, (20, y0 + 60), 0.55, TEXT)
            self.skip_btn.draw(img, self.ptr)
            return
        text, until, col = self.message
        if text and time.time() < until:
            put_text(img, text, (20, y0 + 36), 0.65, col)
            return
        if hint:
            put_text(img, hint, (20, y0 + 36), 0.6, DIM)
            return
        warns = self.warnings()
        if not warns:
            put_text(img, "All three views agree. Press Build 3D.", (20, y0 + 36), 0.65, GOOD)
        else:
            for i, w in enumerate(warns[:2]):
                put_text(img, w, (20, y0 + 30 + i * 28), 0.58, WARN)

    # -------------------------------------------------------------------- loop
    def handle_key(self, k: int):
        if k < 0:
            return
        c = chr(k & 0xFF).lower() if (k & 0xFF) < 128 else ""
        if k == 27:
            if self.screen == "calib":
                self.end_calibration(False)
            elif self.guide_on:
                self.end_guide()
            elif self.screen in ("build", "air"):
                self.screen = "menu"
            else:
                self.quit = True
        elif c == "n":
            self.cycle_camera()
        elif self.screen == "air":
            sk = self.sketch
            arrows = {2424832: (-18, 0), 2555904: (18, 0), 2490368: (0, -18), 2621440: (0, 18)}
            if k in arrows:
                sk.orbit(*arrows[k])
            tools_by_key = {str(i + 1): f"t_{t}" for i, t in enumerate(ALL_TOOLS[:9])}
            tools_by_key["0"] = "t_move"
            tools_by_key["x"] = "t_scale"
            if c in tools_by_key:
                self.act_air(tools_by_key[c])
            if c == "h":
                self.toggle_dominant()
            keymap = {"i": "import", "b": "bg", "k": "calibrate", "z": "undo", "c": "clear", "[": "depth_dn", "]": "depth_up", "d": "depth_mode",
                      "s": "snap", "+": "zoom_in", "=": "zoom_in", "-": "zoom_out", "v": "reset",
                      "e": "export", "g": "guide"}
            if c in keymap:
                self.act_air(keymap[c])
        elif self.screen == "menu" and c in ("a", "g", "k"):
            self.act({"a": "air", "g": "guide", "k": "calibrate"}[c])
        elif self.screen == "build":
            if c in ("1", "2", "3"):
                self.set_view(VIEWS["123".index(c)])
            elif c == "z":
                self.canvases[self.view].undo()
            elif c == "c":
                self.canvases[self.view].clear()
            elif c == "r":
                self.build()
            elif c == "e":
                self.export()
            elif c == "g":
                self.start_guide()
            elif c == "h":
                self.show_grid = not self.show_grid
        if c == "q" and self.screen == "menu":
            self.quit = True

    def run(self):
        cv2.namedWindow(WIN, cv2.WINDOW_AUTOSIZE)
        cv2.setMouseCallback(WIN, self.on_mouse)
        while not self.quit:
            self.update()
            cv2.imshow(WIN, self.render())
            self.ptr.tick()
            self.handle_key(cv2.waitKey(1))
            if cv2.getWindowProperty(WIN, cv2.WND_PROP_VISIBLE) < 1:
                break
        if self.hand is not None:
            self.hand.stop()
        cv2.destroyAllWindows()
