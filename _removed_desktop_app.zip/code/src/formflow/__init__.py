"""FormFlow: hand-drawn 3D scenes from webcam gestures."""
import platform as _platform


def _no_wmi(*_a, **_k):
    raise OSError("WMI disabled")


# numpy imports platform.machine(), which on Windows asks WMI. If the WMI service is hung
# (it can be under memory pressure) every `import numpy` blocks for minutes. Python already
# falls back to environment variables when WMI raises OSError, so make that the default.
if hasattr(_platform, "_wmi_query"):
    _platform._wmi_query = _no_wmi
