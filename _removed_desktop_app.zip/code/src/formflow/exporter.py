"""OBJ / STL export with sanity checks."""
from __future__ import annotations

from pathlib import Path


def export_mesh(mesh, filename) -> Path:
    import open3d as o3d

    path = Path(filename)
    if path.suffix.lower() not in {".obj", ".stl"}:
        raise ValueError("Supported formats: .obj, .stl")
    if mesh.is_empty():
        raise ValueError("Mesh is empty")
    path.parent.mkdir(parents=True, exist_ok=True)
    mesh.compute_vertex_normals()
    if not o3d.io.write_triangle_mesh(str(path), mesh, write_ascii=False):
        raise IOError(f"Failed to write {path}")
    return path


def mesh_report(mesh) -> dict:
    return {
        "vertices": len(mesh.vertices),
        "triangles": len(mesh.triangles),
        "watertight": bool(mesh.is_watertight()),
        "extent": [round(float(v), 2) for v in mesh.get_axis_aligned_bounding_box().get_extent()],
    }
