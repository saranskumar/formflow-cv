"""Skippable, self-advancing tutorial.

Each step waits for the user to actually do the thing; `done(app)` is
polled every frame. Works identically with mouse or hand input.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List, Optional


@dataclass
class Step:
    title: str
    body: str
    done: Callable[["object"], bool]
    highlight: Optional[str] = None        # button id to pulse
    view: Optional[str] = None             # view the user should be on


def build_steps(hand: bool) -> List[Step]:
    draw = "Pinch thumb + index and move to draw." if hand else "Click and drag to draw."
    return [
        Step("Welcome to FormFlow",
             "You describe an object by drawing it from 3 sides. We build the 3D model. "
             + ("Move your index finger to steer the cursor." if hand else "Use the mouse."),
             lambda a: a.guide_ticks > 90),
        Step("1. Draw the FRONT view", draw + " Sketch a closed shape, e.g. an L.",
             lambda a: a.canvases["front"].has_ink, view="front"),
        Step("2. Close the outline",
             "Finish the loop. Small gaps are repaired automatically. Green = recognised.",
             lambda a: a.canvases["front"].silhouette.closed, view="front"),
        Step("3. Switch to TOP", "Select Top, then draw it. Its width must match Front's.",
             lambda a: a.canvases["top"].silhouette.closed, highlight="top", view="top"),
        Step("4. Now the SIDE view", "Its depth must match Top's, its height Front's.",
             lambda a: a.canvases["side"].silhouette.closed, highlight="side", view="side"),
        Step("5. Reconstruct", "Press Build 3D. A window opens: drag to rotate, scroll to zoom.",
             lambda a: a.mesh is not None, highlight="build"),
        Step("6. Export", "Press Export to save OBJ and STL to the exports folder.",
             lambda a: a.exported, highlight="export"),
        Step("You're done", "Undo removes a stroke. Hold Clear to wipe a view. Enjoy!",
             lambda a: a.guide_ticks_step > 120),
    ]


def build_air_steps(hand: bool) -> List[Step]:
    if hand:
        move = "Hold your hand up. The cursor sits between your thumb and index finger."
        draw = "PINCH at the centre, drag outward to size it, release to place it."
        rot = "Make a FIST and move your hand: the view orbits. Open the hand to stop."
        depth = "Pinch Depth +. Or use Depth: hand and push toward the camera."
        grab = "Press Move, then pinch an object and drag it. Release to drop it."
    else:
        move = "Move the mouse over the 3D area."
        draw = "Click at the centre, drag outward to size it, release to place it."
        rot = "Right-drag to orbit the view. Scroll to zoom."
        depth = "Press Depth + to slide the drawing plane toward you."
        grab = "Press Move, then click-drag an object to reposition it."
    return [
        Step("Welcome to Air Sketch", "Build 3D scenes from shapes. This tour takes about a minute.",
             lambda a: a.guide_ticks > 90),
        Step("1. Move the cursor", move, lambda a: a.air_hover_ticks > 40),
        Step("2. Pick a shape", "Choose Cube from the palette on the left.",
             lambda a: a.sketch.tool == "cube", highlight="t_cube"),
        Step("3. Draw a cube", draw, lambda a: a.sketch.solid_count >= 1),
        Step("4. Rotate the view", rot, lambda a: a.sketch.rotated > 1.2),
        Step("5. Change depth", depth, lambda a: a.sketch.depth != 0.0 or a.sketch.depth_mode == "hand",
             highlight="depth_up"),
        Step("6. Add a sphere", "Pick Sphere and draw one. It lands at the new depth.",
             lambda a: a.sketch.solid_count >= 2),
        Step("7. Move things", grab, lambda a: a.sketch.moved >= 1, highlight="t_move"),
        Step("8. Undo", "Press Undo to remove the last shape.",
             lambda a: a.sketch.undo_count >= 1, highlight="undo"),
        Step("9. Export", "Press Export to save OBJ + STL to the exports folder.",
             lambda a: a.exported, highlight="export"),
        Step("You're done", "Two hands: fist = orbit, both pinched = zoom and pan. Import brings in OBJ/STL models.",
             lambda a: a.guide_ticks_step > 150),
    ]
