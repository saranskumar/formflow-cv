"""Drawable items: 2D shapes on the drawing plane and axis-aligned 3D solids.

Every item can give
  polylines()  wireframe, used for display and for OBJ line export
  hull()       3D points whose projection's convex hull is the filled silhouette
  mesh()       (verts, faces) triangle mesh for solids (outward winding), else None
Solids are Y-up and aligned to the world axes so they snap to the grid like CAD parts.
"""
from __future__ import annotations

import math
import struct
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Sequence, Tuple

import numpy as np

TOOLS_2D = ("free", "line", "rect", "circle")
TOOLS_3D = ("cube", "sphere", "cylinder", "cone", "pyramid")
ALL_TOOLS = TOOLS_2D + TOOLS_3D + ("move", "scale")
RING = 40


def _circle(c, u, v, r, n=RING):
    t = np.linspace(0, 2 * math.pi, n + 1)
    return c + r * (np.cos(t)[:, None] * u + np.sin(t)[:, None] * v)


class Item:
    volumetric = False          # True for items that enclose volume (solids, imported meshes)

    def polylines(self) -> List[np.ndarray]:
        raise NotImplementedError

    def snapshot(self):
        """Copy of the editable state, so a drag can be rewound exactly."""
        raise NotImplementedError

    def restore(self, snap) -> None:
        raise NotImplementedError

    def scale(self, factor: float) -> None:
        raise NotImplementedError

    def hull(self) -> Optional[np.ndarray]:
        return None

    def mesh(self) -> Optional[Tuple[np.ndarray, np.ndarray]]:
        return None

    def translate(self, d: np.ndarray) -> None:
        raise NotImplementedError


@dataclass
class Poly(Item):
    """Freehand stroke, line, rectangle or circle (all stored as a polyline)."""
    kind: str
    pts: np.ndarray

    @property
    def center(self) -> np.ndarray:                       # type: ignore[override]
        return self.pts.mean(0)

    def polylines(self):
        return [self.pts]

    def translate(self, d):
        self.pts = self.pts + d

    def snapshot(self):
        return self.pts.copy()

    def restore(self, snap):
        self.pts = snap.copy()

    def scale(self, factor):
        c = self.center
        self.pts = c + (self.pts - c) * factor


@dataclass
class Solid(Item):
    kind: str
    center: np.ndarray                                    # type: ignore[assignment]
    r: float

    # proportions
    @property
    def half(self) -> float:
        return self.r * 0.8 if self.kind in ("cube", "pyramid") else self.r

    @property
    def rad(self) -> float:
        return self.r * 0.7 if self.kind in ("cylinder", "cone") else self.r

    volumetric = True

    def translate(self, d):
        self.center = self.center + d

    def snapshot(self):
        return (self.center.copy(), self.r)

    def restore(self, snap):
        self.center, self.r = snap[0].copy(), snap[1]

    def scale(self, factor):
        self.r = float(np.clip(self.r * factor, 0.03, 2.0))

    def polylines(self) -> List[np.ndarray]:
        c, k = self.center, self.kind
        X, Y, Z = np.eye(3)
        if k == "cube":
            h = self.half
            v = np.array([c + h * np.array([sx, sy, sz]) for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)])
            idx = [(0, 1), (2, 3), (4, 5), (6, 7), (0, 2), (1, 3), (4, 6), (5, 7), (0, 4), (1, 5), (2, 6), (3, 7)]
            return [v[[a, b]] for a, b in idx]
        if k == "sphere":
            r = self.r
            return [_circle(c, X, Y, r), _circle(c, X, Z, r), _circle(c, Y, Z, r),
                    _circle(c + Y * r * 0.55, X, Z, r * 0.835), _circle(c - Y * r * 0.55, X, Z, r * 0.835)]
        if k == "cylinder":
            r, h = self.rad, self.r
            top, bot = _circle(c + Y * h, X, Z, r), _circle(c - Y * h, X, Z, r)
            side = [np.array([bot[i], top[i]]) for i in range(0, RING, RING // 8)]
            return [top, bot] + side
        if k == "cone":
            r, h = self.rad, self.r
            base = _circle(c - Y * h, X, Z, r)
            apex = c + Y * h
            return [base] + [np.array([base[i], apex]) for i in range(0, RING, RING // 8)]
        if k == "pyramid":
            h = self.half
            b = [c + np.array([sx * h, -self.r, sz * h]) for sx, sz in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
            apex = c + Y * self.r
            return [np.array(b + [b[0]])] + [np.array([p, apex]) for p in b]
        raise ValueError(k)

    def hull(self):
        return np.concatenate(self.polylines())

    # ---- meshes -------------------------------------------------------
    def mesh(self):
        v, f = self._raw_mesh()
        # every solid is convex: orient each triangle away from the centre => outward winding
        t = v[f]
        n = np.cross(t[:, 1] - t[:, 0], t[:, 2] - t[:, 0])
        out = np.einsum("ij,ij->i", n, t.mean(1) - self.center)
        f = f.copy()
        flip = out < 0
        f[flip] = f[flip][:, [0, 2, 1]]
        return v, f

    def _raw_mesh(self):
        c, k = self.center, self.kind
        if k == "cube":
            h = self.half
            v = np.array([c + h * np.array([sx, sy, sz]) for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)])
            f = [(0, 1, 3), (0, 3, 2), (4, 6, 7), (4, 7, 5), (0, 4, 5), (0, 5, 1),
                 (2, 3, 7), (2, 7, 6), (0, 2, 6), (0, 6, 4), (1, 5, 7), (1, 7, 3)]
            return v, np.array(f)
        if k == "pyramid":
            h = self.half
            v = np.array([c + [-h, -self.r, -h], c + [h, -self.r, -h], c + [h, -self.r, h],
                          c + [-h, -self.r, h], c + [0, self.r, 0]])
            f = [(0, 1, 2), (0, 2, 3), (0, 4, 1), (1, 4, 2), (2, 4, 3), (3, 4, 0)]
            return v, np.array(f)
        if k in ("cylinder", "cone"):
            n = 32
            t = np.linspace(0, 2 * math.pi, n, endpoint=False)
            ring = np.stack([np.cos(t), np.zeros(n), np.sin(t)], 1) * self.rad
            bot = c + ring - [0, self.r, 0]
            verts = [bot]
            faces: List[Tuple[int, int, int]] = []
            if k == "cylinder":
                top = c + ring + [0, self.r, 0]
                verts.append(top)
                v = np.concatenate(verts + [[c - [0, self.r, 0]], [c + [0, self.r, 0]]])
                cb, ct = 2 * n, 2 * n + 1
                for i in range(n):
                    j = (i + 1) % n
                    faces += [(i, n + j, j), (i, n + i, n + j), (cb, j, i), (ct, n + i, n + j)]
            else:
                v = np.concatenate(verts + [[c + [0, self.r, 0]], [c - [0, self.r, 0]]])
                ap, cb = n, n + 1
                for i in range(n):
                    j = (i + 1) % n
                    faces += [(i, j, ap), (cb, j, i)]
            return v, np.array(faces)
        if k == "sphere":
            nu, nv = 16, 32
            v = [c + [0, self.r, 0]]
            for i in range(1, nu):
                a = math.pi * i / nu
                for j in range(nv):
                    b = 2 * math.pi * j / nv
                    v.append(c + self.r * np.array([math.sin(a) * math.cos(b), math.cos(a), math.sin(a) * math.sin(b)]))
            v.append(c - [0, self.r, 0])
            f = []
            for j in range(nv):
                f.append((0, 1 + (j + 1) % nv, 1 + j))
            for i in range(nu - 2):
                for j in range(nv):
                    a, b = 1 + i * nv + j, 1 + i * nv + (j + 1) % nv
                    cc, d = a + nv, b + nv
                    f += [(a, b, cc), (b, d, cc)]
            last = len(v) - 1
            for j in range(nv):
                f.append((last, 1 + (nu - 2) * nv + j, 1 + (nu - 2) * nv + (j + 1) % nv))
            return np.array(v), np.array(f)
        raise ValueError(k)


@dataclass
class ImportedMesh(Item):
    """A model loaded from an OBJ/STL file, fitted to the workspace and editable like any other item.

    verts/faces are stored once in local space (centred, unit-scale); `center` and `s` place and size it.
    A decimated copy is used for drawing, the full mesh is used for export.
    """
    name: str
    verts: np.ndarray                       # (n,3) local, centred at the origin
    faces: np.ndarray                       # (m,3)
    center: np.ndarray = field(default_factory=lambda: np.zeros(3))      # type: ignore[assignment]
    s: float = 1.0
    kind: str = "mesh"
    volumetric = True

    def __post_init__(self):
        from .meshio import decimate_for_display
        self.disp_v, self.disp_f = decimate_for_display(self.verts, self.faces, 1200)
        t = self.disp_v[self.disp_f]
        n = np.cross(t[:, 1] - t[:, 0], t[:, 2] - t[:, 0])
        ln = np.linalg.norm(n, axis=1, keepdims=True)
        self.disp_n = n / np.where(ln > 1e-12, ln, 1.0)                  # unit normals (local = world: no rotation)
        self.radius0 = float(np.linalg.norm(self.verts, axis=1).max())

    @classmethod
    def from_file(cls, path, half: float = 0.85) -> "ImportedMesh":
        from pathlib import Path as _P
        from .meshio import fit_to_workspace, load_mesh
        v, f = load_mesh(path)
        v, _ = fit_to_workspace(v, half)
        return cls(_P(path).stem, v, f)

    @property
    def r(self) -> float:
        return self.radius0 * self.s

    def mesh(self):
        return self.verts * self.s + self.center, self.faces

    def display(self):
        return self.disp_v * self.s + self.center, self.disp_f

    def polylines(self) -> List[np.ndarray]:
        """Bounding box wireframe: used for picking and for the highlight."""
        lo, hi = self.verts.min(0) * self.s + self.center, self.verts.max(0) * self.s + self.center
        c = np.array([[x, y, z] for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])])
        idx = [(0, 1), (2, 3), (4, 5), (6, 7), (0, 2), (1, 3), (4, 6), (5, 7), (0, 4), (1, 5), (2, 6), (3, 7)]
        return [c[[a, b]] for a, b in idx]

    def hull(self):
        return np.concatenate(self.polylines())

    def translate(self, d):
        self.center = self.center + d

    def snapshot(self):
        return (self.center.copy(), self.s)

    def restore(self, snap):
        self.center, self.s = snap[0].copy(), snap[1]

    def scale(self, factor):
        self.s = float(np.clip(self.s * factor, 0.05, 6.0))


# ------------------------------------------------------------ stroke cleanup
def normalize_polyline(pts: np.ndarray, spacing: float = 0.03, smooth_iters: int = 3) -> np.ndarray:
    """Smooth and evenly resample a hand-drawn stroke.

    Raw hand tracking gives points that bunch up when you move slowly and spread out when you
    move fast, plus small tremor. Laplacian smoothing (endpoints pinned) removes the tremor,
    then arc-length resampling gives uniform point spacing regardless of drawing speed.
    """
    pts = np.asarray(pts, float)
    if len(pts) < 3:
        return pts
    keep = np.r_[True, np.linalg.norm(np.diff(pts, axis=0), axis=1) > 1e-9]
    pts = pts[keep]
    if len(pts) < 3:
        return pts
    for _ in range(smooth_iters):
        pts = pts.copy()
        pts[1:-1] = 0.25 * pts[:-2] + 0.5 * pts[1:-1] + 0.25 * pts[2:]
    seg = np.linalg.norm(np.diff(pts, axis=0), axis=1)
    arc = np.r_[0.0, np.cumsum(seg)]
    total = arc[-1]
    if total < spacing * 1.5:
        return pts
    n = max(2, int(round(total / spacing)) + 1)
    t = np.linspace(0.0, total, n)
    return np.stack([np.interp(t, arc, pts[:, k]) for k in range(3)], 1)


# ---------------------------------------------------------------- builders
def build_item(kind: str, a: np.ndarray, b: np.ndarray, right: np.ndarray, up: np.ndarray) -> Optional[Item]:
    """Item from a drag A->B on the camera-facing drawing plane, or None if too small."""
    d = b - a
    size = float(np.linalg.norm(d))
    if size < 0.03:
        return None
    if kind == "line":
        return Poly("line", np.array([a, b]))
    dx, dy = float(d @ right), float(d @ up)
    if kind == "rect":
        pts = np.array([a, a + right * dx, b, a + up * dy, a])
        return Poly("rect", pts)
    if kind == "circle":
        return Poly("circle", _circle(a, right, up, size))
    if kind in TOOLS_3D:
        return Solid(kind, a.copy(), size)
    return None


# ------------------------------------------------------------------ export
def solid_triangles(items: Sequence[Item]) -> np.ndarray:
    tris = []
    for it in items:
        m = it.mesh()
        if m is not None:
            v, f = m
            tris.append(v[f])
    return np.concatenate(tris) if tris else np.zeros((0, 3, 3))


def mesh_volume(v: np.ndarray, f: np.ndarray) -> float:
    t = v[f]
    return float(np.einsum("ij,ij->i", t[:, 0], np.cross(t[:, 1], t[:, 2])).sum() / 6)


def export_scene_obj(items: Sequence[Item], path) -> Path:
    """Solids as triangle meshes, everything else as polylines."""
    if not items:
        raise ValueError("Nothing to export")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    out, base = ["# FormFlow air sketch"], 1
    for n, it in enumerate(items):
        out.append(f"o {it.kind}_{n}")
        m = it.mesh()
        if m is not None:
            v, f = m
            out += [f"v {p[0]:.5f} {p[1]:.5f} {p[2]:.5f}" for p in v]
            out += [f"f {a + base} {b + base} {c + base}" for a, b, c in f]
            base += len(v)
        else:
            for pl in it.polylines():
                out += [f"v {p[0]:.5f} {p[1]:.5f} {p[2]:.5f}" for p in pl]
                out.append("l " + " ".join(str(base + j) for j in range(len(pl))))
                base += len(pl)
    path.write_text("\n".join(out) + "\n", encoding="utf-8")
    return path


def export_scene_stl(items: Sequence[Item], path) -> Path:
    """Binary STL of all solids (lines and flat shapes have no volume)."""
    tris = solid_triangles(items)
    if len(tris) == 0:
        raise ValueError("No solids to export")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(b"FormFlow air sketch".ljust(80, b"\0"))
        fh.write(struct.pack("<I", len(tris)))
        for t in tris:
            n = np.cross(t[1] - t[0], t[2] - t[0])
            n = n / (np.linalg.norm(n) or 1.0)
            fh.write(struct.pack("<12fH", *n, *t[0], *t[1], *t[2], 0))
    return path
