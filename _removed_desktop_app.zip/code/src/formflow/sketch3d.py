"""Air sketch: build 3D scenes with a hand (or mouse) in an embedded viewport.

World axes: X right, Y up, Z toward the viewer (at yaw 0). The workspace is
the cube [-1, 1]^3.

Drawing model (like sketching on a sheet of glass): the cursor ray through
the viewport is intersected with a plane that faces the camera. `depth`
slides that plane toward (+) or away from (-) the viewer. Orbit the view and
the glass turns with it, so any 3D scene can be built from a few gestures.
Depth comes from buttons, or from pushing the hand toward the camera.

Tools: freehand | line | rect | circle | cube | sphere | cylinder | cone |
pyramid | move.  Shape tools are drag-to-size: pinch at the anchor, drag, release.
"""
from __future__ import annotations

import math
import time
from collections import deque
from pathlib import Path
from typing import List, Optional, Tuple

import cv2
import numpy as np

from .shapes import ImportedMesh, Item, Poly, Solid, TOOLS_3D, build_item, normalize_polyline

LIMIT = 1.2          # points are clamped inside this half-extent
SNAP_STEP = 0.1
DEPTH_STEP = 0.2
MAX_ORBIT_PX = 60.0      # a larger one-frame hand jump is a tracking glitch, not a rotation
ORBIT_DECAY = 0.25       # s: inertia time constant after releasing the fist
STROKE_SPACING = 0.03    # even point spacing for freehand strokes

Rect = Tuple[int, int, int, int]

COL_FREE_TOP, COL_FREE_BOT = (255, 190, 70), (70, 190, 255)
COL_2D = (255, 205, 90)
COL_SOLID = (70, 175, 255)
COL_PREVIEW = (240, 240, 240)
COL_HOT = (255, 255, 255)


# static scene geometry, built once
_GRID = np.array([seg for t in np.linspace(-1, 1, 9)
                  for seg in (((t, -1, -1), (t, -1, 1)), ((-1, -1, t), (1, -1, t)))], float)
_CORNERS = np.array([(-1, -1, -1), (1, -1, -1), (1, 1, -1), (-1, 1, -1),
                     (-1, -1, 1), (1, -1, 1), (1, 1, 1), (-1, 1, 1)], float)
_CUBE = np.array([(_CORNERS[i], _CORNERS[j]) for i, j in
                  [(0, 1), (1, 2), (2, 3), (3, 0), (4, 5), (5, 6), (6, 7), (7, 4),
                   (0, 4), (1, 5), (2, 6), (3, 7)]], float)
_AXES = ((((0, 0, 0), (1.3, 0, 0)), (80, 80, 235), "X"), (((0, 0, 0), (0, 1.3, 0)), (110, 210, 110), "Y"),
         (((0, 0, 0), (0, 0, 1.3)), (235, 170, 70), "Z"))


class Sketch3D:
    def __init__(self):
        self.items: List[Item] = []
        self.active: Optional[List[np.ndarray]] = None      # freehand stroke being drawn
        self.tool = "free"
        self.yaw, self.pitch, self.dist = 0.55, 0.35, 4.0
        self.target = np.zeros(3)          # point the camera looks at (pan moves it)
        self.depth = 0.0
        self.depth_mode = "steps"          # "steps" | "hand"
        self.depth_gain = 3.0              # +10% palm size -> +0.3 depth (calibrated)
        self.snap = False
        self.rotated = 0.0                 # total orbit angle so far (for the guide)
        self.undo_count = 0
        self.moved = 0                     # completed move gestures (for the guide)
        self._s_ref = self._d_ref = self._d_smooth = 0.0
        self._cursor: Optional[np.ndarray] = None
        self._anchor: Optional[np.ndarray] = None
        self._drag: Optional[Item] = None
        self._drag_last: Optional[np.ndarray] = None
        self._drag_depth = 0.0
        self._drag_moved = False
        self._drag_y = 0.0
        self._drag_hist: deque = deque(maxlen=128)        # (t, snapshot) for exact rewind on release
        self.hot: Optional[Item] = None    # item under the cursor (move tool)
        self._times: List[float] = []                       # timestamps of the active stroke's points
        self._cursor_hist: deque = deque(maxlen=64)         # (t, point) while a shape is being dragged
        self._vel = np.zeros(2)                             # orbit velocity, px/s
        self._orbit_t: Optional[float] = None
        self._coasting = False
        self._coast_t = 0.0
        self.palm_ref = 0.0                                 # neutral palm size for off-hand depth
        self.palm_ref_cal = 0.0                             # calibrated palm size (0 = learn on first sight)
        self._basis_key = None
        self._basis = None
        self._bg_cache = {}

    # kept for older callers/tests: the list of everything drawn
    @property
    def strokes(self) -> List[Item]:
        return self.items

    # ---------------------------------------------------------------- camera
    def basis(self):
        key = (self.yaw, self.pitch, self.dist, *self.target)
        if self._basis_key == key:
            return self._basis
        cp, sp, cy, sy = math.cos(self.pitch), math.sin(self.pitch), math.cos(self.yaw), math.sin(self.yaw)
        offset = self.dist * np.array([cp * sy, sp, cp * cy])
        fwd = -offset / self.dist
        eye = self.target + offset
        right = np.array([-fwd[2], 0.0, fwd[0]])          # fwd x (0,1,0), written out
        right /= np.linalg.norm(right)
        up = np.array([right[1] * fwd[2] - right[2] * fwd[1],
                       right[2] * fwd[0] - right[0] * fwd[2],
                       right[0] * fwd[1] - right[1] * fwd[0]])
        self._basis_key, self._basis = key, (eye, fwd, right, up)
        return self._basis

    @staticmethod
    def focal(rect: Rect) -> float:
        return rect[3] * 1.35

    def project(self, pts, rect: Rect):
        """(n,3) world -> (n,2) screen px, and (n,) camera-space depth."""
        pts = np.atleast_2d(np.asarray(pts, float))
        eye, fwd, right, up = self.basis()
        v = pts - eye
        zc = np.maximum(v @ fwd, 1e-3)
        f = self.focal(rect)
        x = rect[0] + rect[2] / 2 + f * (v @ right) / zc
        y = rect[1] + rect[3] / 2 - f * (v @ up) / zc
        return np.stack([x, y], 1), zc

    def unproject(self, sx: float, sy: float, rect: Rect, depth: float) -> np.ndarray:
        """Point where the cursor ray meets the camera-facing plane at `depth`."""
        eye, fwd, right, up = self.basis()
        zc = self.dist - depth
        f = self.focal(rect)
        xc = (sx - rect[0] - rect[2] / 2) * zc / f
        yc = -(sy - rect[1] - rect[3] / 2) * zc / f
        return eye + right * xc + up * yc + fwd * zc

    # ---------------------------------------------------------------- view
    def _rotate(self, dx: float, dy: float) -> None:
        self.yaw -= dx * 0.009
        self.pitch = float(np.clip(self.pitch + dy * 0.009, -1.45, 1.45))

    def orbit(self, dx: float, dy: float, now: Optional[float] = None) -> None:
        """Rotate by a hand/mouse delta (pixels). Tracks velocity so release can coast."""
        now = time.time() if now is None else now
        dx, dy = float(np.clip(dx, -MAX_ORBIT_PX, MAX_ORBIT_PX)), float(np.clip(dy, -MAX_ORBIT_PX, MAX_ORBIT_PX))
        self._rotate(dx, dy)
        self.rotated += (abs(dx) + abs(dy)) * 0.009
        if self._orbit_t is not None and now > self._orbit_t:
            v = np.array([dx, dy]) / max(now - self._orbit_t, 1e-3)
            self._vel = 0.6 * self._vel + 0.4 * np.clip(v, -1500, 1500)
        self._orbit_t, self._coasting = now, False

    def release_orbit(self, now: Optional[float] = None) -> None:
        """Hand opened: keep spinning, slowing down smoothly (inertia)."""
        self._coasting = float(np.linalg.norm(self._vel)) > 60.0
        self._coast_t = time.time() if now is None else now
        self._orbit_t = None

    def coast(self, now: Optional[float] = None) -> None:
        if not self._coasting:
            return
        now = time.time() if now is None else now
        dt = min(max(now - self._coast_t, 0.0), 0.05)
        self._coast_t = now
        self._vel = self._vel * math.exp(-dt / ORBIT_DECAY)
        if float(np.linalg.norm(self._vel)) < 20.0:
            self._vel, self._coasting = np.zeros(2), False
            return
        self._rotate(*(self._vel * dt))

    def offhand_depth(self, palm: float) -> None:
        """Depth from the second hand's distance to the camera (pull back = away, push = closer)."""
        if palm <= 0:
            return
        if self.palm_ref <= 0:
            self.palm_ref = palm                    # first sighting defines 'neutral'
        rel = palm / self.palm_ref - 1.0
        if abs(rel) < 0.08:                         # dead zone: small drifts do nothing
            rel = 0.0
        else:
            rel -= 0.08 * np.sign(rel)
        target = float(np.clip(rel * self.depth_gain, -1.0, 1.0))
        self.depth += 0.25 * (target - self.depth)  # eased, so depth never jumps

    def zoom(self, factor: float) -> None:
        self.dist = float(np.clip(self.dist * factor, 2.2, 9.0))

    def pan(self, dx: float, dy: float, rect: Rect) -> None:
        """Slide the view by a hand/mouse delta in pixels: the scene follows the hands."""
        _, _, right, up = self.basis()
        k = self.dist / self.focal(rect)
        self.target = np.clip(self.target + (-right * dx + up * dy) * k, -2.5, 2.5)

    def reset_view(self) -> None:
        self.yaw, self.pitch, self.dist = 0.55, 0.35, 4.0
        self.target = np.zeros(3)

    def step_depth(self, sign: int) -> None:
        self.depth = float(np.clip(round(self.depth + sign * DEPTH_STEP, 2), -1.0, 1.0))

    DEPTH_MODES = ("steps", "hand", "offhand")

    def toggle_depth_mode(self) -> str:
        """steps (buttons) -> hand (push the drawing hand) -> offhand (second hand's distance)."""
        i = self.DEPTH_MODES.index(self.depth_mode)
        self.depth_mode = self.DEPTH_MODES[(i + 1) % len(self.DEPTH_MODES)]
        if self.depth_mode == "offhand":
            self.palm_ref = self.palm_ref_cal       # neutral = calibrated distance (or learn it on first sight)
        return self.depth_mode

    def set_tool(self, tool: str) -> None:
        self.end()
        self.tool = tool
        self.hot = None

    # ---------------------------------------------------------------- input
    def _place(self, sx, sy, rect, depth) -> np.ndarray:
        p = np.clip(self.unproject(sx, sy, rect, depth), -LIMIT, LIMIT)
        if self.snap:
            p = np.round(p / SNAP_STEP) * SNAP_STEP
        return p

    def current_depth(self, palm: float = 0.0) -> float:
        busy = self.active is not None or self._anchor is not None
        if self.depth_mode == "hand" and busy and self._s_ref > 0 and palm > 0:
            target = self._d_ref + self.depth_gain * (palm - self._s_ref) / self._s_ref
            self._d_smooth += 0.3 * (float(np.clip(target, -1.0, 1.0)) - self._d_smooth)
            return self._d_smooth
        return self.depth

    def hover(self, sx, sy, rect: Rect, palm: float = 0.0) -> None:
        self._cursor = self._place(sx, sy, rect, self.current_depth(palm))
        self.hot = self.pick(sx, sy, rect) if self.tool in ("move", "scale") else None

    def pick(self, sx: float, sy: float, rect: Rect) -> Optional[Item]:
        """Item nearest to a screen point (for the move tool)."""
        best, best_d = None, 1e9
        f = self.focal(rect)
        for it in self.items:
            if it.volumetric:
                p, zc = self.project(it.center, rect)
                d = float(np.hypot(p[0, 0] - sx, p[0, 1] - sy))
                reach = max(28.0, f * it.r / float(zc[0]))
                d = d if d <= reach else 1e9
            else:
                pp, _ = self.project(np.concatenate(it.polylines()), rect)
                d = float(np.min(np.hypot(pp[:, 0] - sx, pp[:, 1] - sy)))
                d = d if d <= 26 else 1e9
            if d < best_d:
                best, best_d = it, d
        return best

    def begin(self, sx, sy, rect: Rect, palm: float = 0.0) -> None:
        self._s_ref, self._d_ref, self._d_smooth = palm, self.depth, self.depth
        if self.tool in ("move", "scale"):
            it = self.pick(sx, sy, rect)
            if it is None:
                return
            eye, fwd, _, _ = self.basis()
            self._drag = it
            self._drag_depth = self.dist - float((it.center - eye) @ fwd)
            self._drag_last = self.unproject(sx, sy, rect, self._drag_depth)
            self._drag_y = sy
            self._drag_moved = False
            self._drag_hist.clear()
            self._drag_hist.append((time.time(), it.snapshot()))
            return
        p = self._place(sx, sy, rect, self.current_depth(palm))
        self._cursor = p
        self._cursor_hist.clear()
        self._times = [time.time()]
        if self.tool == "free":
            self.active = [p]
        else:
            self._anchor = p

    def add(self, sx, sy, rect: Rect, palm: float = 0.0, now: Optional[float] = None) -> None:
        if self._drag is not None:
            t = time.time() if now is None else now
            if self.tool == "scale":                      # drag up = bigger, drag down = smaller
                dy = sy - self._drag_y
                self._drag_y = sy
                if dy:
                    self._drag.scale(math.exp(-dy * 0.005))
                    self._drag_moved = True
            else:
                p = self.unproject(sx, sy, rect, self._drag_depth)
                d = p - self._drag_last
                if np.any(d):
                    self._drag.translate(d)
                    self._drag_last = p
                    self._drag_moved = True
            self._drag_hist.append((t, self._drag.snapshot()))
            return
        if self.active is None and self._anchor is None:
            return
        p = self._place(sx, sy, rect, self.current_depth(palm))
        self._cursor = p
        t = time.time() if now is None else now
        self._cursor_hist.append((t, p))
        if self.active is not None and (not self.active or np.linalg.norm(p - self.active[-1]) >= 0.012):
            self.active.append(p)
            self._times.append(t)

    def preview(self) -> Optional[Item]:
        if self.active is not None and len(self.active) > 1:
            return Poly("free", np.array(self.active))
        if self._anchor is not None and self._cursor is not None:
            _, _, right, up = self.basis()
            return build_item(self.tool, self._anchor, self._cursor, right, up)
        return None

    def end(self, trim: float = 0.0, now: Optional[float] = None) -> None:
        """Finish the current gesture.

        trim: drop the last `trim` seconds of input. Opening the fingers to release a pinch moves
        the cursor, which leaves a small hook at the end of a stroke; hand input trims it.
        """
        now = time.time() if now is None else now
        if self._drag is not None:
            if trim > 0 and len(self._drag_hist) >= 3:
                # Release commit: opening the fingers moves the hand before the pinch is seen to end.
                # Rewind to where the item was `trim` seconds before release, so it stays where it was let go.
                older = [snap for t, snap in self._drag_hist if t <= now - trim]
                if older:
                    self._drag.restore(older[-1])
            if self._drag_moved:
                self.moved += 1
            self._drag = self._drag_last = None
            self._drag_hist.clear()
        item = None
        if self.active is not None:
            pts, times = self.active, self._times
            if trim > 0 and len(pts) > 2 and len(times) == len(pts):
                cut = now - trim
                kept = [i for i, t in enumerate(times) if t <= cut]
                if len(kept) >= 2:
                    pts = [pts[i] for i in kept]
            if len(pts) >= 2:
                arr = np.array(pts)
                if not self.snap:                       # snapping already regularises; smoothing would undo it
                    arr = normalize_polyline(arr, STROKE_SPACING)
                item = Poly("free", arr)
        elif self._anchor is not None:
            final = self._cursor
            if trim > 0 and self._cursor_hist:
                cut = now - trim
                older = [p for t, p in self._cursor_hist if t <= cut]
                if older:
                    self._cursor = older[-1]
            item = self.preview()
            if item is None and final is not None:      # a quick flick must not be rewound to nothing
                self._cursor = final
                item = self.preview()
        if item is not None:
            self.items.append(item)
        self.active = self._anchor = None
        self._times = []
        self._cursor_hist.clear()

    def cancel(self) -> None:
        """Abandon the gesture in progress without committing it (a drag is rewound to its start)."""
        if self._drag is not None and self._drag_hist:
            self._drag.restore(self._drag_hist[0][1])
        self._drag = self._drag_last = None
        self._drag_hist.clear()
        self.active = self._anchor = None
        self._times = []
        self._cursor_hist.clear()

    def add_item(self, item: Item) -> Item:
        self.items.append(item)
        return item

    def undo(self) -> None:
        if self.items:
            self.items.pop()
            self.undo_count += 1
            self.hot = None

    def clear(self) -> None:
        self.items.clear()
        self.active = self._anchor = self._drag = None
        self.hot = None

    @property
    def point_count(self) -> int:
        return sum(len(pl) for it in self.items for pl in it.polylines())

    @property
    def solid_count(self) -> int:
        return sum(i.volumetric for i in self.items)

    # ---------------------------------------------------------------- render
    def _line3(self, img, rect, a, b, color, thick=1):
        pp, _ = self.project(np.array([a, b]), rect)
        cv2.line(img, tuple(np.round(pp[0]).astype(int)), tuple(np.round(pp[1]).astype(int)),
                 color, thick, cv2.LINE_AA)

    def _fill_item(self, fill, rect, it: Item, color):
        if isinstance(it, Solid):
            pts, _ = self.project(it.hull(), rect)
            hull = cv2.convexHull(np.round(pts).astype(np.int32))
            cv2.fillConvexPoly(fill, hull, color)

    MESH_COLOR = np.array([185.0, 150.0, 95.0])

    def _draw_mesh(self, view, rect, it: "ImportedMesh", hot=False):
        """Shaded, depth-sorted triangles (painter's algorithm) for an imported model."""
        v, f = it.display()
        pp, zc = self.project(v, rect)
        order = np.argsort(-zc[f].mean(1))                         # far to near
        _, fwd, _, _ = self.basis()
        shade = np.abs(it.disp_n @ -fwd)                           # headlight, two-sided: imports may be wound either way
        base = self.MESH_COLOR + (60 if hot else 0)
        cols = np.clip(base * (0.35 + 0.65 * shade[:, None]), 0, 255).astype(int)
        tri = np.round(pp[f]).astype(np.int32)
        for i in order:
            cv2.fillConvexPoly(view, tri[i], cols[i].tolist())

    def _wire_item(self, canvas, rect, it: Item, color, thick=2, hot=False):
        if isinstance(it, ImportedMesh) and not hot:               # bounding box only when highlighted
            return
        white = (255, 255, 255)
        for pl in it.polylines():
            pp, _ = self.project(pl, rect)
            pi = np.round(pp).astype(np.int32)
            if isinstance(it, Poly) and it.kind == "free":
                for i in range(len(pl) - 1):
                    t = float(np.clip((pl[i][1] + 1) / 2, 0, 1))
                    col = tuple(int(a * (1 - t) + b * t) for a, b in zip(COL_FREE_TOP, COL_FREE_BOT))
                    cv2.line(canvas, tuple(pi[i]), tuple(pi[i + 1]), white if hot else col,
                             thick + 1, cv2.LINE_AA)
            else:
                cv2.polylines(canvas, [pi], False, white if hot else color, thick, cv2.LINE_AA)

    _GRID, _CUBE, _AXES = _GRID, _CUBE, _AXES   # module-level, built once

    def _draw_segs(self, view, segs: np.ndarray, local: Rect, color, thick=1):
        """Project N segments in one call and draw them with one polylines call."""
        pp, _ = self.project(segs.reshape(-1, 3), local)
        pi = np.round(pp).astype(np.int32).reshape(-1, 2, 1, 2)
        cv2.polylines(view, list(pi), False, color, thick, cv2.LINE_AA)

    def render(self, img: np.ndarray, rect: Rect, show_cursor: bool = True,
               backdrop: Optional[np.ndarray] = None, backdrop_alpha: float = 0.4) -> None:
        x, y, w, h = rect
        local = (0, 0, w, h)                       # draw in viewport-local coordinates
        bg = self._bg_cache.get((w, h))
        if bg is None:
            bg = self._bg_cache[(w, h)] = np.full((h, w, 3), (30, 26, 24), np.uint8)
        if backdrop is not None:
            cam = cv2.resize(backdrop, (w, h), interpolation=cv2.INTER_LINEAR)
            view = cv2.addWeighted(cam, backdrop_alpha, bg, 1 - backdrop_alpha, 0)
        else:
            view = bg.copy()

        lit = backdrop is not None
        self._draw_segs(view, self._GRID, local, (82, 76, 70) if lit else (62, 56, 50))
        self._draw_segs(view, self._CUBE, local, (110, 100, 92) if lit else (84, 76, 68))
        for seg, col, name in self._AXES:
            seg = np.array(seg, float)
            self._draw_segs(view, seg[None], local, col, 2)
            p, _ = self.project(seg[1], local)
            cv2.putText(view, name, tuple(np.round(p[0]).astype(int) + [5, 5]),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, col, 1, cv2.LINE_AA)

        # drawing plane ("glass") at the current depth
        eye, fwd, right, up = self.basis()
        centre = eye + fwd * (self.dist - self.depth)
        half = 1.1 * (self.dist - self.depth) / self.dist
        quad = np.array([centre + right * a * half + up * b * half
                         for a, b in ((-1, -1), (1, -1), (1, 1), (-1, 1))])
        qp, _ = self.project(quad, local)
        cv2.polylines(view, [np.round(qp).astype(np.int32)], True, (170, 130, 60), 1, cv2.LINE_AA)

        # imported models: opaque shaded surfaces
        for it in self.items:
            if isinstance(it, ImportedMesh):
                self._draw_mesh(view, local, it, it is self.hot)

        # items: translucent fill for solids first, then crisp wireframes on top
        pv = self.preview()
        shown = [(it, COL_SOLID if isinstance(it, Solid) else COL_2D, it is self.hot) for it in self.items]
        if pv is not None:
            shown.append((pv, COL_PREVIEW, False))
        if any(isinstance(it, Solid) for it, _, _ in shown):
            fill = view.copy()
            for it, col, _ in shown:
                self._fill_item(fill, local, it, col)
            view = cv2.addWeighted(fill, 0.22, view, 0.78, 0)
        for it, col, hot in shown:
            self._wire_item(view, local, it, col, hot=hot)

        # 3D cursor with a drop line to the floor, for depth perception
        if show_cursor and self._cursor is not None:
            p3 = self._cursor
            foot = p3.copy()
            foot[1] = -1.0
            pp, _ = self.project(np.array([p3, foot]), local)
            a_, b_ = tuple(np.round(pp[0]).astype(int)), tuple(np.round(pp[1]).astype(int))
            cv2.line(view, a_, b_, (170, 150, 120), 1, cv2.LINE_AA)
            cv2.circle(view, b_, 3, (170, 150, 120), -1, cv2.LINE_AA)
            cv2.circle(view, a_, 6, (255, 200, 90), 2, cv2.LINE_AA)

        img[y:y + h, x:x + w] = view
        cv2.rectangle(img, (x, y), (x + w, y + h), (255, 190, 70), 1)


def export_polylines_obj(strokes, path) -> Path:
    """Write items as OBJ polylines (`v` + `l`). Kept for simple line-only export."""
    path = Path(path)
    if not strokes:
        raise ValueError("Nothing to export")
    path.parent.mkdir(parents=True, exist_ok=True)
    lines, base = ["# FormFlow air sketch (polylines)"], 1
    for i, s in enumerate(strokes):
        pts = s.polylines()[0] if hasattr(s, "polylines") else s
        lines.append(f"o stroke_{i}")
        lines += [f"v {p[0]:.5f} {p[1]:.5f} {p[2]:.5f}" for p in pts]
        lines.append("l " + " ".join(str(base + j) for j in range(len(pts))))
        base += len(pts)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path
