"""Tiny immediate-mode UI on top of OpenCV, driven by a generic Pointer.

A Pointer is "where the user is pointing and whether they are pressing".
Mouse and hand tracking both feed the same Pointer, so every button and
canvas works with either.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import cv2
import numpy as np

FONT = cv2.FONT_HERSHEY_SIMPLEX

BG = (28, 24, 22)
PANEL = (46, 40, 36)
EDGE = (88, 80, 72)
TEXT = (235, 232, 228)
DIM = (150, 144, 138)
ACCENT = (255, 190, 70)      # BGR: sky blue
GOOD = (120, 200, 90)
WARN = (60, 170, 250)
BAD = (90, 90, 235)


@dataclass
class Pointer:
    x: float = -1.0
    y: float = -1.0
    down: bool = False
    visible: bool = False
    source: str = "mouse"          # "mouse" | "hand"
    prev_down: bool = False
    grab: bool = False             # fist (hand) / right button (mouse): rotate the view
    scale: float = 0.0             # palm size in image units: grows as the hand nears the camera
    wheel: int = 0                 # mouse wheel ticks since last frame (+ = zoom in)
    pan: bool = False              # middle mouse button: slide the view

    @property
    def pressed(self) -> bool:
        return self.down and not self.prev_down

    @property
    def released(self) -> bool:
        return self.prev_down and not self.down

    def tick(self) -> None:
        self.prev_down = self.down


def put_text(img, text, org, scale=0.55, color=TEXT, thick=1):
    cv2.putText(img, text, org, FONT, scale, color, thick, cv2.LINE_AA)


def text_size(text, scale=0.55, thick=1) -> Tuple[int, int]:
    (w, h), _ = cv2.getTextSize(text, FONT, scale, thick)
    return w, h


class Button:
    """Press to trigger. With hold>0 the pointer must stay down (progress ring)."""

    def __init__(self, bid: str, label: str, rect, hold: float = 0.0, hint: str = "", scale: float = 0.55):
        self.id, self.label, self.rect, self.hold, self.hint = bid, label, rect, hold, hint
        self.scale = scale
        self.enabled = True
        self.active = False
        self.progress = 0.0
        self._t0: Optional[float] = None
        self._fired = False

    def contains(self, x: float, y: float) -> bool:
        bx, by, bw, bh = self.rect
        return bx <= x <= bx + bw and by <= y <= by + bh

    def hovered(self, ptr: Pointer) -> bool:
        return ptr.visible and self.contains(ptr.x, ptr.y)

    def update(self, ptr: Pointer, now: float) -> bool:
        if not self.enabled:
            self.progress, self._t0 = 0.0, None
            return False
        inside = self.hovered(ptr)
        if self.hold <= 0:
            # Selection is always an intentional press (pinch or click): hovering never activates anything.
            return inside and ptr.pressed
        if inside and ptr.down and not self._fired:
            if self._t0 is None:
                self._t0 = now
            self.progress = min(1.0, (now - self._t0) / self.hold)
            if self.progress >= 1.0:
                self._fired = True
                return True
        else:
            if not ptr.down:
                self._fired = False
            self.progress, self._t0 = 0.0, None
        return False

    def draw(self, img, ptr: Pointer, pulse: float = 0.0):
        x, y, w, h = self.rect
        hover = self.hovered(ptr)
        fill = PANEL
        if self.active:
            fill = (92, 72, 44)
        if hover and self.enabled:
            fill = (74, 64, 56) if not self.active else (112, 88, 52)
        cv2.rectangle(img, (x, y), (x + w, y + h), fill, -1)
        if self.progress > 0:
            cv2.rectangle(img, (x, y), (x + int(w * self.progress), y + h), (70, 110, 200), -1)
        border = ACCENT if (self.active or hover) else EDGE
        cv2.rectangle(img, (x, y), (x + w, y + h), border, 1)
        if pulse > 0:                                   # guide highlight
            g = int(2 + 2 * pulse)
            cv2.rectangle(img, (x - g, y - g), (x + w + g, y + h + g), ACCENT, 2)
        col = TEXT if self.enabled else (100, 96, 92)
        tw, th = text_size(self.label, self.scale)
        put_text(img, self.label, (x + (w - tw) // 2, y + (h + th) // 2), self.scale, col)
        if self.hint:
            put_text(img, self.hint, (x + w - 22, y + h - 8), 0.4, DIM)


def draw_cursor(img, ptr: Pointer):
    if not ptr.visible:
        return
    c = (int(ptr.x), int(ptr.y))
    col = BAD if ptr.down else ACCENT
    cv2.circle(img, c, 10 if ptr.down else 14, col, 2, cv2.LINE_AA)
    cv2.circle(img, c, 3, col, -1, cv2.LINE_AA)
