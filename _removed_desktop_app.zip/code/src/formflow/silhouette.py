"""Turn a raw stroke raster into a clean, filled silhouette mask."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import cv2
import numpy as np


@dataclass
class Silhouette:
    mask: np.ndarray                           # uint8 0/255, filled
    closed: bool                               # outline was closed (possibly after gap repair)
    bbox: Optional[Tuple[int, int, int, int]]  # x, y, w, h (None if nothing drawn)
    kernel_used: int = 0                       # gap-closing kernel that worked (0 = none needed)

    @property
    def empty(self) -> bool:
        return self.bbox is None


def _remove_specks(img: np.ndarray, min_area: int) -> np.ndarray:
    n, labels, stats, _ = cv2.connectedComponentsWithStats(img, connectivity=8)
    out = np.zeros_like(img)
    for i in range(1, n):
        if stats[i, cv2.CC_STAT_AREA] >= min_area:
            out[labels == i] = 255
    return out


def _fill_enclosed(outline: np.ndarray) -> np.ndarray:
    """Fill everything the outline encloses: flood the outside, invert."""
    h, w = outline.shape
    pad = cv2.copyMakeBorder(outline, 1, 1, 1, 1, cv2.BORDER_CONSTANT, value=0)
    cv2.floodFill(pad, np.zeros((h + 4, w + 4), np.uint8), (0, 0), 128)
    filled = np.where(pad == 128, 0, 255).astype(np.uint8)
    return filled[1:-1, 1:-1]


def extract_silhouette(strokes: np.ndarray, kernels=(5, 11, 21), min_area: int = 150) -> Silhouette:
    """strokes: uint8 image, nonzero where the user drew.

    Closes small gaps with escalating morphological kernels, fills the
    enclosed region and keeps the largest connected shape.
    """
    binary = (strokes > 0).astype(np.uint8) * 255
    binary = _remove_specks(binary, 8)
    if cv2.countNonZero(binary) == 0:
        return Silhouette(np.zeros_like(binary), False, None)

    for k in (0,) + tuple(kernels):
        # Dilate to bridge gaps (closing alone cannot join two thin collinear
        # line ends), fill the enclosed area, then erode the *filled shape*
        # back so the silhouette keeps its true size.
        work = binary
        if k:
            se = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
            work = cv2.dilate(binary, se)
        filled = _fill_enclosed(work)
        # a closed outline encloses area beyond the stroke pixels themselves
        enclosed = cv2.countNonZero(filled) - cv2.countNonZero(work)
        if k:
            filled = cv2.erode(filled, se)
        if enclosed >= min_area:
            contours, _ = cv2.findContours(filled, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            biggest = max(contours, key=cv2.contourArea)
            mask = np.zeros_like(filled)
            cv2.drawContours(mask, [biggest], -1, 255, cv2.FILLED)
            return Silhouette(mask, True, cv2.boundingRect(biggest), k)

    # never closed: report bbox of the strokes so the UI can point at the problem
    return Silhouette(np.zeros_like(binary), False, cv2.boundingRect(cv2.findNonZero(binary)))
