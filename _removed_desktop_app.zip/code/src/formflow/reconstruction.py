"""Visual hull from three orthographic masks, then a triangle mesh.

Voxel array axes are volume[x, y, z] with X = width, Y = height, Z = depth.
Image rows grow downward, so the Y (height) index is flipped when reading
the Front and Side masks.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

import numpy as np
from scipy import ndimage


@dataclass
class Hull:
    volume: np.ndarray               # bool (N, N, N)
    iou: Dict[str, float]            # re-projection IoU per view
    voxels: int


def _iou(a: np.ndarray, b: np.ndarray) -> float:
    u = np.logical_or(a, b).sum()
    return 1.0 if u == 0 else float(np.logical_and(a, b).sum() / u)


def build_visual_hull(front: np.ndarray, top: np.ndarray, side: np.ndarray,
                      keep_largest: bool = True) -> Hull:
    n = front.shape[0]
    if any(m.shape != (n, n) for m in (front, top, side)):
        raise ValueError("All masks must be N x N and equal size.")

    F = np.flipud(front > 0).T   # (X, Y)  front: col = X, row = flipped Y
    T = (top > 0).T              # (X, Z)  top  : col = X, row = Z
    S = np.flipud(side > 0).T    # (Z, Y)  side : col = Z, row = flipped Y

    vol = F[:, :, None] & T[:, None, :] & S.T[None, :, :]   # (X, Y, Z)

    if keep_largest and vol.any():
        lab, cnt = ndimage.label(vol)
        if cnt > 1:
            sizes = ndimage.sum(vol, lab, range(1, cnt + 1))
            vol = lab == (int(np.argmax(sizes)) + 1)

    iou = {
        "front": _iou(vol.any(axis=2), F),
        "top": _iou(vol.any(axis=1), T),
        "side": _iou(vol.any(axis=0).T, S),
    }
    return Hull(vol, iou, int(vol.sum()))


def volume_to_mesh(volume: np.ndarray, voxel_size: float = 1.0):
    """Marching cubes on the padded volume -> Open3D TriangleMesh."""
    import open3d as o3d
    from skimage.measure import marching_cubes

    if not volume.any():
        raise ValueError("Empty volume: the three views do not intersect.")
    padded = np.pad(volume.astype(np.uint8), 1)
    verts, faces, _, _ = marching_cubes(padded, level=0.5)
    verts = (verts - 1.0) * voxel_size          # undo padding offset
    mesh = o3d.geometry.TriangleMesh(
        o3d.utility.Vector3dVector(verts), o3d.utility.Vector3iVector(faces))
    mesh.remove_degenerate_triangles()
    mesh.remove_duplicated_vertices()
    mesh.compute_vertex_normals()
    return mesh
