"""A drawing canvas for one orthographic view."""
from __future__ import annotations

from typing import List, Optional, Tuple

import cv2
import numpy as np

from .silhouette import Silhouette, extract_silhouette

Point = Tuple[float, float]

AXES = {
    "front": ("X (width)", "Y (height)"),
    "top": ("X (width)", "Z (depth)"),
    "side": ("Z (depth)", "Y (height)"),
}


class ViewCanvas:
    def __init__(self, name: str, size: int = 512, brush: int = 4, min_spacing: float = 2.0):
        self.name, self.size, self.brush, self.min_spacing = name, size, brush, min_spacing
        self.strokes: List[List[Point]] = []
        self.active: Optional[List[Point]] = None
        self._sil: Optional[Silhouette] = None

    # ---- stroke input -------------------------------------------------
    def begin(self, p: Point) -> None:
        self.active = [p]

    def add(self, p: Point) -> None:
        if self.active is None:
            self.begin(p)
            return
        lx, ly = self.active[-1]
        if (p[0] - lx) ** 2 + (p[1] - ly) ** 2 >= self.min_spacing ** 2:
            self.active.append(p)

    def end(self) -> None:
        if self.active is not None and len(self.active) > 1:
            self.strokes.append(self.active)
            self._sil = None
        self.active = None

    def undo(self) -> None:
        if self.strokes:
            self.strokes.pop()
            self._sil = None

    def clear(self) -> None:
        self.strokes.clear()
        self.active = None
        self._sil = None

    @property
    def has_ink(self) -> bool:
        return bool(self.strokes) or bool(self.active and len(self.active) > 1)

    # ---- rendering ----------------------------------------------------
    def raster(self, include_active: bool = True) -> np.ndarray:
        img = np.zeros((self.size, self.size), np.uint8)
        groups = list(self.strokes)
        if include_active and self.active and len(self.active) > 1:
            groups.append(self.active)
        for s in groups:
            pts = np.round(np.array(s)).astype(np.int32).reshape(-1, 1, 2)
            cv2.polylines(img, [pts], False, 255, self.brush, cv2.LINE_8)
        return img

    @property
    def silhouette(self) -> Silhouette:
        if self._sil is None:
            self._sil = extract_silhouette(self.raster(include_active=False))
        return self._sil

    def render(self, show_grid: bool = True, show_fill: bool = True) -> np.ndarray:
        """BGR image of the canvas for display."""
        n = self.size
        img = np.full((n, n, 3), (40, 35, 32), np.uint8)
        if show_grid:
            for i in range(0, n + 1, n // 8):
                c = (70, 62, 56) if i != n // 2 else (96, 86, 76)
                cv2.line(img, (i, 0), (i, n), c, 1)
                cv2.line(img, (0, i), (n, i), c, 1)
        sil = self.silhouette
        if show_fill and sil.closed:
            tint = np.zeros_like(img)
            tint[sil.mask > 0] = (110, 150, 70)
            img = cv2.addWeighted(img, 1.0, tint, 0.55, 0)
        ink = self.raster()
        img[ink > 0] = (240, 235, 230)
        return img
