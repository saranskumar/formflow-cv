"""Cross-view consistency checks and alignment of the three silhouettes.

Axes: X = width, Y = height, Z = depth.
  Front: horizontal X, vertical Y     Top: horizontal X, vertical Z
  Side : horizontal Z, vertical Y
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

import cv2
import numpy as np

from .silhouette import Silhouette


@dataclass
class Extents:
    width: float    # X
    height: float   # Y
    depth: float    # Z


def rel_error(a: float, b: float) -> float:
    m = max(a, b)
    return 0.0 if m == 0 else abs(a - b) / m


def check_consistency(front: Silhouette, top: Silhouette, side: Silhouette,
                      tolerance: float = 0.15) -> List[str]:
    """Return human-readable warnings (empty list = views agree)."""
    missing = [n for n, s in (("Front", front), ("Top", top), ("Side", side))
               if s.empty or not s.closed]
    if missing:
        return [f"{', '.join(missing)}: draw a closed outline."]
    checks = [
        ("Width (Front vs Top)", front.bbox[2], top.bbox[2]),
        ("Height (Front vs Side)", front.bbox[3], side.bbox[3]),
        ("Depth (Top vs Side)", top.bbox[3], side.bbox[2]),
    ]
    return [f"{name} differs by {rel_error(a, b):.0%}"
            for name, a, b in checks if rel_error(a, b) > tolerance]


def target_extents(front: Silhouette, top: Silhouette, side: Silhouette) -> Extents:
    """Average each shared dimension across the two views that measure it."""
    return Extents(
        width=(front.bbox[2] + top.bbox[2]) / 2,
        height=(front.bbox[3] + side.bbox[3]) / 2,
        depth=(top.bbox[3] + side.bbox[2]) / 2,
    )


def _place(sil: Silhouette, tw: float, th: float, n: int) -> np.ndarray:
    """Crop to bbox, scale to (tw, th) pixels and centre on an n x n canvas."""
    x, y, w, h = sil.bbox
    crop = sil.mask[y:y + h, x:x + w]
    tw_i, th_i = max(1, int(round(tw))), max(1, int(round(th)))
    scaled = cv2.resize(crop, (tw_i, th_i), interpolation=cv2.INTER_NEAREST)
    out = np.zeros((n, n), np.uint8)
    ox, oy = (n - tw_i) // 2, (n - th_i) // 2
    out[oy:oy + th_i, ox:ox + tw_i] = scaled
    return out


def align_views(front: Silhouette, top: Silhouette, side: Silhouette,
                n: int = 96, margin: float = 0.06):
    """Normalise the three masks onto a shared n x n grid.

    The largest extent fills the grid (minus margin) so the W:H:D ratio is
    preserved and shared dimensions agree exactly across views.
    Returns (front, top, side) uint8 masks of shape (n, n).
    """
    e = target_extents(front, top, side)
    scale = n * (1 - 2 * margin) / max(e.width, e.height, e.depth)
    w, h, d = e.width * scale, e.height * scale, e.depth * scale
    return (
        _place(front, w, h, n),   # X horizontal, Y vertical
        _place(top, w, d, n),     # X horizontal, Z vertical
        _place(side, d, h, n),    # Z horizontal, Y vertical
    )
