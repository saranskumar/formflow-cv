"""Load OBJ and STL files into plain (vertices, faces) arrays.

Own parsers, no dependency on Open3D, so import works the same in tests and in the app.
  OBJ  : `v` vertices and `f` faces (v, v/vt, v//vn, v/vt/vn, negative indices, polygons fan-triangulated)
  STL  : binary and ASCII; duplicate corner vertices are welded
"""
from __future__ import annotations

import re
import struct
from pathlib import Path
from typing import Tuple

import numpy as np

MAX_FILE_MB = 80


class MeshError(ValueError):
    """The file could not be read as a usable mesh."""


def load_mesh(path) -> Tuple[np.ndarray, np.ndarray]:
    path = Path(path)
    if not path.is_file():
        raise MeshError(f"File not found: {path}")
    if path.stat().st_size > MAX_FILE_MB * 1024 * 1024:
        raise MeshError(f"File is larger than {MAX_FILE_MB} MB")
    ext = path.suffix.lower()
    if ext == ".obj":
        v, f = _load_obj(path)
    elif ext == ".stl":
        v, f = _load_stl(path)
    else:
        raise MeshError("Only .obj and .stl files can be imported")
    return _clean(v, f)


# ---------------------------------------------------------------------- OBJ
def _load_obj(path: Path):
    verts, faces = [], []
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if line.startswith("v "):
                parts = line.split()
                try:
                    verts.append((float(parts[1]), float(parts[2]), float(parts[3])))
                except (IndexError, ValueError):
                    raise MeshError("Malformed vertex line in OBJ")
            elif line.startswith("f "):
                idx = []
                for tok in line.split()[1:]:
                    try:
                        i = int(tok.split("/")[0])
                    except ValueError:
                        raise MeshError("Malformed face line in OBJ")
                    idx.append(i - 1 if i > 0 else len(verts) + i)    # negative = relative to the end
                for k in range(1, len(idx) - 1):                      # fan triangulation
                    faces.append((idx[0], idx[k], idx[k + 1]))
    if not verts:
        raise MeshError("OBJ has no vertices")
    return np.array(verts, float), np.array(faces, int).reshape(-1, 3)


# ---------------------------------------------------------------------- STL
def _load_stl(path: Path):
    data = path.read_bytes()
    if len(data) >= 84:
        n = struct.unpack("<I", data[80:84])[0]
        if len(data) == 84 + 50 * n:                                  # exact size match = binary
            if n == 0:
                raise MeshError("STL has no triangles")
            rec = np.frombuffer(data, dtype=np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]),
                                count=n, offset=84)
            tris = rec["v"].astype(float).reshape(-1, 3)
            return _weld(tris)
    text = data.decode("utf-8", errors="replace")
    nums = re.findall(r"vertex\s+(\S+)\s+(\S+)\s+(\S+)", text)
    if not nums or len(nums) % 3:
        raise MeshError("STL is neither valid binary nor valid ASCII")
    try:
        tris = np.array(nums, float).reshape(-1, 3)
    except ValueError:
        raise MeshError("Malformed vertex in ASCII STL")
    return _weld(tris)


def _weld(corners: np.ndarray):
    """Triangle-soup corners (3n,3) -> shared vertices + faces."""
    key = np.round(corners * 1e5).astype(np.int64)
    _, first, inverse = np.unique(key, axis=0, return_index=True, return_inverse=True)
    return corners[first], inverse.reshape(-1, 3)


# ------------------------------------------------------------------ shared
def _clean(v: np.ndarray, f: np.ndarray):
    if len(f) == 0:
        raise MeshError("File has no faces")
    if f.min() < 0 or f.max() >= len(v):
        raise MeshError("Face refers to a vertex that does not exist")
    if not np.isfinite(v).all():
        raise MeshError("Mesh contains invalid numbers")
    ok = (f[:, 0] != f[:, 1]) & (f[:, 1] != f[:, 2]) & (f[:, 0] != f[:, 2])      # drop degenerate faces
    f = f[ok]
    if len(f) == 0:
        raise MeshError("All faces are degenerate")
    used = np.unique(f)                                                       # drop unused vertices
    remap = -np.ones(len(v), int)
    remap[used] = np.arange(len(used))
    return v[used], remap[f]


def fit_to_workspace(v: np.ndarray, half: float = 0.85) -> Tuple[np.ndarray, float]:
    """Centre the mesh on the origin and scale it to fit inside [-half, half]^3.

    Returns (vertices, scale). Unit-agnostic: a 2 mm part and a 2 km model both arrive the same size.
    """
    lo, hi = v.min(0), v.max(0)
    extent = float((hi - lo).max())
    if extent <= 0:
        raise MeshError("Mesh has zero size")
    s = 2 * half / extent
    return (v - (lo + hi) / 2) * s, s


def _cluster(v, f, n, lo, extent):
    cell = np.floor((v - lo) / extent * (n - 1e-6)).astype(np.int64)
    key = cell[:, 0] * n * n + cell[:, 1] * n + cell[:, 2]
    uniq, inv = np.unique(key, return_inverse=True)
    sums = np.zeros((len(uniq), 3))
    np.add.at(sums, inv, v)
    cv = sums / np.bincount(inv)[:, None]
    nf = inv[f]
    keep = (nf[:, 0] != nf[:, 1]) & (nf[:, 1] != nf[:, 2]) & (nf[:, 0] != nf[:, 2])
    return cv, nf[keep]


def decimate_for_display(v: np.ndarray, f: np.ndarray, max_tris: int = 2500):
    """Cheap vertex-clustering decimation so a huge model still draws at full frame rate.

    The full-resolution mesh is kept for export; this copy is only for the viewport.
    """
    if len(f) <= max_tris:
        return v, f
    lo, hi = v.min(0), v.max(0)
    extent = float((hi - lo).max()) or 1.0
    best = None
    for n in (12, 16, 24, 32, 48, 64, 96, 128, 192, 256):       # finest grid that stays inside the budget
        cv, nf = _cluster(v, f, n, lo, extent)
        if len(nf) > max_tris:
            break
        best = (cv, nf)
    if best is None:                                            # even the coarsest grid is too dense
        return v, f[np.linspace(0, len(f) - 1, max_tris).astype(int)]
    return best
